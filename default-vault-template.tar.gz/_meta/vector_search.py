# -*- coding: utf-8 -*-
"""
vector_search.py — 守藏本地向量辅助检索(Phase 5,零第三方依赖)
依据: docs/落地方案.md Phase 5 / 决策8(薄客户端+降级)

用法:
    python vector_search.py build                     # 全量重建索引(增量处理 pending)
    python vector_search.py query "文本" [--top-k 5]   # 语义检索 top-k

配置来源: <wiki_root>/shoucang.config.yaml §shoucang.embedding
    base_url 为空或配置缺失 = 语义路由禁用(exit 2)
端点不可达 = 报错退出(exit 3),调用方自行降级关键词路由
"""
import io
import json
import re
import shutil
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

WIKI_ROOT = Path(__file__).resolve().parent.parent
INDEX_FILE = WIKI_ROOT / ".index_cache" / "vector_index.jsonl"
PENDING_FILE = WIKI_ROOT / ".index_cache" / "vector_pending.json"
META_FILE = WIKI_ROOT / ".index_cache" / "vector_meta.json"  # 索引元数据(模型/维度/时间) · 2026-08-27


def read_meta() -> dict:
    """索引元数据：记录了该索引由哪个模型/维度产生（模型切换迁移判据）。"""
    try:
        return json.loads(META_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_meta(cfg: dict, rows: int) -> dict:
    """与索引同生共死的元数据：写入当前 model/dimension/构建时间/行数。"""
    META_FILE.parent.mkdir(parents=True, exist_ok=True)
    meta = {
        "model": cfg["model"],
        "dimension": int(cfg.get("dimension") or 0),
        "built_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "rows": rows,
    }
    META_FILE.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return meta


def index_mismatch(cfg: dict, meta: dict):
    """配置 vs 索引元数据不匹配说明；None=一致。模型或维度任一变化都判定为需迁移重嵌。"""
    if not meta:
        return None
    if str(meta.get("model", "")) != str(cfg["model"]):
        return f"模型不一致（索引={meta.get('model')} vs 配置={cfg['model']}）"
    if int(meta.get("dimension") or 0) != int(cfg.get("dimension") or 0):
        return f"维度不匹配（索引={meta.get('dimension')} vs 配置={cfg.get('dimension')}）"
    return None


def load_embedding_cfg():
    """从 shoucang.config.yaml 读 embedding 配置;缺失/空=禁用"""
    cfg_path = WIKI_ROOT / "shoucang.config.yaml"
    if not cfg_path.exists():
        return None
    text = cfg_path.read_text(encoding="utf-8-sig")
    sec = None
    out = {}
    for line in text.splitlines():
        s = line.rstrip()
        if not s or s.lstrip().startswith("#"):
            continue
        indent = len(s) - len(s.lstrip(" "))
        m = re.match(r"([A-Za-z_][\w-]*):\s*(.*)$", s.strip())
        if not m:
            continue
        key, val = m.group(1), m.group(2).strip()
        if indent == 0:
            sec = key if val == "" else None
        elif indent <= 2 and sec == "shoucang" and key == "embedding" and val == "":
            sec = "embedding"
        elif indent >= 4 and sec == "embedding":
            out[key] = val.split("#")[0].strip().strip('"').strip("'")  # 剥行内注释后剥引号（2026-08-27 修复：api_key 带注释被解析成注释文本）
    if not out.get("base_url"):
        return None
    return {
        "base_url": out["base_url"].rstrip("/"),
        "model": out.get("model", "bge-m3"),
        "dimension": int(out.get("dimension", "1024")),
        "api_key": out.get("api_key", ""),
    }


def embed(texts, cfg):
    """批量嵌入:POST {base_url}/embeddings (OpenAI 兼容)。返回 list[vector]。"""
    url = cfg["base_url"] + "/v1/embeddings"
    body = json.dumps({"input": texts, "model": cfg["model"]}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    key = str(cfg.get("api_key") or "").strip()
    if key:
        headers["Authorization"] = "Bearer " + key
    req = urllib.request.Request(url, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    vecs = [d["embedding"] for d in data["data"]]
    if len(vecs) != len(texts):
        raise RuntimeError(f"embedding count mismatch: {len(vecs)} != {len(texts)}")
    return vecs


def chunk_text(text, max_len=500):
    """按标题/段落切块;过短合并。返回 [chunk]。"""
    paras = re.split(r"\n{2,}", text)
    chunks, buf = [], ""
    for p in paras:
        p = p.strip()
        if not p:
            continue
        if len(buf) + len(p) <= max_len:
            buf += ("\n\n" + p if buf else p)
        else:
            if buf:
                chunks.append(buf)
            buf = p[:max_len]
    if buf:
        chunks.append(buf)
    return chunks


def iter_board_files():
    for board in ("画像", "记忆", "笔记", "归档"):
        root = WIKI_ROOT / board
        if not root.exists():
            continue
        for md in root.rglob("*.md"):
            if md.name == "_index.md":
                continue
            yield md


def cmd_prune():
    """清理索引中已不存在文件的过期条目（内容删除/归档移动后触发；R1 修复）"""
    if not INDEX_FILE.exists():
        print(json.dumps({"mode": "prune", "kept": 0, "removed": 0}, ensure_ascii=False))
        return 0
    keep, removed = [], []
    for line in INDEX_FILE.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
            p = row.get("path", "")
        except Exception:
            continue
        if p and (WIKI_ROOT / p).is_file():
            keep.append(row)
        else:
            removed.append(p)
    with INDEX_FILE.open("w", encoding="utf-8") as f:
        for r in keep:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(json.dumps({"mode": "prune", "kept": len(keep), "removed": len(removed),
                      "dangling": removed[:20]}, ensure_ascii=False))
    return 0


def cmd_build(force: bool = False):
    cfg = load_embedding_cfg()
    if not cfg:
        print(json.dumps({"error": "embedding disabled: base_url empty"}, ensure_ascii=False))
        return 2
    # 待处理清单 = pending 标记 或 全量(索引为空时)
    existing = {}
    if INDEX_FILE.exists():
        for line in INDEX_FILE.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
                existing[row["path"]] = row
            except Exception:
                pass
    # 模型切换迁移检测（2026-08-27）：索引元数据 vs 当前配置
    meta = read_meta()
    why = index_mismatch(cfg, meta) if existing else None
    if why and not force:
        print(json.dumps({"error": "index 与当前嵌入模型不匹配", "mode": "needs_force",
                          "why": why,
                          "hint": "切换模型后旧向量不可复用，须全量重嵌：python vector_search.py build --force（旧索引自动备份）"},
                         ensure_ascii=False, indent=1))
        return 4
    full = not existing or (why and force)
    if force and existing:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        for f in (INDEX_FILE, META_FILE):
            if f.exists():
                shutil.copy2(f, f.with_name(f.name + f".bak-{ts}"))
    pending = []
    try:
        pending = json.loads(PENDING_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    targets = []
    seen = set()
    for md in iter_board_files():
        rel = md.relative_to(WIKI_ROOT).as_posix()
        seen.add(rel)
        if full or rel in pending or rel not in existing:
            targets.append((rel, md))
    removed = [p for p in existing if p not in seen]

    rows_keep = [existing[p] for p in existing if p not in set(removed)]
    batch_texts, batch_meta = [], []
    for rel, md in targets:
        try:
            body = md.read_text(encoding="utf-8").lstrip("\ufeff")  # BOM 防御（2026-08-27）
        except Exception:
            continue
        fm_conf = 0
        if body.startswith("---"):
            # R2 索引行携带推理用元数据：confidence（frontmatter）与 mtime、一级目录（R1 过滤/排序用）
            head = body.split("---", 2)[1] if body.count("---") >= 2 else ""
            fm_conf = 0
            import re as _re
            mm = _re.search(r"^confidence\s*:\s*(\d+)", head, _re.M)
            if mm:
                fm_conf = int(mm.group(1))
            parts = body.split("---", 2)
            body = parts[2] if len(parts) >= 3 else body
        try:
            mtime = int(md.stat().st_mtime)
        except Exception:
            mtime = 0
        rel_dir = rel.split("/")[0] if "/" in rel else rel
        for ch in chunk_text(body):
            batch_texts.append(ch[:1000])
            batch_meta.append({"path": rel, "chunk": ch[:200],
                               "dir": rel_dir, "mtime": mtime, "conf": fm_conf})
    vectors = []
    B = 16
    for i in range(0, len(batch_texts), B):
        vectors.extend(embed(batch_texts[i:i + B], cfg))
    new_rows = [{"path": m["path"], "chunk": m["chunk"], "vector": v,
                 "dir": m["dir"], "mtime": m["mtime"], "conf": m["conf"]}
                for m, v in zip(batch_meta, vectors)]
    all_rows = rows_keep + new_rows
    INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
    with INDEX_FILE.open("w", encoding="utf-8") as f:
        for r in all_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    try:
        PENDING_FILE.unlink()
    except Exception:
        pass
    write_meta(cfg, len(all_rows))  # 索引元数据随索引同生（2026-08-27）
    print(json.dumps({"mode": "full" if full else "incremental", "forced": bool(force),
                      "model": cfg["model"], "dimension": cfg["dimension"],
                      "embedded_chunks": len(new_rows), "removed": len(removed),
                      "total_rows": len(all_rows)}, ensure_ascii=False))
    return 0


def cmd_check():
    """配置 vs 索引一致性体检：报告模型/维度/行数/是否需迁移重嵌。"""
    cfg = load_embedding_cfg()
    meta = read_meta()
    configured = None
    if cfg:
        configured = {"enabled": True, "base_url": cfg["base_url"],
                      "model": cfg["model"], "dimension": cfg["dimension"],
                      "api_key_set": bool(cfg.get("api_key"))}
    else:
        configured = {"enabled": False, "note": "base_url 为空 = 语义检索禁用"}
    index = {"model": meta.get("model"), "dimension": meta.get("dimension"),
             "rows": meta.get("rows", 0), "built_at": meta.get("built_at")} if meta else None
    why = index_mismatch(cfg, meta) if (cfg and meta) else None
    print(json.dumps({
        "configured": configured,
        "index": index,
        "consistent": why is None,
        "needs_rebuild": why is not None,
        "why": why,
        "index_missing": (cfg is not None) and not bool(meta),
    }, ensure_ascii=False, indent=1))
    return 0


def cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    return dot / (na * nb) if na and nb else 0.0


def _rerank(url, query, documents):
    """R4 精排：调本地 rerank 服务（OpenAI 兼容风格 POST /v1/rerank）。返回 list[score]。"""
    req = urllib.request.Request(
        url.rstrip("/") + "/v1/rerank",
        data=json.dumps({"query": query, "documents": documents}).encode("utf-8"),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    out = [0.0] * len(documents)
    for it in data.get("results", []):
        try:
            out[int(it["index"])] = float(it["score"])
        except Exception:
            pass
    return out


def cmd_query(query, top_k, dir_filter="", days=0, min_conf=0, rerank_url="", rerank_top=None):
    """语义召回（R1-R4 · 2026-08-27）：

    R1 metadata 过滤：--dir <一级或二级前缀> / --days <N>（仅近 N 天修改）/ --min-conf <N>
    R2 排序带 confidence：向量分数主序，conf 打平；索引行现携带 dir/mtime/conf
    R3 混合检索：关键词精确命中集与向量候选**合并**（命中者保底分），两路互补
    R4 可选精排：--rerank-url 对 top-N 候选调本地 rerank 服务重排序取 top_k
    """
    cfg = load_embedding_cfg()
    if not cfg:
        print(json.dumps({"error": "embedding disabled"}, ensure_ascii=False))
        return 2
    if not INDEX_FILE.exists():
        print(json.dumps({"error": "index not built; run build first"}, ensure_ascii=False))
        return 3
    meta = read_meta()
    why = index_mismatch(cfg, meta) if meta else "索引无元数据"
    if why:
        # 切换模型后未重嵌：旧向量维度/分布与当前模型不符，禁止静默错误召回（2026-08-27）
        print(json.dumps({"error": "index model mismatch", "why": why,
                          "hint": "运行 python vector_search.py build --force 全量重嵌后再查询"},
                         ensure_ascii=False, indent=1))
        return 4
    rows = []
    for line in INDEX_FILE.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except Exception:
            pass
    now = time.time()
    # R1 过滤：目录前缀 / 修改时限 / 最低置信
    filtered = []
    for r in rows:
        if dir_filter and not str(r.get("dir", "")).startswith(dir_filter):
            continue
        if days > 0:
            try:
                if now - float(r.get("mtime") or 0) > days * 86400:
                    continue
            except Exception:
                pass
        if min_conf > 0 and int(r.get("conf") or 0) < min_conf:
            continue
        filtered.append(r)
    if not filtered:
        print(json.dumps({"query": query, "hits": [], "note": "过滤后无候选（调整 --dir/--days/--min-conf）"}, ensure_ascii=False))
        return 0
    qv = embed([query], cfg)[0]
    scored = []
    for r in filtered:
        scored.append((cosine(qv, r["vector"]), r))
    scored.sort(key=lambda t: -t[0])
    # R3 混合检索：关键词精确命中集（CJK 2-gram 与词片匹配 chunk），并入候选池，命中者保底分
    kw_hits = set()
    grams = set()
    norm_q = re.sub(r"[\s\u3000\uFF0C\u3001\u3002\uFF1B\uFF1A\uFF01\uFF1F\uFF08\uFF09\u3010\u3011{}'\":,\-\._=+*/\\|]+", "", query)
    if len(norm_q) >= 2:
        for i in range(len(norm_q) - 1):
            grams.add(norm_q[i:i + 2])
    for r in filtered:
        chunk = str(r.get("chunk", "") or "")
        hit = any(g in chunk for g in grams)
        if hit:
            kw_hits.add(r["path"])
    pool = {}
    for s, r in scored:
        pool[r["path"]] = (s, r)
    for r in filtered:
        if r["path"] in kw_hits and r["path"] not in pool:
            pool[r["path"]] = (0.0, r)  # 两路补足：仅关键词命中（向量未进 top）也入池
    # 排序：向量分主导；关键词命中保底 0.85；conf 做平局键（R2）
    merged = []
    for path, (s, r) in pool.items():
        s2 = s
        if path in kw_hits:
            s2 = max(s2, 0.85)
        merged.append((s2, int(r.get("conf") or 0), r))
    merged.sort(key=lambda t: (-t[0], -t[1]))
    # R4 可选精排：对 top-N（默认 top_k*4）调本地 rerank 服务重排
    if rerank_url and merged:
        n = int(rerank_top or top_k * 4)
        cands = merged[:n]
        try:
            scores = _rerank(rerank_url, query, [c[2] for c in cands])
            for i, sc in enumerate(scores):
                cands[i] = (sc, cands[i][1], cands[i][2])
            cands.sort(key=lambda t: (-t[0], -t[1]))
            merged = cands
        except Exception as e:
            merged[:] = merged  # 精排失败降级为原排序
            print(f"[rerank 降级] {e}", file=sys.stderr)
    hits = [{"score": round(s, 4), "path": r["path"], "snippet": str(r.get("chunk"))[:120],
             "conf": int(r.get("conf") or 0), "dir": r.get("dir")}
            for s, _c, r in merged[:top_k]]
    print(json.dumps({"query": query, "hits": hits, "mode": "rerank" if rerank_url else "hybrid"},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    rest = sys.argv[2:]
    if cmd == "build":
        sys.exit(cmd_build(force="--force" in rest))
    elif cmd == "prune":
        sys.exit(cmd_prune())
    elif cmd == "check":
        sys.exit(cmd_check())
    elif cmd == "query":
        k = 5
        qargs = []
        i = 0
        opts = {"dir": "", "days": 0, "min_conf": 0, "rerank_url": "", "rerank_top": None}
        while i < len(rest):
            a = rest[i]
            if a in ("--top-k", "--dir", "--days", "--min-conf", "--rerank-url", "--rerank-top") and i + 1 < len(rest):
                val = rest[i + 1]
                if a == "--top-k":
                    try:
                        k = int(val)
                    except Exception:
                        pass
                elif a == "--dir":
                    opts["dir"] = val
                elif a == "--days":
                    try:
                        opts["days"] = max(0, int(val))
                    except Exception:
                        pass
                elif a == "--min-conf":
                    try:
                        opts["min_conf"] = max(0, int(val))
                    except Exception:
                        pass
                elif a == "--rerank-url":
                    opts["rerank_url"] = val
                elif a == "--rerank-top":
                    try:
                        opts["rerank_top"] = int(val)
                    except Exception:
                        pass
                i += 2
            else:
                qargs.append(a)
                i += 1
        qtext = " ".join(qargs)
        k = max(1, min(k, 20))  # 2d 配额代码化（落地方案）：top-k 硬上限 20，防递归爆量
        sys.exit(cmd_query(qtext, k, opts["dir"], opts["days"], opts["min_conf"],
                           opts["rerank_url"], opts["rerank_top"]))
    else:
        print(__doc__)
        sys.exit(2)
