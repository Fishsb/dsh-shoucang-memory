# -*- coding: utf-8 -*-
"""model_manager.py — 守藏向量模型一键下载/部署（2026-08-27）

「框架 + 可选下载」模式（对齐 dsh-prompt-enhancer 本地模型下载范式 + 生态 bge-m3-openai-server 服务范本）：
- pull：从 HuggingFace（优先 HF_ENDPOINT 镜像）下载 transformers.js 布局模型（config.json/tokenizer*/onnx/*），
  断点续传 + 进度文件（.progress-<id>.json），模型落 ~/.dsh/shoucang/models/<id>/
- deploy：准备 runtime（@huggingface/transformers，优先 junction 复用生态已有运行时）→ 拷贝 embed_server.cjs →
  spawn detached 服务（OpenAI 兼容 /v1/embeddings）→ 健康检查，返回 {port, dim, ok}
- list/status：扫描模型目录 + 注册表 models.json + 服务存活探测

零硬编码路径：所有本机路径由环境/注册表派生；端口默认 9917（避开 9915/3082）。
用法：python model_manager.py list|pull|progress|deploy|status  …
"""
import io
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

DSH_HOME = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
MODEL_HOME = DSH_HOME / "shoucang" / "models"
RUNTIME_DIR = DSH_HOME / "shoucang" / "runtime"
REG_FILE = MODEL_HOME / "models.json"
SERVER_SRC = Path(__file__).resolve().parent / "embed_server.cjs"   # 部署时拷贝到 runtime
DEFAULT_PORT = 9917
KNOWN_RUNTIME = DSH_HOME / "memory" / "runtime" / "node_modules"     # 生态已有 transformers.js 运行时
HF_ENDPOINT = (os.environ.get("HF_ENDPOINT") or "https://huggingface.co").rstrip("/")

BOM = "\ufeff"


def _out(o):
    print(json.dumps(o, ensure_ascii=False, indent=1))
    return 0


def read_reg():
    try:
        return json.loads(REG_FILE.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"version": 1, "models": []}


def write_reg(reg):
    REG_FILE.parent.mkdir(parents=True, exist_ok=True)
    REG_FILE.write_text(json.dumps(reg, ensure_ascii=False, indent=1), encoding="utf-8")


def reg_find(reg, mid):
    for m in reg["models"]:
        if m.get("id") == mid:
            return m
    return None


def http_json(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "shoucang-model-manager/0.1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def hf_tree(repo):
    """枚举 HF 仓库文件：{path,size,type}。镜像自动跟随 HF_ENDPOINT。"""
    url = f"{HF_ENDPOINT}/api/models/{repo}/tree/main?recursive=true&expand=true"
    items = http_json(url)
    out = []
    for it in items:
        p = it.get("path")
        if not p or p in (".gitattributes",) or p.startswith("."):
            continue
        out.append({"path": p, "size": int(it.get("size") or it.get("lfs", {}).get("size") or 0)})
    return out


def progress_path(mid):
    return MODEL_HOME / f".progress-{mid}.json"


def write_progress(mid, **kw):
    try:
        p = progress_path(mid)
        data = {"mid": mid}
        data.update(kw)
        p.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def download_file(url, dest: Path, progress):
    """断点续传单文件：.part 临时 + Range 头；进度回调。"""
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    already = part.stat().st_size if part.exists() else 0
    headers = {"User-Agent": "shoucang-model-manager/0.1"}
    if already:
        headers["Range"] = f"bytes={already}-"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=60) as r:
        total = already
        mode = "ab" if already else "wb"
        with part.open(mode) as f:
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                total += len(chunk)
                progress("file_bytes", len(chunk))
    if dest.exists():
        dest.unlink()
    part.rename(dest)


def cmd_pull(repo, mid, dim):
    reg = read_reg()
    existing = reg_find(reg, mid)
    model_dir = MODEL_HOME / mid
    if existing and model_dir.exists() and (model_dir / "config.json").exists():
        return _out({"error": f"模型已存在: {mid}", "status": "already"})
    write_progress(mid, phase="listing", repo=repo, done_files=0, total_files=0,
                   done_bytes=0, total_bytes=0, cur="", finished=False)
    try:
        files = hf_tree(repo)
    except Exception as e:
        write_progress(mid, phase="error", error=str(e), finished=True)
        return _out({"error": f"HF tree 枚举失败: {e}"})
    # transformers.js 必需集：config/tokenizer 系 + onnx 只选一个量化变体（q8 优先；避免全变体数百 MB）
    keep = []
    for f in files:
        p = f["path"]
        if re.match(r"^(config|tokenizer|special_tokens_map|tokenizer_config)\.(json|txt)$", p.split("/")[-1]):
            keep.append(f)
    onnx_cands = [f for f in files if f["path"].startswith("onnx/")]

    def onnx_key(f):
        n = f["path"].split("/")[-1].lower()
        if "quantized" in n:
            return (0, f["size"])   # q8：transformers.js 默认 dtype，最小且兼容
        if "bnb4" in n:
            return (1, f["size"])
        if "uint8" in n:
            return (2, f["size"])
        if "fp16" in n:
            return (3, f["size"])
        return (4, f["size"])

    if onnx_cands:
        keep.append(min(onnx_cands, key=onnx_key))
    total = sum(f["size"] for f in keep)
    write_progress(mid, phase="downloading", repo=repo, done_files=0, total_files=len(keep),
                   done_bytes=0, total_bytes=total, cur="", finished=False)
    done_bytes = 0
    done_files = 0
    cur_file = ""

    def prog(kind, n):
        nonlocal done_bytes
        if kind == "file_bytes":
            done_bytes += n
            write_progress(mid, phase="downloading", repo=repo, done_files=done_files,
                           total_files=len(keep), done_bytes=done_bytes, total_bytes=total,
                           cur=cur_file, finished=False)

    try:
        for idx, f in enumerate(keep):
            cur_file = f["path"]
            url = f"{HF_ENDPOINT}/{repo}/resolve/main/{f['path']}"
            download_file(url, model_dir / f["path"], prog)
            done_files = idx + 1
            write_progress(mid, phase="downloading", repo=repo, done_files=done_files,
                           total_files=len(keep), done_bytes=done_bytes, total_bytes=total,
                           cur=cur_file, finished=False)
    except Exception as e:
        write_progress(mid, phase="error", error=str(e), cur=cur_file, finished=True)
        return _out({"error": f"下载失败: {e}", "cur": cur_file})
    write_progress(mid, phase="done", done_files=len(keep), total_files=len(keep),
                   done_bytes=done_bytes, total_bytes=total, cur="", finished=True)
    reg["models"] = [m for m in reg["models"] if m.get("id") != mid]
    reg["models"].append({"id": mid, "repo": repo, "dim": int(dim), "dir": str(model_dir),
                          "size": done_bytes, "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                          "port": None, "status": "downloaded"})
    write_reg(reg)
    return _out({"ok": True, "id": mid, "files": len(keep), "bytes": done_bytes})


def cmd_progress(mid):
    p = progress_path(mid)
    if not p.exists():
        return _out({"error": f"无进度: {mid}"})
    try:
        return _out(json.loads(p.read_text(encoding="utf-8-sig")))
    except Exception:
        return _out({"raw": p.read_text(encoding="utf-8-sig")[:400]})


def ensure_runtime():
    """准备 runtime/@huggingface/transformers：复用生态 junction 或 npm install。返回 (node, runtime_dir)。"""
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    nm = RUNTIME_DIR / "node_modules"
    if not (nm / "@huggingface" / "transformers").exists():
        if KNOWN_RUNTIME.exists():
            # 生态已有 transformers.js（junction 复用，零下载）
            if nm.exists():
                shutil.rmtree(nm)
            try:
                r = subprocess.run(["cmd", "/c", "mklink", "/J", str(nm), str(KNOWN_RUNTIME)],
                                   capture_output=True, text=True, timeout=30)
                if (nm / "@huggingface" / "transformers").exists():
                    return r.returncode == 0 or True, nm
            except Exception:
                pass
        # npm install 兜底
        node = os.environ.get("NODE") or "node"
        r = subprocess.run([node, "--version"], capture_output=True, text=True)
        if r.returncode != 0:
            return False, "node 不可用"
        ins = subprocess.run([node, "-e",
                              "const p=require('path');const e=process.execPath;"
                              "const npm=require('fs').existsSync(p.join(p.dirname(e),'npm-cli.js'))?"
                              "p.join(p.dirname(e),'npm-cli.js'):'npm';console.log(npm)"],
                             capture_output=True, text=True, timeout=30)
        npm = (ins.stdout or "npm").strip()
        subprocess.run([node, npm, "install", "@huggingface/transformers", "--prefix", str(RUNTIME_DIR),
                        "--no-fund", "--no-audit"], capture_output=True, text=True, timeout=300)
    return True, str(RUNTIME_DIR)


def service_alive(port):
    try:
        with socket.create_connection(("127.0.0.1", int(port)), timeout=1):
            return True
    except Exception:
        return False


def cmd_import(abs_dir: str, mid=None):
    """导入本地已有模型目录（引用式·不拷贝）：校验 transformers.js 布局（config.json + onnx/*），
    从 config.hidden_size 推断维度，登记 models.json 后即可 deploy。"""
    d = Path(abs_dir).expanduser()
    if not d.is_dir():
        return _out({"error": f"目录不存在: {d}"})
    cfg_file = d / "config.json"
    if not cfg_file.exists():
        return _out({"error": f"缺少 config.json（非 HuggingFace/transformers.js 模型目录）: {d}"})
    try:
        cfg = json.loads(cfg_file.read_text(encoding="utf-8-sig"))
        dim = int(cfg.get("hidden_size") or cfg.get("dimension") or 0)
    except Exception:
        dim = 0
    onnx_files = list(d.glob("onnx/*")) or list(d.rglob("*.onnx"))
    if not onnx_files:
        return _out({"error": "目录内无 onnx 权重（transformers.js 需 quantized onnx），不满足嵌入模型布局"})
    if dim <= 0:
        return _out({"error": "config.json 未能推断维度（hidden_size 缺失）"})
    size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
    mid = mid or d.name
    reg = read_reg()
    ex = reg_find(reg, mid)
    if ex and Path(ex.get("dir") or MODEL_HOME / mid).resolve() == d.resolve():
        m = ex
        m.update({"repo": ex.get("repo"), "dim": dim, "dir": str(d), "size": size,
                  "status": "imported", "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
    else:
        reg["models"] = [m2 for m2 in reg["models"] if m2.get("id") != mid]
        reg["models"].append({"id": mid, "repo": None, "dim": dim, "dir": str(d), "size": size,
                              "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                              "port": None, "status": "imported"})
    write_reg(reg)
    return _out({"ok": True, "id": mid, "dir": str(d), "dim": dim, "size": size,
                 "onnx": str(onnx_files[0].name), "status": "imported"})


def _kill_service(port, pid=None):
    """杀端口/pid 对应服务进程（Windows）。返回是否成功。"""
    if pid:
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True, timeout=15)
            return True
        except Exception:
            pass
    if port:
        try:
            net = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=20).stdout
            for line in net.splitlines():
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.split()
                    if parts:
                        subprocess.run(["taskkill", "/PID", parts[-1], "/F"], capture_output=True, timeout=15)
                        return True
        except Exception:
            pass
    return False


def cmd_stop(mid):
    """停止模型服务（单活约束 · 2026-08-27）：杀进程 + reg 标记 stopped。"""
    reg = read_reg()
    m = reg_find(reg, mid)
    if not m:
        return _out({"error": f"无此模型: {mid}"})
    killed = _kill_service(m.get("port"), m.get("pid"))
    m["status"] = "stopped"
    write_reg(reg)
    return _out({"ok": True, "id": mid, "port": m.get("port"), "killed": killed, "status": "stopped"})


def cmd_deploy(mid, port=None, dim=None):
    reg = read_reg()
    m = reg_find(reg, mid)
    model_dir = Path(m.get("dir")) if (m and m.get("dir")) else (MODEL_HOME / mid)
    if not m or not (model_dir / "config.json").exists():
        return _out({"error": f"模型不可用: {mid}（先 pull 或 import 本地目录）"})
    # 单活约束（2026-08-27 定稿）：至多一个嵌入服务运行——切换部署前先停其它 running 的嵌入模型
    stopped_others = []
    for o in reg["models"]:
        if o.get("id") == mid:
            continue
        if o.get("port") and (service_alive(o["port"]) or o.get("status") == "running"):
            if _kill_service(o.get("port"), o.get("pid")):
                o["status"] = "stopped"
                stopped_others.append(o["id"])
    if stopped_others:
        write_reg(reg)
    # 重新读取目标（stop 循环可能改过 reg）
    reg = read_reg()
    m = reg_find(reg, mid)
    yaml_dim = None
    try:
        import sys as _s
        udg = Path(__file__).resolve().parent.parent / "_meta" / "registry" / "udg"
        if str(udg) not in _s.path:
            _s.path.insert(0, str(udg))
        import shoucang_config as _sc
        emb = _sc.load_config(Path(__file__).resolve().parent.parent).get("embedding", {}) or {}
        yaml_dim = int(emb.get("dimension") or 0)
    except Exception:
        pass
    dim = int(dim or m.get("dim") or yaml_dim or 1024)
    r = ensure_runtime()
    if not r[0]:
        return _out({"error": f"runtime 准备失败: {r[1]}"})
    runtime_dir = r[1]
    # 服务脚本拷贝（始终覆盖同步，避免旧版本残留）
    shutil.copy2(SERVER_SRC, Path(runtime_dir) / "embed_server.cjs")
    if m.get("port") and service_alive(m["port"]):
        return _out({"ok": True, "id": mid, "port": m["port"], "dim": int(m.get("dim") or dim),
                     "note": "服务已在运行，复用"})
    port = int(port or m.get("port") or DEFAULT_PORT)
    # 端口被占则自增探测
    while service_alive(port):
        port += 1
    logf = DSH_HOME / "shoucang" / f"embed-{mid}.log"
    node = os.environ.get("NODE") or "node"
    child = subprocess.Popen([node, str(Path(runtime_dir) / "embed_server.cjs"),
                              str(model_dir), str(dim), "cls", str(port), str(logf)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    # Popen 无 detach()（多进程 API）；Windows 上 DETACHED_PROCESS 已脱离控制台，靠 pid 追踪
    # 健康检查（≤8s）
    up = False
    t0 = time.time()
    while time.time() - t0 < 8:
        if service_alive(port):
            up = True
            break
        time.sleep(0.4)
    m["port"] = port
    m["status"] = "running" if up else "starting"
    m["pid"] = child.pid
    m["dim"] = dim
    write_reg(reg)
    return _out({"ok": up, "id": mid, "port": port, "dim": dim, "pid": child.pid,
                 "note": "健康检查" + ("通过" if up else "未就绪(稍后重试)"),
                 "stopped_others": stopped_others if stopped_others else []})


def cmd_deploy_rerank(abs_dir: str, port=None):
    """R4 精排服务部署：加载 cross-encoder（bge-reranker 类）跑 /v1/rerank。
    简化：不登记 models.json（精排非嵌入模型），返回 (port, ok) 供配置 embedding.rerank_url。"""
    d = Path(abs_dir).expanduser()
    if not d.is_dir() or not (d / "config.json").exists():
        return _out({"error": f"rerank 模型目录无效（无 config.json）: {d}"})
    r = ensure_runtime()
    if not r[0]:
        return _out({"error": f"runtime 准备失败: {r[1]}"})
    runtime_dir = r[1]
    src = Path(__file__).resolve().parent / "rerank_server.cjs"
    if not src.exists():
        return _out({"error": "rerank_server.cjs 缺失"})
    shutil.copy2(src, Path(runtime_dir) / "rerank_server.cjs")
    port = int(port or 9925)
    while service_alive(port):
        port += 1
    logf = DSH_HOME / "shoucang" / "rerank.log"
    node = os.environ.get("NODE") or "node"
    subprocess.Popen([node, str(Path(runtime_dir) / "rerank_server.cjs"), str(d), str(port), str(logf)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    up = False
    t0 = time.time()
    while time.time() - t0 < 8:
        if service_alive(port):
            up = True
            break
        time.sleep(0.4)
    return _out({"ok": up, "port": port, "model_dir": str(d),
                 "note": "健康检查" + ("通过" if up else "未就绪(稍后重试)") + "；配置 embedding.rerank_url 后 query --rerank-url 启用精排"})


def cmd_list():
    reg = read_reg()
    out = []
    MODEL_HOME.mkdir(parents=True, exist_ok=True)
    # 有效模型 = MODEL_HOME 目录 ∪ reg 外部引用（import 的本地目录，dir 不在 MODEL_HOME）
    # （2026-08-27 修复：外部引用此前不列表面板看不到，import 后无法部署）
    local_dirs = [p for p in MODEL_HOME.iterdir() if p.is_dir() and not p.name.startswith(".")]
    seen_ids = {d.name for d in local_dirs}
    ext_refs = [m for m in reg["models"]
                if (m.get("id") not in seen_ids and m.get("dir")
                    and Path(m["dir"]).exists() and Path(m["dir"]).resolve() != (MODEL_HOME / m["id"]).resolve())]

    def fetch_state(mid, model_dir, entry):
        dim = entry.get("dim")
        size = entry.get("size")
        if dim is None or size is None:
            dim_file = model_dir / "config.json"
            try:
                cfg = json.loads(dim_file.read_text(encoding="utf-8-sig"))
                dim = int(cfg.get("hidden_size") or cfg.get("dimension") or 1024)
            except Exception:
                pass
            try:
                size = sum(f.stat().st_size for f in model_dir.rglob("*") if f.is_file())
            except Exception:
                pass
        port = entry.get("port")
        status = entry.get("status") or "downloaded"  # imported 或下载完成态
        if port and service_alive(port):
            status = "running"
        elif port and entry.get("status") == "running":
            status = "stopped"
        row = {"id": mid, "repo": entry.get("repo"), "dim": dim, "size": size,
               "port": port, "status": status, "at": entry.get("at"), "local": Path(model_dir).resolve() == (MODEL_HOME / mid).resolve()}
        try:
            p = progress_path(mid)
            if p.exists():
                d = json.loads(p.read_text(encoding="utf-8-sig"))
                if not d.get("finished") and d.get("phase") not in ("done", "error"):
                    total = int(d.get("total_bytes") or 0)
                    done = int(d.get("done_bytes") or 0)
                    row["status"] = "downloading"
                    row["progress"] = round(100 * done / total, 1) if total else 0
                    row["progress_cur"] = d.get("cur")
                elif d.get("phase") == "error":
                    row["progress_error"] = d.get("error")
        except Exception:
            pass
        return row

    for mid_dir in sorted(local_dirs):
        out.append(fetch_state(mid_dir.name, mid_dir, reg_find(reg, mid_dir.name) or {}))
    for m in ext_refs:
        out.append(fetch_state(str(m["id"]), Path(m["dir"]), m))
    _reg_running = [{"id": m["id"], "port": m["port"]} for m in reg["models"]
                    if m.get("port") and service_alive(m["port"])]
    return _out({"models": out, "running": _reg_running})


def cmd_status():
    return cmd_list()


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    c = args[0]
    if c == "pull":
        if len(args) < 3:
            return _out({"error": "用法: pull <id> <repo> [--dim N]"})
        mid, repo = args[1], args[2]
        dim = args[args.index("--dim") + 1] if "--dim" in args else 1024
        return cmd_pull(repo, mid, dim)
    if c == "progress":
        return cmd_progress(args[1] if len(args) > 1 else "")
    if c == "deploy":
        mid = args[1] if len(args) > 1 else ""
        port = None
        dim = None
        if "--port" in args:
            port = int(args[args.index("--port") + 1])
        if "--dim" in args:
            dim = int(args[args.index("--dim") + 1])
        return cmd_deploy(mid, port, dim)
    if c in ("list", "status"):
        return cmd_list()
    if c == "stop":
        if len(args) < 2:
            return _out({"error": "用法: stop <id>"})
        return cmd_stop(args[1])
    if c == "import":
        if len(args) < 2:
            return _out({"error": "用法: import <绝对目录> [--id <id>]"})
        mid = args[args.index("--id") + 1] if "--id" in args else None
        return cmd_import(args[1], mid)
    if c == "deploy-rerank":
        if len(args) < 2:
            return _out({"error": "用法: deploy-rerank <模型目录> [--port N]"})
        port = None
        if "--port" in args:
            port = int(args[args.index("--port") + 1])
        return cmd_deploy_rerank(args[1], port)
    return _out({"error": f"未知命令: {c}"})


if __name__ == "__main__":
    sys.exit(main())