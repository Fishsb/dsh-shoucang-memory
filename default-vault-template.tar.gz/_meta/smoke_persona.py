# -*- coding: utf-8 -*-
"""守藏 Phase1 冒烟测试: persona 类型经 write_gate/read_gate 全链路"""
import sys, json
sys.path.insert(0, r'D:\lk\FF\shoucang-dev-wiki\_meta\registry')
from udg.write_gate import write_wiki_file
from udg.read_gate import list_by_type, get_file

results = []

# T1: 我域种子条目
r1 = write_wiki_file(
    target_type="persona", title="用户协作风格画像",
    content=(
        "# 用户协作风格画像\n\n"
        "## 概述\n\n用户为中文使用者,习惯中文短指令;对提取速度敏感,"
        "回答需直接并附实测数据。\n\n"
        "## 关键事实\n\n- 开源免费工具优先于付费 API\n"
        "- 会追问决策原因与耗时\n- 重实测数据,轻转述\n"
    ),
    target="我",
    frontmatter={
        "name": "user-collaboration-style-note",
        "tags": ["偏好/协作"],
        "description": "用户协作风格:中文短指令、重实测数据、开源优先",
    },
)
results.append(("T1 我域写入", r1))

# T2: 你域种子条目
r2 = write_wiki_file(
    target_type="persona", title="AI响应哲学准则",
    content=(
        "# AI响应哲学准则\n\n"
        "## 概述\n\n守藏语境下 AI 的行为基线:轻代码多路由,"
        "机制做成契约而非硬编码管线。\n\n"
        "## 行为准则\n\n- 召回选路权交给模型自由决策\n"
        "- 系统只守底线:写路径唯一+frontmatter 合规\n"
        "- 信息规模增长靠指针表分层,不靠过滤代码\n"
    ),
    target="你",
    frontmatter={
        "name": "ai-response-philosophy-note",
        "tags": ["偏好/架构"],
        "description": "AI 行为基线:轻代码多路由、契约优先、底线守护",
    },
)
results.append(("T2 你域写入", r2))

# T3: 非法 subtype 必须被拒
r3 = write_wiki_file(
    target_type="persona", title="非法测试",
    content="# x\n\n内容占位,超过一百字符的正文内容用于绕过长度门。" * 3,
    target="它",
    frontmatter={"name": "illegal-subtype-test"},
)
results.append(("T3 非法subtype拒绝", {"status": r3.get("status"), "error": r3.get("error", "")[:60]}))

# T4: read_gate 读回
lst = list_by_type("persona")
files = [x["path"] for x in lst]
results.append(("T4 read_gate读回", {"count": len(lst), "files": files}))

ok = True
for i, (name, r) in enumerate(results):
    print(f"--- {name} ---")
    print(json.dumps(r, ensure_ascii=False, default=str)[:500])
    if i == 2:  # T3 预期 error(拒绝),在下方单独判定
        continue
    if "error" in str(r.get("status", "")):
        ok = False
# T3 应该是 error 才对(预期拒绝)
t3 = results[2][1]
if t3["status"] != "error":
    print("!!! T3 失败: 非法 subtype 未被拒绝")
    ok = False
if len(results[3][1]["files"]) < 2:
    print("!!! T4 失败: 读回条目不足 2")
    ok = False

print("\nSMOKE:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
