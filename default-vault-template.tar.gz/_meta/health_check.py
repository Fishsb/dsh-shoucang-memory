#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""守藏健康检查（R2 修复：测试残留基线 + _index 死链 + 结构核验）。

用法:
    python health_check.py            # 默认检查，输出 JSON；--strict 退出码=1 当有问题
    python health_check.py --fix      # 列出可自动修复项（默认不修改）
"""
import json
import re
import sys
from pathlib import Path

sys.stdout = __import__("io").TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

WIKI_ROOT = Path(__file__).resolve().parent.parent
BOARDS = ("画像", "记忆", "笔记", "归档")
TEST_PREFIX = re.compile(r"(^|[-_])(audit|tmp|hot-memory|test|audit-|mock)-|[.-](test|mock)$|^(p-.*-test|m-level-)", re.I)

def _find_indexes(root: Path):
    for board in BOARDS:
        d = root / board
        if d.exists():
            for idx in d.rglob("_index.md"):
                yield idx

def check(root: Path = None):
    root = root or WIKI_ROOT
    issues = []
    # 1) 测试残留基线
    residues = []
    for board in BOARDS:
        d = root / board
        if not d.exists():
            continue
        for md in d.rglob("*.md"):
            if md.name == "_index.md":
                continue
            if TEST_PREFIX.search(md.stem):
                residues.append(md.relative_to(root).as_posix())
    # 2) _index 死链
    dead = []
    for idx in _find_indexes(root):
        try:
            text = idx.read_text(encoding="utf-8")
        except Exception:
            continue
        base = idx.parent
        for m in re.finditer(r"\[\[([^\]|#]+)\]\]", text):
            tgt = m.group(1).strip().split("/")
            # 相对链接：目录名 或 文件 stem
            cand_file = base / (m.group(1).strip() + ".md")
            cand_dir = base / m.group(1).strip()
            exists = cand_file.is_file() or cand_dir.is_dir()
            if not exists and m.group(1).strip() != "wiki-link":
                dead.append(f"{idx.relative_to(root).as_posix()} -> [[{m.group(1).strip()}]]")
    # 3) 结构核验（预期 12 目录）
    expected = ["画像/我", "画像/你", "记忆/日记忆", "记忆/参考", "记忆/工具",
                "记忆/规则", "记忆/环境", "记忆/配置", "笔记", "归档"]
    missing = [d for d in expected if not (root / d).exists()]
    if residues:
        issues.append({"type": "residue", "count": len(residues), "files": residues[:10]})
    if dead:
        issues.append({"type": "deadlink", "count": len(dead), "files": dead[:10]})
    if missing:
        issues.append({"type": "structure", "missing": missing})
    ok = not issues
    result = {"ok": ok, "root": str(root), "issues": issues,
              "residue_count": len(residues), "deadlink_count": len(dead)}
    print(json.dumps(result, ensure_ascii=False, indent=1))
    return 0 if ok else 1

if __name__ == "__main__":
    strict = "--strict" in sys.argv
    rc = check()
    if strict and rc != 0:
        sys.exit(rc)
    sys.exit(0)