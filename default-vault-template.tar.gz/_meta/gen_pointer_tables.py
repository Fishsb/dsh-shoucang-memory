# -*- coding: utf-8 -*-
"""守藏指针表投影器（真源+投影 · 2026-08-27 借鉴 mnemon Runtime「真源/投影分离」设计）。

定位（与 `_index.md` 语义定稿对齐 — 2026-08-27）：
    `_index.md` 内并存两层，职责分离：
      · 索引区（frontmatter + # 标题 + 条目表 + ## 子目录）  = **生成物**：由本脚本按目录扫描确定性重建
      · 规则区（`## 目录文件规范` 起）                      = **人工精修内容**：投影时逐字保留，绝不重写
    条目文件(.md) 与子目录是唯一真源；写门/蒸馏落笔后调本脚本重建所在目录指针表（见 merge_check/write_gate 接入）。

用法:
    python gen_pointer_tables.py <rel_dir>   # 重建指定目录（相对 wiki_root）的指针表（写前 .bak-，仅变化时）
    python gen_pointer_tables.py --all       # 重建全库所有含内容/子目录的目录
    python gen_pointer_tables.py             # 兼容：仅为缺失 _index.md 的目录生成（旧 bootstrap 行为）

零硬编码路径（2026-08-27）：wiki_root 由 __file__ 派生；不再有 Windows 绝对路径/过期板块名单。
"""
import io
import re
import sys
from datetime import date
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
TODAY = date.today().isoformat()
RULES_MARK = "## 目录文件规范"          # 规则块起始标记（其后内容逐字保留）
BACKUP_PREFIX = ".bak-ptr-"


def parse_frontmatter(text: str):
    """解析 frontmatter，返回 (fm_dict, body)。"""
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            fm = {}
            for line in parts[1].splitlines():
                m = re.match(r"^([\w-]+):\s*(.*)$", line.strip())
                if m:
                    fm[m.group(1)] = m.group(2).strip().strip("\"'")
            return fm, parts[2]
    return {}, text


def title_of(md: Path) -> str:
    """条目标题：frontmatter title，退回文件名 stem。"""
    try:
        head = md.read_text(encoding="utf-8", errors="ignore")[:800]
    except Exception:
        return md.stem
    fm, _ = parse_frontmatter(head)
    t = str(fm.get("title", "") or "").strip()
    return t or md.stem


def one_line(md: Path) -> str:
    """一句话摘要：frontmatter description，退回正文首行（去标题/列表符号，≤40 字）。"""
    try:
        text = md.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""
    fm, body = parse_frontmatter(text)
    d = str(fm.get("description", "") or "").strip()
    if d:
        return d[:40]
    for ln in body.splitlines():
        s = ln.strip().lstrip("-* •>#")
        if len(s) >= 4:
            return s[:40]
    return ""


def split_preserved(text: str) -> str:
    """抽取须逐字保留的规则块：`## 目录文件规范` 起至文件尾；无则返回空串。"""
    i = text.find(RULES_MARK)
    if i == -1:
        return ""
    return text[i:].rstrip() + "\n"


def subdir_lines(d: Path, old_text: str) -> list:
    """子目录行：`- [[名]]` + 保留旧行中同名声明的尾部描述（如「— 当日知识暂存」）。"""
    desc = {}
    if old_text:
        for ln in old_text.splitlines():
            m = re.match(r"-\s*\[\[([^\]|]+)(?:\|[^\]]+)?\]\](.*)$", ln.strip())
            if m:
                desc[m.group(1).strip()] = (m.group(2) or "").strip()
    out = []
    for s in sorted([x.name for x in d.iterdir() if x.is_dir() and not x.name.startswith(".")]):
        tail = desc.get(s, "")
        if tail.startswith("—"):
            tail = tail[1:].strip()
        out.append(f"- [[{s}]]" + (f" — {tail}" if tail else ""))
    return out


def build_index(d: Path, old_text: str) -> str:
    """按目录扫描重建 _index.md 内容（索引区全量重建 + 规则块逐字保留）。"""
    entries = sorted(
        [f for f in d.glob("*.md") if f.name != "_index.md"],
        key=lambda p: p.stem,
    )
    lines = [
        "---",
        "type: index",
        f'title: "{d.name} 指针表"',
        f"updated: {TODAY}",
        "---",
        "",
        f"# {d.name}",
        "",
    ]
    if entries:
        lines += ["| 条目 | 摘要 | 链接 |", "| --- | --- | --- |"]
        for e in entries:
            lines.append(f"| {title_of(e)} | {one_line(e)} | [[{e.stem}]] |")
    else:
        lines.append("(暂无条目)")
    subs = subdir_lines(d, old_text)
    if subs:
        lines += ["", "## 子目录", ""]
        lines += subs
    lines.append("")
    preserved = split_preserved(old_text)
    if preserved:
        lines.append(preserved)
    return "\n".join(lines)


def rebuild(d: Path) -> bool:
    """重建目录指针表。仅内容变化时写盘；写前 .bak-ptr- 备份。返回是否发生写入。"""
    if not d.exists():
        return False
    idx = d / "_index.md"
    old = idx.read_text(encoding="utf-8", errors="ignore") if idx.exists() else ""
    new = build_index(d, old)
    if old == new:
        return False
    if old and old.strip():
        (d / f"_index.md{BACKUP_PREFIX}{TODAY}").write_text(old, encoding="utf-8")
    idx.write_text(new, encoding="utf-8")
    return True


def bootstrap(d: Path) -> bool:
    """旧兼容行为：仅为缺失 _index.md 的目录生成（不重建已有）。"""
    if (d / "_index.md").exists():
        return False
    return rebuild(d)


def iter_dirs():
    """遍历 wiki_root 下的内容目录（顶层板块 + 递归子目录）。

    排除基础设施：_meta / validate / .obsidian / .index_cache / .git / __pycache__ 等
    （它们不是记忆板块，不应有指针表）。
    """
    EXCLUDE = {"_meta", "validate", "__pycache__", ".obsidian", ".index_cache", ".git"}
    seen = []
    if not ROOT.exists():
        return seen
    for board in sorted(x for x in ROOT.iterdir() if x.is_dir() and not x.name.startswith(".") and x.name not in EXCLUDE):
        seen.append(board)
        for sub in sorted(board.rglob("*")):
            if not sub.is_dir():
                continue
            try:
                rel = sub.relative_to(ROOT)
            except ValueError:
                continue
            if any(p.startswith(".") or p in EXCLUDE for p in rel.parts):
                continue
            seen.append(sub)
    return seen


def main():
    args = sys.argv[1:]
    H = {"--help", "-h"}
    if args and args[0] in H:
        print(__doc__)
        return 0
    if not args:
        # 旧行为兼容：bootstrap 缺失表
        total = created = 0
        for d in iter_dirs():
            total += 1
            if bootstrap(d):
                created += 1
                print(f"+ {d.relative_to(ROOT)}")
        print(f"\n生成 {created}/{total}")
        return 0
    if args[0] == "--all":
        total = changed = 0
        for d in iter_dirs():
            total += 1
            if rebuild(d):
                changed += 1
                print(f"↻ {d.relative_to(ROOT)} 指针表已重建")
        print(f"\n重建 {changed}/{total}")
        return 0
    rel = args[0].strip("/\\")
    d = (ROOT / rel).resolve()
    try:
        d.relative_to(ROOT)
    except ValueError:
        print(json_err({"error": f"路径越界: {rel}"}))
        return 2
    if rebuild(d):
        print(json_err({"rebuilt": True, "dir": rel}))
    else:
        print(json_err({"rebuilt": False, "dir": rel, "note": "无变化（幂等）"}))
    return 0


def json_err(o):
    import json
    return json.dumps(o, ensure_ascii=False)


if __name__ == "__main__":
    sys.exit(main())