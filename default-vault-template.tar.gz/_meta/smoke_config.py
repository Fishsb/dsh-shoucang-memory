# -*- coding: utf-8 -*-
"""守藏 Phase2 冒烟测试: boards 开关三处一致生效"""
import sys, io, json
from pathlib import Path
sys.path.insert(0, r'D:\lk\FF\shoucang-dev-wiki\_meta\registry')
from udg import shoucang_config
from udg.write_gate import write_wiki_file
from udg.read_gate import search_knowledge, list_by_type

WIKI = Path(r'D:\lk\FF\shoucang-dev-wiki')
CFG = WIKI / 'shoucang.config.yaml'
results = []

def t(name, cond):
    results.append((name, bool(cond)))

# T1 默认(无配置): 全开,memory 可写(用唯一标题避免跨运行去重;正文须≥100字过质量门)
import time
uniq = str(int(time.time()))
body = ("# 临时\n\n这是配置测试用的临时内容,超过一百字符以通过质量门。"
        "补充说明:守藏板块开关要求三处一致生效,包括写入拒绝与检索摘除两条路径,"
        "本段文字仅用于凑足正文字数以满足记忆类条目一百字符的最低门槛要求。") * 2
r1 = write_wiki_file(target_type="memory", title=f"临时开关测试条目-{uniq}",
                     content=body,
                     target="config",
                     frontmatter={"name": f"tmp-switch-test-{uniq}-note"})
t("T1 默认全开 memory 可写", r1.get("status") in ("created", "updated"))

# T2 关闭 memory 板块
CFG.write_text("shoucang:\n  boards:\n    persona: true\n    memory: false\n    wiki: true\n", encoding="utf-8")
r2 = write_wiki_file(target_type="memory", title="应被拒写入",
                     content="# 应拒\n\n这条在 memory 关闭后应当被拒绝写入的正文内容。" * 2,
                     target="config", frontmatter={"name": "should-be-rejected-note"})
t("T2a memory 关闭后拒写", r2.get("status") == "error")
s = search_knowledge("编排器")
t("T2b search 不含 memory 来源", "memory" not in str(s.get("sources", {})))
t("T2c persona 未关仍可列", len(list_by_type("persona")) >= 2)

# T3 regex 兜底解析验证(模拟无 PyYAML)
parsed = shoucang_config._regex_parse(CFG.read_text(encoding="utf-8"))
t("T3 regex兜底解析正确", parsed.get("boards", {}).get("memory") is False)

# T4 恢复默认(T1 已建同名文件,skipped/updated 均证明开关放行到去重检查)
CFG.unlink()
r4 = write_wiki_file(target_type="memory", title=f"临时开关测试条目-{uniq}",
                     content=body,
                     target="config",
                     frontmatter={"name": f"tmp-switch-test-{uniq}-note"})
t("T4 删配置恢复正常", r4.get("status") in ("created", "updated", "skipped"))

ok = all(c for _, c in results)
for name, c in results:
    print(("PASS " if c else "FAIL ") + name)
print("\nSMOKE:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
