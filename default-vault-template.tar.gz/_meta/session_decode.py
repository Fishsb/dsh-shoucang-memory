#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DSH 会话解档（.jsonl.zstd 多帧 → 事件 JSONL）。

用法:
    python session_decode.py <in.jsonl.zstd> [out.jsonl]
    out 缺省 = 输入路径去 .zst* 后缀（stdout 兼容）。
多帧兼容：按 zstd magic 逐帧流式解压；坏帧跳过（容错）。
"""
import sys
from pathlib import Path

sys.stdout = __import__("io").TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

MAGIC = b"\x28\xb5\x2f\xfd"

def decode_frames(data: bytes):
    import zstandard as zstd
    dctx = zstd.ZstdDecompressor()
    reader = zstd.ZstdDecompressor().stream_reader(data) if False else None
    # 逐帧：magic 定位切分
    pos, frames = 0, []
    idxs = []
    start = data.find(MAGIC)
    while start != -1:
        idxs.append(start)
        start = data.find(MAGIC, start + 4)
    idxs.append(len(data))
    for i in range(len(idxs) - 1):
        seg = data[idxs[i]:idxs[i + 1]]
        try:
            frames.append(dctx.decompress(seg, max_output_size=64 * 1024 * 1024))
        except Exception:
            try:
                dobj = zstd.ZstdDecompressor().decompressobj()
                frames.append(dobj.decompress(seg))
            except Exception:
                continue
    return b"".join(frames)

def main():
    if len(sys.argv) < 2:
        print(json_err("需要输入文件"))
        return 2
    src = Path(sys.argv[1])
    data = src.read_bytes()
    out_text = decode_frames(data).decode("utf-8", errors="replace")
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_name(src.name.replace(".zstd", "").replace(".zst", ""))
    dst.write_text(out_text, encoding="utf-8")
    print(f'{{"mode": "decode", "src": "{src.name}", "dst": "{dst.name}", "bytes": {len(out_text)}, "lines": {out_text.count(chr(10))}}}')
    return 0

def json_err(msg: str) -> str:
    import json
    return json.dumps({"error": msg}, ensure_ascii=False)

if __name__ == "__main__":
    rc = 0
    try:
        rc = main()
    except Exception as e:
        print(json_err(str(e)[:200]))
        rc = 1
    sys.exit(rc)