#!/usr/bin/env node
/**
 * rerank_server.cjs — 守藏本地重排服务（R4 · 2026-08-27）
 *
 * 用途：对召回 top-N 候选用 cross-encoder（bge-reranker 类）精排取 top-k。
 * 与 embed_server.cjs 同构（transformers.js 离线加载本地模型 + HTTP 服务）。
 *
 * 调用：node rerank_server.cjs <模型目录> [端口] [日志路径]
 * 模型：Xenova/bge-reranker-base（.dsh/mneme/models 已有资产）或同族 cross-encoder
 *
 * 端点：
 *   GET  /health     → {ok, model}
 *   POST /v1/rerank  → {query, documents:[string]} → {results:[{index,score}]}（分数越高越相关）
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

const MODEL_DIR = process.argv[2];
const PORT = parseInt(process.argv[3], 10) || 9925;
const LOG = process.argv[4] || '';
if (!MODEL_DIR) { console.error('usage: node rerank_server.cjs <modelDir> [port] [log]'); process.exit(2); }

let transformers = null;
try { transformers = require('@huggingface/transformers'); } catch (e) { /* runtime 缺失由部署脚本诊断 */ }
const { env } = transformers || {};

if (env) {
  env.allowRemoteModels = false;
  env.localModelPath = MODEL_DIR;
}

function log(m) {
  if (!LOG) return;
  try { fs.appendFileSync(LOG, new Date().toISOString() + ' ' + m + '\n'); } catch (e) { /* 日志失败无害 */ }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = '';
    req.on('data', (c) => { buf += c; if (buf.length > 8 * 1024 * 1024) { req.destroy(); reject(new Error('body too large')); } });
    req.on('end', () => resolve(buf));
    req.on('error', reject);
  });
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  });
  res.end(body);
}

let tokenizer = null;
let model = null;

function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }

async function scorePairs(query, docs) {
  // cross-encoder 手动推理（transformers.js 批量 text_pair 不兼容 · 逐对前向）
  const scores = new Array(docs.length).fill(0);
  for (let i = 0; i < docs.length; i++) {
    try {
      const inp = await tokenizer(query, docs[i]);
      const out = await model(inp);
      const lg = Array.isArray(out.logits) ? out.logits : (out.logits && out.logits.tolist ? out.logits.tolist() : null);
      const row = lg && lg.length ? lg[0] : [0];
      const logit = Number(row[row.length - 1] || 0);
      scores[i] = Number(sigmoid(logit).toFixed(4));
    } catch (e) {
      scores[i] = 0;
    }
  }
  return scores;
}

async function load() {
  if (!transformers) throw new Error('@huggingface/transformers 缺失：请先部署 runtime');
  const { AutoTokenizer, AutoModelForSequenceClassification } = transformers;
  try {
    tokenizer = await AutoTokenizer.from_pretrained(MODEL_DIR, {});
    model = await AutoModelForSequenceClassification.from_pretrained(MODEL_DIR, { device: 'cpu', dtype: 'q8' });
  } catch (e1) {
    log('q8 load failed: ' + e1.message);
    model = await AutoModelForSequenceClassification.from_pretrained(MODEL_DIR, { device: 'cpu' });
  }
  const probe = await scorePairs('维度自检', ['这是维度自检文档。']);
  log('reranker ready, probe=' + JSON.stringify(probe));
}

async function main() {
  try { await load(); log('server ready on :' + PORT); } catch (e) {
    log('load error: ' + (e && e.message));
    console.error('model load failed: ' + (e && e.message));
    process.exit(3);
  }
  http.createServer(async (req, res) => {
    const url = req.url || '/';
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
      if (req.method === 'GET' && url === '/health') { send(res, 200, { ok: true, model: path.basename(MODEL_DIR) }); return; }
      if (req.method === 'POST' && url === '/v1/rerank') {
        const body = JSON.parse(await readBody(req) || '{}');
        const q = String(body.query || '');
        const docs = Array.isArray(body.documents) ? body.documents.map(String) : [];
        if (!q || !docs.length) { send(res, 400, { error: 'query/documents required' }); return; }
        const scores = await scorePairs(q, docs);
        const results = scores.map((score, i) => ({ index: i, score: typeof score === 'number' ? score : 0 }));
        send(res, 200, { results });
        return;
      }
      send(res, 404, { error: 'not found' });
    } catch (e) {
      log('req error: ' + e.message);
      send(res, 500, { error: e.message });
    }
  }).listen(PORT, '127.0.0.1', () => {
    log('listening on 127.0.0.1:' + PORT);
    console.log(JSON.stringify({ ok: true, port: PORT, model: path.basename(MODEL_DIR) }));
  });
}

main();