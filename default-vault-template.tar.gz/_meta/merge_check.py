#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""守藏合并去重（合并去重设计-v1 规则层·零模型依赖）。

判定：name 键相等 + 正文指纹（CJK bigram Jaccard）分层：
   ≥0.85          → exact_duplicate（仅元数据合并）
   0.4 ≤ j < 0.85 → complement_merge（正文 append「## 补充」+ 元数据）
   其余同名      → suspect（不合并，报告；L2 模型层可插拔处理）
   name 不等：取全目录最高指纹；≥0.85 仍判 duplicate（同义主题），否则 new。

用法:
    python merge_check.py <新文件.md|新文本> --dir <日记忆|环境|工具|规则|参考|配置>
        [--apply] [--vector] [--out <json路径>]
默认 dry-run：只输出判定协议 JSON，不落笔。--apply 才写目标（写前备份 .bak-merge-<ts>）。
"""
import hashlib
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

sys.stdout = __import__("io").TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

WIKI_ROOT = Path(__file__).resolve().parent.parent
MEM_ROOT = WIKI_ROOT / "记忆"


def body_hash(body: str) -> str:
    """正文指纹（CAS revision = sha256 前缀 16）。"""
    return hashlib.sha256(normalize(body).encode("utf-8")).hexdigest()[:16]


def current_revision(text: str) -> str:
    """CAS 权威 revision：**按正文现算**（不信任 frontmatter 字段——正文被外部改动而字段未更新时
    必须判为已变；2026-08-27 修复）。frontmatter `revision` 仅为投影标记，由 with_revision 保持对齐。"""
    _, body = parse_frontmatter(text)
    return body_hash(body)


def with_revision(text: str) -> str:
    """把正文 revision 写入 frontmatter（幂等；无 frontmatter 则补）。"""
    fm, body = parse_frontmatter(text)
    fm["revision"] = body_hash(body)
    return meta_block(fm) + "\n" + body.lstrip("\n")

def parse_frontmatter(text: str):
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            fm = {}
            for line in parts[1].splitlines():
                m = re.match(r"^([\w-]+):\s*(.*)$", line.strip())
                if m:
                    fm[m.group(1)] = m.group(2).strip().strip("\"'")
            return fm, parts[2]
    return {}, text

def normalize(text: str) -> str:
    _pn = set("[]{}()【】《》〈〉「」『』“”‘’、。，；：？！…—·`~!@#$%^&*_+=<>?|\\/\"' ")
    return "".join(ch for ch in text if ch not in _pn and not ch.isspace())

def bigrams(s: str):
    return {s[i:i + 2] for i in range(len(s) - 1)} if len(s) > 1 else {s}

def jaccard(a: str, b: str) -> float:
    A, B = bigrams(normalize(a)), bigrams(normalize(b))
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)

def load_config():
    try:
        import sys as _s
        sys.path.insert(0, str(WIKI_ROOT / "_meta" / "registry" / "udg"))
        import shoucang_config as sc
        return sc.load_config(WIKI_ROOT)
    except Exception:
        return {}

def meta_block(fm: dict) -> str:
    lines = ["---"]
    for k, v in fm.items():
        lines.append(f"{k}: {v}")
    lines.append("---")
    return "\n".join(lines)

def apply_meta(orig: str, add_source: str = "", bump_conf: int = 5, link_ids=None):
    fm, body = parse_frontmatter(orig)
    fm["updated"] = datetime.now().strftime("%Y-%m-%d")
    cur = fm.get("updated", datetime.now().strftime("%Y-%m-%d"))
    fm["updated"] = cur
    src = fm.get("source", "")
    if add_source and add_source not in src:
        fm["source"] = (src + ";" + add_source) if src else add_source
    try:
        conf = min(95, int(fm.get("confidence", 60)) + bump_conf)
    except Exception:
        conf = 65
    fm["confidence"] = conf
    if link_ids:
        fm["linked_memory_ids"] = (fm.get("linked_memory_ids", "") + (";" + link_ids) if fm.get("linked_memory_ids") else link_ids)
    yaml = meta_block(fm)
    return yaml + "\n" + body.lstrip("\n")

def apply_backup(path: Path):
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    bak = path.with_name(path.name + f".bak-merge-{ts}")
    shutil.copy2(path, bak)
    return bak

KNOWN_DIRS = {"日记忆": "记忆/日记忆", "参考": "记忆/参考", "工具": "记忆/工具",
              "规则": "记忆/规则", "环境": "记忆/环境", "配置": "记忆/配置",
              "笔记": "笔记", "归档": "归档"}

def scan_dir(rel_dir: str):
    r = KNOWN_DIRS.get(rel_dir)
    if r is None:
        r = rel_dir if (rel_dir.startswith("记忆/") or rel_dir in ("笔记", "归档")) else "记忆/" + rel_dir
    d = WIKI_ROOT / r
    if not d.exists():
        return []
    rows = []
    for md in d.glob("*.md"):
        if md.name == "_index.md":
            continue
        try:
            text = md.read_text(encoding="utf-8")
        except Exception:
            continue
        fm, body = parse_frontmatter(text)
        rows.append({"path": md, "name": str(fm.get("name", "") or ""), "title": str(fm.get("title", "") or ""),
                     "body": body, "text": text, "superseded": bool(fm.get("superseded_at")),
                     "rev": current_revision(text)})
    return rows


def cas_guard(row) -> str:
    """CAS 复验（借鉴 mnemon Runtime sha256 revision 写门）：扫描后目标是否被并发修改过。

    返回 None=通过；否则返回冲突说明（调用方必须中止本次写入）。
    """
    try:
        live = row["path"].read_text(encoding="utf-8")
    except Exception:
        return "读取失败"
    if current_revision(live) != row["rev"]:
        return f"revision 不匹配（扫描 {row['rev']} vs 当前 {current_revision(live)}）"
    return None


def _rebuild_ptr(rel_dir: str) -> str:
    """写门落笔后投影重建所在目录指针表（真源+投影 · 2026-08-27 接入）。

    条目/子目录是唯一真源，_index.md 索引区由 gen_pointer_tables 确定性重建，
    规则块（## 目录文件规范）逐字保留。失败不阻断写门，仅提示。
    """
    try:
        import subprocess
        import sys as _s
        r = KNOWN_DIRS.get(rel_dir)
        ptr_rel = r if r else (rel_dir if (rel_dir.startswith("记忆/") or rel_dir in ("笔记", "归档")) else "记忆/" + rel_dir)
        script = Path(__file__).resolve().parent / "gen_pointer_tables.py"
        run = subprocess.run([_s.executable, str(script), ptr_rel],
                             capture_output=True, text=True, encoding="utf-8", timeout=60)
        return (run.stdout or "").strip()
    except Exception:
        return ""

def decide(new_name: str, new_body: str, rows: list, thr: float = 0.85, floor: float = 0.4):
    """规则层判定。返回 (decision, target_row|None, evidence, by)"""
    if new_name:
        exact = [r for r in rows if r["name"] == new_name]
        if exact:
            active = [r for r in exact if not r.get("superseded")]
            target = active[0] if active else exact[0]
            j = jaccard(new_body, target["body"])
            if j >= thr:
                return ("exact_duplicate", target, {"name_equal": True, "jaccard": round(j, 4)}, "rule")
            if j >= floor:
                return ("complement_merge", target, {"name_equal": True, "jaccard": round(j, 4)}, "rule")
            return ("suspect", target, {"name_equal": True, "jaccard": round(j, 4), "note": "同名低重合：疑似改版/矛盾，写门默认走时序 supersede（旧条目标记不删）"}, "rule")
    best, best_j = None, 0.0
    for r in rows:
        j = jaccard(new_body, r["body"])
        if j > best_j:
            best, best_j = r, j
    if best and best_j >= thr:
        return ("exact_duplicate", best, {"name_equal": False, "jaccard": round(best_j, 4), "note": "跨名高重合：同义主题建议统一 name"}, "rule")
    return ("new", None, {"name_equal": False, "jaccard": round(best_j, 4) if best else 0.0}, "rule")

def merge_check(source: str, rel_dir: str, apply: bool = False, vector: bool = False, out=None,
                supersede: bool = True):
    fm, body = parse_frontmatter(source)
    new_name = str(fm.get("name", "") or "")
    new_title = str(fm.get("title", "") or new_name)
    new_subtype = str(fm.get("subtype", "") or "")
    cfg = load_config().get("merge", {})
    thr = float(cfg.get("fingerprint_threshold", 0.85))
    floor = float(cfg.get("complement_floor", 0.4))
    rows = scan_dir(rel_dir)
    decision, target, ev, by = decide(new_name, body, rows, thr, floor)
    plan = []
    if apply:
        if decision in ("exact_duplicate", "complement_merge") and target:
            clash = cas_guard(target)
            if clash:
                plan.append(f"CAS 冲突：{target['path'].name} {clash} → 未落笔（并发写保护）")
                decision = "cas_conflict"
            else:
                bak = apply_backup(target["path"])
                plan.append(f"备份: {bak.name}")
                new_txt = target["text"]
                if decision == "complement_merge":
                    new_txt += f"\n## 补充（{datetime.now().strftime('%Y-%m-%d')}）\n{body.strip()}\n"
                new_txt = apply_meta(new_txt, add_source=new_subtype, link_ids=new_name)
                new_txt = with_revision(new_txt)
                target["path"].write_text(new_txt, encoding="utf-8")
                plan.append(f"已合并 → {target['path'].relative_to(WIKI_ROOT).as_posix()}")
        elif decision == "suspect" and target and supersede:
            clash = cas_guard(target)
            if clash:
                plan.append(f"CAS 冲突：{target['path'].name} {clash} → 未落笔（并发写保护）")
                decision = "cas_conflict"
            else:
                # 矛盾时序 supersede（Zep 风格：旧条目标记不删）：旧条目 superseded_at + 新条目 supersedes
                bak = apply_backup(target["path"])
                plan.append(f"备份(旧): {bak.name}")
                old_txt = target["text"]
                fm_o, _ = parse_frontmatter(old_txt)
                fm_o["superseded_at"] = datetime.now().strftime("%Y-%m-%d")
                target["path"].write_text(with_revision(meta_block(fm_o) + "\n" + old_txt.split("---", 2)[2].lstrip("\n") if old_txt.startswith("---") else old_txt), encoding="utf-8")
                plan.append(f"旧条目标记 superseded_at → {target['path'].relative_to(WIKI_ROOT).as_posix()}")
                decision = "supersede"
                # 新条目落地（含 supersedes 链）
                write_new(source, rel_dir, fm, body, new_name, new_title, new_subtype, target["name"], plan)
        elif decision == "new":
            write_new(source, rel_dir, fm, body, new_name, new_title, new_subtype, None, plan)
        else:
            plan.append("未落笔（suspect 且 --no-supersede）")
        if decision != "cas_conflict":
            ptr = _rebuild_ptr(rel_dir)
            if ptr:
                plan.append(f"指针投影: {ptr}")
    result = {
        "mode": "APPLY" if apply else "DRY-RUN",
        "cmd": "merge_check",
        "dir": rel_dir,
        "decision": decision,
        "by": by,
        "evidence": ev,
        "target": target["path"].relative_to(WIKI_ROOT).as_posix() if target else None,
        "plan": plan,
        "threshold": {"fingerprint": thr, "complement_floor": floor},
        "at": datetime.now().isoformat(timespec="seconds"),
    }
    if vector:
        try:
            # 2b（落地方案 · 评估口径 2026-08-27）：向量仅作 evidence 建议，绝不自动落笔。
            # new 决策无 target → 对比 jaccard 最高候选行（best）；仅当 best_j∈[0.15,0.4)
            # 且 sim≥0.82 时升格为「建议 L2 模型层复核同义合并」。无关对（jaccard≈0）被排除；
            # 反义对（对称向量模型无法区分）会命中 suggested——其语义就是「交 L2 裁决」，由模型层否决。
            if decision == "new":
                best_row, best_j2 = None, 0.0
                for r in rows:
                    j = jaccard(body, r["body"])
                    if j > best_j2:
                        best_row, best_j2 = r, j
                if best_row:
                    sim = _vector_sim(body, best_row["body"])
                    result["evidence"]["vector_sim"] = sim
                    if 0.15 <= best_j2 < 0.4 and sim >= 0.82:
                        result["evidence"]["suggested"] = {
                            "action": "L2_review_synonym_merge",
                            "reason": f"jaccard={round(best_j2,3)}∈[0.15,0.4) 且 vector_sim={sim}≥0.82：疑似同义改写，建议 L2 复核并入 {best_row['path'].relative_to(WIKI_ROOT).as_posix()}（不自动落笔；反义会被 L2 否决）",
                        }
                else:
                    result["evidence"]["vector_sim"] = -1
            else:
                result["evidence"]["vector_sim"] = _vector_sim(new_body, target["body"] if target else "")
        except Exception:
            result["evidence"]["vector_sim"] = -1
    text = json.dumps(result, ensure_ascii=False, indent=1)
    print(text)
    if out:
        Path(out).write_text(text, encoding="utf-8")
    return result


def write_new(source: str, rel_dir: str, fm: dict, body: str, name: str, title: str, subtype: str,
              supersedes: str or None, plan: list):
    """写门：new/supersede 时把候选落盘到目标目录（文件名=name 或标题，幂等去重文件名）"""
    d = WIKI_ROOT / KNOWN_DIRS.get(rel_dir, rel_dir if rel_dir.startswith("记忆/") else "记忆/" + rel_dir)
    d.mkdir(parents=True, exist_ok=True)
    stem = name if name else (title or "untitled")
    stem = re.sub(r"[\\/:*?\"<>|]", "-", stem)
    out_p = d / (stem + ".md")
    n = 1
    while out_p.exists():
        out_p = d / f"{stem}-{n}.md"
        n += 1
    nf = dict(fm)
    nf.pop("name", None)
    nf["name"] = stem
    nf["title"] = title or stem
    nf["revision"] = body_hash(body)  # CAS 写门：新文件即刻携带正文 revision（2026-08-27）
    if supersedes:
        nf["supersedes"] = supersedes
    out_p.write_text(meta_block(nf) + "\n" + body.lstrip("\n") + "\n", encoding="utf-8")
    plan.append(f"已写入 → {out_p.relative_to(WIKI_ROOT).as_posix()}")
    return out_p

def _vector_sim(a: str, b: str) -> float:
    import sys as _s
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import vector_search as vs
    cfg = vs.load_embedding_cfg()
    if not cfg or not b:
        return -1.0
    va, vb = vs.embed([normalize(a)[:1000], normalize(b)[:1000]], cfg)
    return round(vs.cosine(va, vb), 4)

def main():
    args = sys.argv[1:]
    if not args or "--help" in args or "-h" in args:
        print(__doc__)
        return 0
    src = args[0]
    rel_dir = ""
    if "--dir" in args:
        rel_dir = args[args.index("--dir") + 1]
    if not rel_dir:
        print(json.dumps({"error": "需要 --dir（日记忆 | 记忆/参考 | 参考 …）"}, ensure_ascii=False))
        return 2
    apply = "--apply" in args
    vector = "--vector" in args
    supersede = "--no-supersede" not in args
    out = ""
    if "--out" in args:
        out = args[args.index("--out") + 1]
    p = Path(src)
    source = p.read_text(encoding="utf-8") if p.exists() else src
    merge_check(source, rel_dir, apply=apply, vector=vector, out=out, supersede=supersede)
    return 0

if __name__ == "__main__":
    sys.exit(main())