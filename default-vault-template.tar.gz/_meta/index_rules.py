# -*- coding: utf-8 -*-
"""
index_rules.py — 归档合规规则（2026-08-27 定稿）
================================================================
规则：整个归档逻辑必须以**每个目录的 `_index.md`** 规定的格式为权威约束——
归档/写入路径必须满足目标目录 `_index.md` 的格式；**不符合 → 扩展目录类型**：
创建缺失的类型目录 + 同步登记到父目录 `_index.md`（备份先行，幂等）。

**扩展前置（2026-08-27 定稿）**：扩展目录类型**必须先网络检索**——
按 `记忆/_index.md` 规则框架 + 新类型，web_search/read_page 补全该类型
`_index.md` 的「目录文件规范」块，**禁止不检索直接扩展**。
`ensure-researched` 命令接收检索结论（--summary）后建目录 + 写规范 + 登记父表。

用法（供管线脚本 import）：
    import index_rules as ir
    d = ir.ensure_type_dir(parent, "新类型", summary="一句话", apply=APPLY)
    ok, why = ir.validate(rel, ir.read_index(parent))

命令行：
    python index_rules.py --dry-run <parent> <type>            # 展示将扩展
    python index_rules.py --ensure-researched <parent> <type> --summary <检索结论>
                                                                # 检索后补全（建目录+写 _index 规范+登记父表）
"""
import io
import json
import sys
from pathlib import Path
from datetime import datetime

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")


def read_index(parent: Path) -> str:
    """读取目录 _index.md（目录格式权威），不存在返回空。"""
    try:
        return (parent / "_index.md").read_text(encoding="utf-8")
    except Exception:
        return ""


def _backup(parent: Path) -> None:
    try:
        idx = parent / "_index.md"
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        (parent / f"_index.md.bak-{stamp}").write_text(idx.read_text(encoding="utf-8"), encoding="utf-8")
    except Exception:
        pass


def ensure_type_dir(parent: Path, type_name: str, summary: str = "", apply: bool = True) -> Path:
    """扩展目录类型（幂等）：类型目录缺失则创建，并在父目录 _index.md 登记。

    - 目录已存在且已登记 → 原样返回
    - 目录缺失 → 创建（apply 时）+ 登记
    - 目录存在但 _index.md 未登记 → 补登记（apply 时）
    写 _index.md 前先备份（守藏惯例：写前 .bak-）。
    """
    type_name = str(type_name).strip("/\\")
    if not type_name:
        return parent
    d = parent / type_name
    text = read_index(parent)
    registered = bool(text) and (type_name in text)
    if d.exists() and registered:
        return d
    if d.exists():
        if apply:
            _backup(parent)
            text = text.rstrip("\n") + "\n" + _entry_line(type_name, summary) + "\n"
            (parent / "_index.md").write_text(text, encoding="utf-8")
            print(f"[index_rules] 补登记目录类型: {type_name} → {parent / '_index.md'}")
        else:
            print(f"[index_rules](dry) 将补登记目录类型: {type_name} → {parent / '_index.md'}")
        return d
    if apply:
        d.mkdir(parents=True, exist_ok=True)
        print(f"[index_rules] 扩展目录类型: {d}")
        _backup(parent)
        if not text:
            text = ("---\ntype: index\n"
                    f'title: "{parent.name} 目录类型"\n'
                    f"updated: {datetime.now().strftime('%Y-%m-%d')}\n"
                    "---\n\n# {}\n\n".format(parent.name))
        text = text.rstrip("\n") + "\n" + _entry_line(type_name, summary) + "\n"
        (parent / "_index.md").write_text(text, encoding="utf-8")
    else:
        print(f"[index_rules](dry) 将扩展目录类型: {d}")
    return d


def _entry_line(type_name: str, summary: str) -> str:
    base = f"- {type_name}"
    return f"{base} — {summary}" if summary else base


def validate(rel: str, rules_text: str):
    """写路径合规校验（轻量）：入口目录是否被 _index.md 登记。

    返回 (ok, reason)：不满足时 reason 建议「扩展目录类型」。
    """
    if not rules_text:
        return False, f"缺少 {rel} 的 _index.md（目录格式权威缺失，需先建立）"
    head = rel.split("/")[0]
    if head not in rules_text and rel not in rules_text:
        return False, f"目录类型 {head} 未登记于 _index.md（不符合 → 应扩展目录类型）"
    return True, ""


def researched_type_index(parent: Path, type_name: str, summary: str) -> str:
    """按 记忆/_index.md 规则框架生成新类型 _index.md（检索结论 --summary 为规范依据）。"""
    today = datetime.now().strftime("%Y-%m-%d")
    return (
        "---\ntype: index\n"
        f'title: "{type_name} 指针表"\n'
        f"updated: {today}\n"
        "---\n\n"
        f"# {type_name}\n\n"
        "(暂无条目)\n\n"
        "## 目录文件规范（{type}）\n\n".format(type=type_name) +
        f"> 依据：网络检索（2026-08-27 扩展前置规则）——{summary}\n\n"
        f"- 职责：{type_name} 类长期记忆（archive-daily subtype={type_name}→{type_name}）\n"
        f"- 文件类型：`type: memory`，subtype 固定 `{type_name}`，stage=`settled`\n"
        "- frontmatter 必填：`type / name / title / subtype / stage / confidence / created / updated / description`\n"
        "- 正文：≥100 字、自包含、不脱库引用；跨条目只用 `[[wiki-link]]`\n"
        "- 维护：write_gate 或 archive-daily 落库；本表指针由 write_gate/archive-daily 维护；不符规则 → 扩展目录类型并登记\n\n"
    )


def ensure_researched(parent: Path, type_name: str, summary: str) -> dict:
    """扩展前置（检索后调用）：建新类型目录 + 写检索补全的 _index.md 规范 + 登记父 _index.md；备份先行幂等。"""
    type_name = str(type_name).strip("/\\")
    out = {"type": type_name, "parent": str(parent), "created_dir": False, "index_written": False, "parent_registered": bool(ensure_type_dir(parent, type_name, f"{type_name} 类", apply=True).exists())}
    d = parent / type_name
    if not d.exists():
        d.mkdir(parents=True, exist_ok=True)
        out["created_dir"] = True
    idx = d / "_index.md"
    if not idx.exists():
        _backup(parent)
        idx.write_text(researched_type_index(parent, type_name, summary), encoding="utf-8")
        out["index_written"] = True
    return out


def _cli():
    args = sys.argv[1:]
    if args and args[0] == "--ensure-researched":
        if len(args) < 5 or "--summary" not in args:
            print("用法: python index_rules.py --ensure-researched <parent> <type> --summary <检索结论>")
            return 2
        parent = Path(args[1])
        type_name = args[2]
        summary = args[args.index("--summary") + 1]
        print(json.dumps(ensure_researched(parent, type_name, summary), ensure_ascii=False, indent=1))
        return 0
    dry = "--dry-run" in args
    args = [a for a in args if a != "--dry-run"]
    if len(args) < 2:
        print("用法: python index_rules.py [--dry-run] <parent> <type> [summary] | --ensure-researched <parent> <type> --summary <结论>")
        return 2
    parent = Path(args[0])
    ensure_type_dir(parent, args[1], args[2] if len(args) > 2 else "", apply=not dry)
    return 0


if __name__ == "__main__":
    sys.exit(_cli())