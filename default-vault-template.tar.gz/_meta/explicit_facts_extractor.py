#!/usr/bin/env python3
"""
explicit_facts_extractor.py — 会话显式内容提取器（Phase 7 第②项 · idle-review 契约 v1.1 预处理）

作用：fork 蒸馏子代理**之前**，把会话记录压缩为「显式内容清单」(Explicit Facts Sheet)——
只收会话中**明确陈述且可引用**的断言（事实/偏好/方法论/稳定结论），每条带来源引用并按板块类型预归类。
子代理以清单为权威输入，会话记录仅作按需回溯（idle-review任务契约-v1.md §预处理输入）。

两种模式（archive.pre_extract.method）:
    rules: 零 LLM 机械提取(默认)——正则规则抽取"明确断言句", 按关键词预归类到 画像/记忆/wiki
    llm  : 轻量 LLM 提取(独立预算≤1次, 计入存档事件预算总额)——本脚本仅留接口, LLM 由宿主注入

输入: 会话记录文本(JSON 或纯文本)
输出: {"facts": [{"text","type","board","source_ref"}], "empty": bool}

零硬编码路径、零第三方依赖。纯规则提取，可离线运行。
用法:
    python explicit_facts_extractor.py <session_text_file> [--mode rules|llm]
    # 或作为模块: from explicit_facts_extractor import extract_facts
"""
import io
import json
import re
import sys
from pathlib import Path
from datetime import datetime

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

# 防重蒸馏标记（2026-08-27）：双保险 = ①注册表 _meta/.distilled-sessions.json ②蒸馏条目 frontmatter `source: <session>`
WIKI_ROOT = Path(__file__).resolve().parent.parent
MARKER_FILE = Path(__file__).resolve().parent / ".distilled-sessions.json"


def already_distilled(session_id: str) -> bool:
    """会话是否已蒸馏过：先查注册表，再扫描 画像|记忆|笔记|归档 下条目 frontmatter source。

    命中即 True —— 供提取器在「整理显式内容」阶段截断，避免重复蒸馏。
    """
    if not session_id:
        return False
    try:
        reg = json.loads(MARKER_FILE.read_text(encoding="utf-8"))
        if any(s.get("id") == session_id for s in reg.get("sessions", [])):
            return True
    except Exception:
        pass
    for board in ("画像", "记忆", "笔记", "归档"):
        base = WIKI_ROOT / board
        if not base.exists():
            continue
        for md in base.rglob("*.md"):
            if md.name == "_index.md":
                continue
            try:
                head = md.read_text(encoding="utf-8")[:600]
            except Exception:
                continue
            m = re.search(r"^source\s*:\s*[\"']?([^\s\"']+)[\"']?\s*$", head, re.M)
            if m and m.group(1) == session_id:
                return True
    return False


def mark_distilled(session_id: str, entries=None, cutoff=None) -> dict:
    """蒸馏落库后登记标记（注册表 upsert）。cutoff=本次已处理到的最大消息 seq（增量蒸馏边界）。"""
    reg = {"version": 1, "sessions": []}
    try:
        reg = json.loads(MARKER_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    reg["sessions"] = [s for s in reg.get("sessions", []) if s.get("id") != session_id]
    reg["sessions"].append({"id": session_id, "at": now, "cutoff": cutoff, "entries": entries or []})
    MARKER_FILE.write_text(json.dumps(reg, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": session_id, "at": now, "cutoff": cutoff, "entries": entries or [], "status": "marked"}


def _registry_record(session_id: str):
    try:
        reg = json.loads(MARKER_FILE.read_text(encoding="utf-8"))
        for s in reg.get("sessions", []):
            if s.get("id") == session_id:
                return s
    except Exception:
        pass
    return None

# 板块类型 → 关键词(预归类; 与 registry.yaml domains 对齐)
BOARD_KEYWORDS = {
    "persona": ["偏好", "喜欢", "不喜欢", "习惯", "风格", "协作", "边界", "prefer", "习惯"],
    "记忆": ["事实", "环境", "方法", "步骤", "配置", "参考", "工具", "规则", "发现", "结论"],
    "wiki": ["流程", "工作流", "清单", "技能", "指南", "预skill", "方法论"],
}

# 明确断言句模式: 陈述句式(含"是/为/意为/表示/指/采用/使用/存在/有/源自/来自"等判断谓词)
ASSERT_PATTERNS = [
    r"[^。！？\n]*?(?:是|为|意为|表示|指|指的是|采用|使用|基于|存在|有|源自|来自|由于|因为|所以|因此|必须|需要|应该|建议|推荐)[^。！？\n]*[。！？]?",
    r"[^。！？\n]*?(?:偏好|喜欢|不喜欢|习惯|边界|约定|规则|原则)[^。！？\n]*[。！？]?",
]

def _extract_asserts(text: str) -> list:
    """用正则抽取候选断言句（零 LLM 机械提取）。"""
    cands = []
    seen = set()
    for pat in ASSERT_PATTERNS:
        for m in re.finditer(pat, text):
            s = m.group(0).strip()
            if len(s) < 8:  # 太短的碎片跳过
                continue
            if s in seen:
                continue
            seen.add(s)
            cands.append(s)
    return cands

def _classify(s: str) -> str:
    """按关键词预归类到板块。"""
    best, best_score = "记忆", 0
    for board, kws in BOARD_KEYWORDS.items():
        cnt = sum(1 for k in kws if k in s)
        if cnt > best_score:
            best, best_score = board, cnt
    return best

def _is_garbage(s: str) -> bool:
    """质量门（2026-08-27 风暴修复）：过滤系统提示/工具 schema/JSON 碎片，非正文断言。

    风暴案例：空闲巩固把会话导出 JSONL 当纯文本跑正则，工具描述「参数 = 包名子串」、
    JSON 残片「},{"type":"text"」被当事实落库。本门在提取端拦截：
    - 过短(<12)/过长(>400)、无 CJK 正文、纯标点/符号碎片
    - 工程残迹：代码标识符、HTTP 方法路径、JSON 结构符号
    """
    if len(s) < 12 or len(s) > 400:
        return True
    if "\n" in s:
        return True  # 多行片段（表格行/newsfeed 拼接）一律不收，断言必须单行
    if s.lstrip().startswith("|") or " | " in s:
        return True  # markdown 表格行
    if "`" in s:
        return True  # 反引号代码/文件名引用（回声碎片类 · 2026-08-27）
    if not re.search(r"[。！？]$", s):
        return True  # 必须以句号/叹号/问号收尾（碎片行「…、」「…：」「…，」穿透修复）
    cjk = sum(1 for ch in s if "\u4e00" <= ch <= "\u9fff")
    if cjk == 0:
        return True
    if re.match(r"^[\s\-*,:.;#|>()!？。，、：；·—`=]+", s) and cjk < 4:
        return True
    ENG_RE = re.compile(
        r"(dev_stage_|browser_|job_output|job_kill|dev_reload|dev_inject|"
        r"shoucang_route|shoucang_verify|read_page|x_search|library_search|"
        r"(GET|POST)\s+/api|function\s*\(|=>|\brequire\(|window\.|node_modules|"
        r"\{\s*\"|\}\s*,|--[a-z-]{3,}|\bschema\b|freed=\d|wss://)", re.I)
    if ENG_RE.search(s):
        return True
    return False


def _facts_from_text(text: str, mode: str) -> dict:
    asserts = _extract_asserts(text)
    facts = []
    seen_fp = []  # 近重指纹去重（CJK bigram Jaccard>0.6 视为重复）
    dropped = 0

    def _fp(s):
        clean = "".join(ch for ch in s if "\u4e00" <= ch <= "\u9fff")
        return {clean[i:i + 2] for i in range(len(clean) - 1)} or {clean}

    def _near_dup(fp):
        for prev in seen_fp:
            inter = len(fp & prev)
            union = len(fp | prev)
            if union and inter / union > 0.6:
                return True
        return False

    MAX_FACTS = 20  # 单次蒸馏产出上限（防风暴失控；超出丢弃计数）
    for i, s in enumerate(asserts):
        s = s.strip()
        if _is_garbage(s):
            dropped += 1
            continue
        fp = _fp(s)
        if len(s) >= 20 and _near_dup(fp):
            dropped += 1
            continue
        if len(facts) >= MAX_FACTS:
            dropped += 1
            continue
        seen_fp.append(fp)
        facts.append({
            "text": s,
            "type": "explicit",
            "board": _classify(s),
            "source_ref": f"session-assert-{i+1}",
        })
    return {"mode": mode, "facts": facts, "empty": len(facts) == 0,
            "filtered": dropped, "cap": MAX_FACTS}


def _activity_rows(rows: list) -> list:
    """活动记分门（借鉴 mnemon idle 实质内容门 · 2026-08-27）：

    - 角色字符门槛：user ≥ user_min_chars / assistant ≥ assistant_min_chars（默认 40/60），
      短消息（打招呼/工具噪声回声）不进入蒸馏；
    - 「不要记」类否决语句逐条过滤（用户显式意图优先）；
    - **注入块防回环（落地方案 1a · 2026-08-27）**：含守藏 R1 注入块标记
      （`[守藏·热记忆]` / `shoucang-hot`）的消息整条跳过——自己的注入输出永不回流成事实；
    阈值可由 shoucang.config.yaml §shoucang.distill.activity 覆盖（0=关闭该门槛）。
    """
    umin = 40   # 用户消息门槛：滤问候/应答（≤10字），保留实质短结论（2026-08-27 定档）
    amin = 60   # 助手消息门槛：长助手消息的碎片由断言级质量门拦截，此处只滤极短回声
    try:
        import sys as _s
        reg = Path(__file__).resolve().parent / "registry" / "udg"
        if str(reg) not in _s.path:
            _s.path.insert(0, str(reg))
        import shoucang_config as _sc
        act = _sc.load_config(WIKI_ROOT).get("distill", {}).get("activity", {}) or {}
        umin = float(act.get("user_min_chars", umin))
        amin = float(act.get("assistant_min_chars", amin))
    except Exception:
        pass
    VETO = re.compile(r"不要记|别记|不用记|勿记|别写进记忆|无需记录|不必记录|别惦记")
    FLAG = re.compile(r"\[守藏·热记忆\]|shoucang-hot|守藏热记忆")  # 注入块标记防回环（1a）
    out = []
    for r in rows:
        t = str(r.get("text", "") or "").strip()
        if VETO.search(t) or FLAG.search(t):
            continue
        tlen = len(t)
        if r.get("role") == "user" and umin > 0 and tlen < umin:
            continue
        if r.get("role") == "assistant" and amin > 0 and tlen < amin:
            continue
        out.append(r)
    return out


def _looks_jsonl(src: Path) -> bool:
    """文件是否 JSONL 会话导出（首行可解析为事件对象）。防活动门过滤后回退原文跑正则。"""
    try:
        raw = src.read_text(encoding="utf-8", errors="ignore").lstrip("\ufeff")  # BOM 防御（2026-08-27）
        first = next((l for l in raw.splitlines() if l.strip()), "")
        o = json.loads(first)
        return isinstance(o, dict) and "data" in o and "type" in o
    except Exception:
        return False


def _messages_from_jsonl(src: Path) -> list:
    """会话事件 JSONL → 消息行（seq/time/role/text），用于增量蒸馏按 cutoff 截断。"""
    rows = []
    try:
        raw = src.read_text(encoding="utf-8", errors="ignore").lstrip("\ufeff")  # BOM 防御（2026-08-27）
        lines = raw.splitlines()
    except Exception:
        return rows
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            o = json.loads(line)
        except Exception:
            continue
        if not o or not isinstance(o.get("data"), dict):
            continue
        t = o.get("type")
        if t not in ("user/message", "assistant/message"):
            continue
        content = o["data"].get("content")
        if not isinstance(content, list):
            content = (o["data"].get("message") or {}).get("content") or []
        texts = [c.get("text", "") for c in content
                 if isinstance(c, dict) and c.get("type") == "text" and isinstance(c.get("text"), str)]
        text = "\n".join(texts).strip()
        if text:
            rows.append({"seq": o.get("seq") or 0, "time": o.get("time") or 0,
                         "role": "user" if t == "user/message" else "assistant", "text": text})
    return rows


def extract_facts(text: str, mode: str = "rules", session: str = "") -> dict:
    """主入口: 会话文本 → 显式内容清单。

    session 非空且该会话已蒸馏过：
      - 无 --cutoff → 不静默跳过也不全量重提，返回 needs_cutoff（请传增量边界，防错判）
      - 有 --cutoff → 走增量蒸馏（main 内实现，按 seq 截断只处理新消息）
    """
    if mode == "llm":
        return {"mode": "llm", "facts": [], "empty": True,
                "note": "llm 模式需宿主注入 LLM 提取，此接口仅契约占位"}
    if session and already_distilled(session):
        return {"mode": mode, "facts": [], "empty": True,
                "already_distilled": True, "needs_cutoff": True,
                "session": session,
                "note": "会话已蒸馏过；新产生的显式内容请用 --cutoff <seq> 增量蒸馏（只处理新消息），避免误判旧内容"}
    return _facts_from_text(text, mode)


def _apply_confirm():
    """lifecycle.archive.apply_confirm：默认需确认 → 蒸馏附带只跑 DRY；显式 --apply 仍执行（R4）。"""
    try:
        import sys as _s
        sys_mod = _s
        reg = Path(__file__).resolve().parent.parent / "_meta" / "registry" / "udg"
        sys_mod.path.insert(0, str(reg))
        import shoucang_config as _sc
        arc = _sc.load_config(WIKI_ROOT_OF_DISTILL()).get("lifecycle", {}).get("archive", {})
        return bool(arc.get("apply_confirm", True))
    except Exception:
        return True


def WIKI_ROOT_OF_DISTILL():
    return Path(__file__).resolve().parent.parent

def _attach_merge(facts):
    """蒸馏 advisory（合并去重设计-v1）：每条事实附带 merge 判定（dry-run，不落笔）"""
    try:
        import sys as _s
        _mc_dir = Path(__file__).resolve().parent
        if str(_mc_dir) not in _s.path:
            _s.path.insert(0, str(_mc_dir))
        import merge_check as _mc
        rows = _mc.scan_dir("日记忆")
        cfg = _mc.load_config().get("merge", {})
        thr = float(cfg.get("fingerprint_threshold", 0.85))
        floor = float(cfg.get("complement_floor", 0.4))
        for f in facts:
            d, tgt, ev, by = _mc.decide("", str(f.get("text", "") or ""), rows, thr, floor)
            f["merge"] = {"decision": d, "by": by,
                          "target": tgt["path"].relative_to(_mc.WIKI_ROOT).as_posix() if tgt else None,
                          "jaccard": ev.get("jaccard")}
    except Exception:
        pass



def _extract_llm(src: Path):
    """llm 模式实装（R4）：读 shoucang.distill.llm 的 OpenAI 兼容端点提取断言；未配置则提示。"""
    try:
        text = src.read_text(encoding="utf-8")
    except Exception as e:
        print(json.dumps({"mode": "llm", "facts": [], "empty": True, "error": f"读取失败: {e}"}, ensure_ascii=False))
        return 0
    cfg = {}
    try:
        import sys as _s
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "_meta" / "registry" / "udg"))
        import shoucang_config as _sc
        cfg = _sc.load_config(WIKI_ROOT_OF_DISTILL()).get("distill", {}).get("llm", {}) or {}
    except Exception:
        pass
    if not cfg.get("enabled") or not cfg.get("base_url"):
        print(json.dumps({"mode": "llm", "facts": [], "empty": True,
                          "note": "llm 模式未启用：请在 shoucang.config.yaml §shoucang.distill.llm 配置 enabled/base_url/model/api_key（OpenAI 兼容端点）"}, ensure_ascii=False))
        return 0
    try:
        import json as _j, urllib.request as _u
        prompt = ("你是守藏的蒸馏器。把下面的会话内容整理为可归档断言列表，仅输出 JSON 数组，元素形如 "
                  '{"text": "断言正文(≥20字，含关键事实/配置/环境/边界)", "type": "fact|decision|config", "confidence": 60}。'
                  "不要输出其他文字。\n\n会话内容：\n" + text[:12000])
        payload = _j.dumps({"model": cfg.get("model") or "", "messages": [
            {"role": "system", "content": "你是守藏蒸馏器，只输出 JSON 数组。"},
            {"role": "user", "content": prompt}]}).encode("utf-8")
        req = _u.Request(cfg["base_url"] + "/chat/completions", data=payload,
                         headers={"Content-Type": "application/json",
                                  "Authorization": "Bearer " + (cfg.get("api_key") or "")})
        with _u.urlopen(req, timeout=90) as resp:
            out = _j.loads(resp.read().decode("utf-8"))
        content = (out.get("choices") or [{}])[0].get("message", {}).get("content", "")
        raw = content.strip()
        if raw.startswith("```"):
            raw = raw.strip("`").split("\n", 1)[-1]
        entries = _j.loads(raw) if raw.startswith("[") else []
        facts = [{"text": e.get("text", ""), "type": e.get("type", "fact"), "confidence": int(e.get("confidence", 60))}
                 for e in entries if isinstance(e, dict) and e.get("text")]
        print(json.dumps({"mode": "llm", "facts": facts, "empty": not facts}, ensure_ascii=False, indent=1))
    except Exception as e:
        print(json.dumps({"mode": "llm", "facts": [], "empty": True, "error": f"LLM 调用失败: {e}"}, ensure_ascii=False))
    return 0


def _archive_check_after_distill():
    """每次蒸馏执行时触发日计划归档检查（apply_confirm=true 时仅 DRY 报告；失败不回滚蒸馏，仅警告）。"""
    try:
        import subprocess, sys as _s
        py = _s.executable
        script = Path(__file__).resolve().parent / "lifecycle_settle.py"
        confirm = _apply_confirm()
        args = [py, str(script), "archive-daily", "--apply"] if not confirm else [py, str(script), "archive-daily"]
        r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", timeout=120)
        tail = (r.stdout or "").strip().splitlines()[-1] if (r.stdout or "").strip() else (r.stderr or "").strip()[-120:]
        note = "" if not confirm else "（apply_confirm=true：仅 DRY 报告，需显式 --apply 归档）"
        print(f"[distill] 归档日计划检查: exit={r.returncode}{note} {str(tail)[:140]}", file=_s.stderr)
        # R1：归档/蒸馏跑批后清理向量索引中的失效条目
        try:
            vs_dir = Path(__file__).resolve().parent
            sys_mod = _s
            sys_mod.path.insert(0, str(vs_dir))
            import vector_search as _vs
            import contextlib, io as _io
            _buf = _io.StringIO()
            with contextlib.redirect_stdout(_buf):
                _vs.cmd_prune()
            print(f"[distill] prune: {_buf.getvalue().strip()[:140]}", file=_s.stderr)
        except Exception:
            pass
    except Exception as e:
        print(f"[distill] 归档检查失败(不影响蒸馏): {e}", file=sys.stderr)


def main():
    args = sys.argv[1:]
    if not args:
        print(json.dumps({"error": "用法: python explicit_facts_extractor.py <会话文本|会话.jsonl> [--mode rules|llm] [--session <id>] [--cutoff <seq>] | --mark-distilled <id> [--cutoff <seq>] [entry...]"}, ensure_ascii=False))
        return 1
    # ── 标记登记子命令 ──
    if args[0] == "--mark-distilled":
        sid = args[1] if len(args) > 1 else ""
        cutoff = None
        rest = args[2:]
        if "--cutoff" in rest:
            i = rest.index("--cutoff")
            try:
                cutoff = int(rest[i + 1])
            except Exception:
                cutoff = None
            rest = rest[:i] + rest[i + 2:]
        res = mark_distilled(sid, rest, cutoff=cutoff)
        print(json.dumps(res, ensure_ascii=False, indent=1))
        return 0
    # ── 提取子命令 ──
    src = Path(args[0])
    mode = "rules"
    session = ""
    cutoff = None
    if "--mode" in args:
        mode = args[args.index("--mode") + 1]
    if "--session" in args:
        session = args[args.index("--session") + 1]
    if "--cutoff" in args:
        try:
            cutoff = int(args[args.index("--cutoff") + 1])
        except Exception:
            cutoff = None
    merge_advisory = "--merge" in args
    if mode == "llm":
        return _extract_llm(Path(args[0]))
    rec = _registry_record(session) if session else None
    if rec:
        stored = rec.get("cutoff")
        if cutoff is None:
            print(json.dumps({"mode": mode, "facts": [], "empty": True,
                              "already_distilled": True, "needs_cutoff": True,
                              "session": session, "stored_cutoff": stored,
                              "note": "会话已蒸馏；请传 --cutoff <seq> 增量蒸馏新消息（不静默跳过，避免错判旧内容）"},
                             ensure_ascii=False, indent=1))
            return 0
        since = stored if stored is not None else cutoff
        tail = _activity_rows([r for r in _messages_from_jsonl(src) if r["seq"] > since])
        if not tail:
            print(json.dumps({"mode": mode, "facts": [], "empty": True,
                              "already_distilled": True, "incremental": True,
                              "session": session, "since": since, "tail": 0,
                              "note": "cutoff 之后无新消息，无增量可蒸馏（未重复处理旧内容）"},
                             ensure_ascii=False, indent=1))
            return 0
        text = "\n\n".join(f"[{r['role']}]\n{r['text']}" for r in sorted(tail, key=lambda r: r["seq"]))
        result = _facts_from_text(text, mode)
        result.update({"incremental": True, "session": session, "since": since, "tail": len(tail)})
        if merge_advisory:
            _attach_merge(result.get("facts", []))
        print(json.dumps(result, ensure_ascii=False, indent=1))
        _archive_check_after_distill()  # 蒸馏执行附带：归档日计划时间检查
        return 0
    # 2026-08-27 风暴修复：JSONL 导出先按事件解析为消息文本，再跑断言正则；
    # 只有非 JSONL 纯文本（人工喂入的 md/txt）才走原文路径。
    # 活动门把所有消息滤光（无实质内容）时也绝不回退原文跑正则（2026-08-27 续）。
    if _looks_jsonl(src):
        msgs = _activity_rows(_messages_from_jsonl(src))
        _facts = _facts_from_text("\n\n".join(f"[{r['role']}]\n{r['text']}" for r in sorted(msgs, key=lambda r: r["seq"]))
                                  if msgs else "", mode)
        _facts["source"] = {"kind": "jsonl", "messages": len(msgs),
                            "activity_gated": not msgs}
    else:
        text = src.read_text(encoding="utf-8")
        _facts = _facts_from_text(text, mode)
        _facts["source"] = {"kind": "raw-text"}
    if merge_advisory:
        _attach_merge(_facts.get("facts", []))
    print(json.dumps(_facts, ensure_ascii=False, indent=1))
    _archive_check_after_distill()  # 蒸馏执行附带：归档日计划时间检查
    return 0

if __name__ == "__main__":
    sys.exit(main())
