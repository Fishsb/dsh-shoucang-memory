#!/usr/bin/env python3
"""
bypass_inspector.py — 旁路检测与拦截守卫

职责：
  检测是否有代码绕过 UDG 直接操作注册表管理的数据路径，
  拦截并提示正确的接口路径和用法。

使用方式：
  python bypass_inspector.py check <file_path_or_operation>
  python bypass_inspector.py watch        # 启动守护（被动监听模式）
  python bypass_inspector.py log          # 查看拦截日志

集成方式：
  from bypass_inspector import check_operation, intercept
  result = check_operation("write", "D:/lk/Obsidian/wiki/预skill/xxx.md")
  if result["blocked"]:
      print(result["redirect_message"])
"""
import os
import re
import sys
import json
import fnmatch
from pathlib import Path
from datetime import datetime

# 日志路径（从 registry.yaml §6 读取，自动发现注册表位置）
_REGISTRY_DIR = Path(__file__).resolve().parent
_LOG_PATH = None


def _merge_local(data):
    """registry.local.yaml 本机覆盖合并（机器专属路径不入模板；不存在则原样返回）"""
    try:
        import yaml as _y
        _lp = _REGISTRY_DIR / "registry.local.yaml"
        if _lp.exists():
            loc = _y.safe_load(_lp.read_text(encoding="utf-8")) or {}
            for _sec in ("roots", "paths"):
                if isinstance(loc.get(_sec), dict):
                    data.setdefault(_sec, {}).update(loc[_sec])
    except Exception:
        pass
    return data
def _get_log_path():
    global _LOG_PATH
    if _LOG_PATH:
        return _LOG_PATH
    try:
        import yaml
        raw = (_REGISTRY_DIR / "registry.yaml").read_text(encoding="utf-8")
        data = yaml.safe_load(raw)
        p = data.get("bypass", {}).get("log_path", "")
        if "${hermes_home}" in p:
            p = p.replace("${hermes_home}", "C:/Users/lk/AppData/Local/hermes")
        if p:
            _LOG_PATH = Path(p)
            return _LOG_PATH
    except Exception:
        pass
    _LOG_PATH = Path("C:/Users/lk/AppData/Local/hermes/logs/bypass.log")
    return _LOG_PATH

LOG_PATH = _get_log_path()
WIKI_ROOT = Path(__file__).resolve().parent.parent.parent  # _meta/registry/ → _meta/ → wiki

# ── 正确接口指引 ──
INTERFACE_GUIDE = {
    "write_wiki_file": {
        "handler": "write_gate.write_wiki_file()",
        "usage": """
from udg.write_gate import write_wiki_file

write_wiki_file(
    target_type="pre_skill",  # 或 memory / note
    title="方法论名称",
    content="# 概述\\n...",
    frontmatter={
        "name": "xxx-yyy",
        "tags": ["domain/hermes", "method/troubleshooting"]
    }
)
        """,
        "cli": "python D:/lk/Obsidian/wiki/_meta/registry/udg/write_gate.py --help",
    },
    "write_state_db": {
        "handler": "archive_gate.cleanup_sessions()",
        "usage": """
归档管线 Phase 9 自动处理 state.db 清理。
如需手动清理：
  from udg.archive_gate import cleanup_sessions
  cleanup_sessions(session_ids=[...])
        """,
        "cli": "请通过编排器触发归档管线",
    },
    "edit_mapping": {
        "handler": "registry.yaml §4",
        "usage": """
编辑 registry.yaml 的 domains 段：
  D:/lk/Obsidian/wiki/_meta/registry/registry.yaml
→ 找到 domains.<name>.keywords
→ 添加/删除关键词即可
→ 运行 registry_validator.py --check 验证
        """,
        "cli": "vim D:/lk/Obsidian/wiki/_meta/registry/registry.yaml",
    },
}


def load_protected_paths():
    """从 registry.yaml 加载受保护路径"""
    try:
        import yaml
        raw = (_REGISTRY_DIR / "registry.yaml").read_text(encoding="utf-8")
        data = yaml.safe_load(raw)
        bypass = data.get("bypass", {})
        return bypass.get("protected_paths", []), bypass.get("mode", "soft")
    except Exception:
        return [], "soft"


def _load_roots() -> dict:
    """从 registry.yaml 加载 roots + resolve 内部的 ${roots.xxx} 引用"""
    try:
        import yaml
        import re
        raw = (_REGISTRY_DIR / "registry.yaml").read_text(encoding="utf-8")
        data = yaml.safe_load(raw)
        roots = data.get("roots", {})
        paths = data.get("paths", {})

        def _resolve(val):
            if not isinstance(val, str):
                return str(val)
            def _replacer(m):
                key = m.group(1)
                parts = key.split(".")
                ctx = {"roots": roots}
                for p in parts:
                    if isinstance(ctx, dict):
                        ctx = ctx.get(p, "")
                    else:
                        return m.group(0)
                return str(ctx) if ctx else m.group(0)
            return re.sub(r'\$\{([^}]+)\}', _replacer, val)

        return {
            "wiki_root": str(WIKI_ROOT),
            "hermes_home": str(roots.get("hermes_home", "C:/Users/lk/AppData/Local/hermes")),
            "archive_plugin_dir": str(roots.get("archive_plugin_dir", "")),
            "state_db": _resolve(paths.get("state_db", "C:/Users/lk/AppData/Local/hermes/state.db")),
            "archive_data_dir": _resolve(paths.get("archive_data_dir", f"{WIKI_ROOT}/_archive_data")),
        }
    except Exception:
        return {
            "wiki_root": str(WIKI_ROOT),
            "hermes_home": "C:/Users/lk/AppData/Local/hermes",
            "state_db": "C:/Users/lk/AppData/Local/hermes/state.db",
            "archive_data_dir": f"{WIKI_ROOT}/_archive_data",
        }


def match_protected_path(file_path: str, protected_paths: list) -> bool:
    """检查路径是否落在受保护范围内（前缀匹配，支持 /** 递归通配符）"""
    abs_path = str(Path(file_path).resolve()).replace("\\", "/")
    roots = _load_roots()
    for pattern in protected_paths:
        # ${var} 替换（从 registry.yaml 动态加载）
        pattern = pattern.replace("${wiki_root}", roots["wiki_root"])
        pattern = pattern.replace("${hermes_home}", roots["hermes_home"])
        pattern = pattern.replace("${archive_data_dir}", roots["archive_data_dir"])
        pattern = pattern.replace("${state_db}", roots["state_db"])
        pattern = pattern.replace("\\", "/")
        # 处理 /** 递归通配符 — 转成前缀匹配
        if pattern.endswith("/**"):
            prefix = pattern[:-3]
            if abs_path.startswith(prefix):
                return True
        elif "**" in pattern:
            prefix = pattern.split("**")[0]
            if abs_path.startswith(prefix):
                return True
        else:
            if abs_path == pattern or fnmatch.fnmatch(abs_path, pattern):
                return True
    return False


def detect_operation_type(file_path: str, context: dict = None) -> str:
    """判断操作类型（写Wiki/写state/编辑映射等）"""
    p = str(file_path).lower()
    if "预skill" in p or "记忆" in p or "笔记" in p or "项目" in p:
        return "write_wiki_file"
    if "state.db" in p:
        return "write_state_db"
    if "DOMAIN_KEYWORDS" in p or "TOPIC_PATTERNS" in p:
        return "edit_mapping"
    if "archive-" in p and any(x in p for x in [".py", ".json"]):
        return "edit_mapping"
    return "unknown"


def check_operation(operation: str, file_path: str, context: dict = None) -> dict:
    """
    UDG 集成接口。检测某个操作是否违反注册表约束。
    
    Args:
        operation: "read" | "write" | "delete" | "edit"
        file_path: 操作目标路径
        context: 可选上下文信息
        
    Returns:
        {"allowed": bool, "blocked": bool, "redirect_message": str, ...}
    """
    protected_paths, mode = load_protected_paths()
    
    # 读操作不拦截
    if operation in ("read",):
        return {"allowed": True, "blocked": False}
    
    # 写/删/改 — 检查路径
    if match_protected_path(file_path, protected_paths):
        op_type = detect_operation_type(file_path, context)
        guide = INTERFACE_GUIDE.get(op_type, {})
        
        block_info = {
            "allowed": mode == "soft",  # soft=允许但提醒, hard=拒绝
            "blocked": True,
            "detected_at": datetime.now().isoformat(),
            "operation": operation,
            "path": file_path,
            "reason": f"路径在注册表管理域内",
            "correct_interface": guide.get("handler", "未知"),
            "redirect_message": guide.get("usage", "请通过 UDG 接口操作"),
            "cli_hint": guide.get("cli", ""),
        }
        
        # 记录日志
        _log_bypass(block_info)
        
        return block_info
    
    return {"allowed": True, "blocked": False}


def _log_bypass(info: dict):
    """记录拦截日志"""
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(info, ensure_ascii=False) + "\n")
    except Exception:
        pass  # 日志不可写不影响主流程


def cmd_check():
    """CLI: python bypass_inspector.py check <path>"""
    if len(sys.argv) < 3:
        print("用法: python bypass_inspector.py check <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[2]
    result = check_operation("write", file_path)
    
    if not result["blocked"]:
        print(f"✅ 路径在保护域外，允许操作: {file_path}")
        sys.exit(0)
    else:
        mode = "🔴 HARD 拒绝" if not result["allowed"] else "🟡 SOFT 提醒（允许执行但强烈建议改道）"
        print(f"╔══ PYLON INTERCEPT ═══════════════════════════════")
        print(f"║  拦截: {result['reason']}")
        print(f"║  路径: {result['path']}")
        print(f"║  模式: {mode}")
        print(f"║")
        print(f"║  ✅ 正确接口: {result['correct_interface']}")
        print(f"║  📖 用法:")
        for line in result['redirect_message'].strip().split('\n'):
            print(f"║    {line}")
        print(f"╚══════════════════════════════════════════════════")
        sys.exit(0 if result["allowed"] else 1)


def cmd_log():
    """CLI: python bypass_inspector.py log"""
    if not LOG_PATH.exists():
        print("无拦截日志")
        return
    
    entries = LOG_PATH.read_text(encoding="utf-8").strip().split("\n")
    entries = [json.loads(e) for e in entries if e]
    
    print(f"拦截日志 ({len(entries)} 条):")
    print("═" * 60)
    for e in entries[-20:]:  # 最近 20 条
        print(f"[{e.get('detected_at','?')}] {e.get('operation','?')}")
        print(f"  路径: {e.get('path','?')}")
        print(f"  原因: {e.get('reason','?')}")
        print(f"  正确接口: {e.get('correct_interface','?')}")
        print()


def main():
    if len(sys.argv) < 2:
        print("用法:")
        print("  python bypass_inspector.py check <path>  — 检查路径")
        print("  python bypass_inspector.py log           — 查看拦截日志")
        print("  python bypass_inspector.py status         — 查看注册表状态")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == "check":
        cmd_check()
    elif cmd == "log":
        cmd_log()
    elif cmd == "status":
        print("Bypass Inspector — UER 旁路守卫")
        print(f"  注册表: {_REGISTRY_DIR / 'registry.yaml'}")
        print(f"  日志: {LOG_PATH}")
        mode = load_protected_paths()[1]
        print(f"  模式: {'🔴 HARD (拒绝)' if mode == 'hard' else '🟡 SOFT (提醒)'}")
    else:
        print(f"未知命令: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
