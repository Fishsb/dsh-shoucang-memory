#!/usr/bin/env python3
"""
registry_validator.py — UER 自检脚本
验证 registry.yaml 的完整性和一致性。
所有组件调用此脚本确保注册表健康。
"""
import os
import re
import sys
import json
from pathlib import Path

REGISTRY_PATH = Path(__file__).resolve().parent / "registry.yaml"
WIKI_ROOT = Path(__file__).resolve().parent.parent.parent  # _meta/registry/ → _meta/ → wiki

def load_registry():
    """加载 registry.yaml，支持 ${var} 变量替换"""
    import yaml
    raw = REGISTRY_PATH.read_text(encoding="utf-8")
    data = yaml.safe_load(raw)
    
    # 简单变量替换（只展开 roots 引用）
    def resolve(val, context):
        if isinstance(val, str):
            def replacer(m):
                key = m.group(1)
                if key.startswith("roots."):
                    parts = key.split(".")
                    ctx = context
                    for p in parts:
                        if isinstance(ctx, dict):
                            ctx = ctx.get(p, "")
                        else:
                            return m.group(0)
                    return str(ctx) if ctx else m.group(0)
                return m.group(0)
            return re.sub(r'\$\{([^}]+)\}', replacer, val)
        return val

    # 递归解析 paths
    roots = data.get("roots", {})
    for section in ["paths", "bypass"]:
        if section in data:
            _walk_and_resolve(data[section], roots)
    return data

def _walk_and_resolve(node, roots):
    if isinstance(node, dict):
        for k, v in node.items():
            if isinstance(v, str):
                node[k] = _resolve_var(v, roots)
            else:
                _walk_and_resolve(v, roots)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            if isinstance(v, str):
                node[i] = _resolve_var(v, roots)
            elif isinstance(v, (dict, list)):
                _walk_and_resolve(v, roots)

def _resolve_var(val, roots):
    def replacer(m):
        key = m.group(1)
        parts = key.split(".")
        ctx = {"roots": roots}
        for p in parts:
            if isinstance(ctx, dict):
                ctx = ctx.get(p, "")
            else:
                return m.group(0)
        return str(ctx) if ctx else m.group(0)
    return re.sub(r'\$\{([^}]+)\}', replacer, val)

def check_section(registry, results):
    errors = results["errors"]
    warnings = results["warnings"]

    # §1 检查 roots
    roots = registry.get("roots", {})
    if not roots:
        errors.append("§1 roots 段缺失")
    if "wiki_root" not in roots:
        errors.append("§1 wiki_root 未定义（应为唯一数据锚点）")
    else:
        wr = Path(roots["wiki_root"])
        if not wr.exists():
            warnings.append(f"§1 wiki_root 路径不存在: {wr}")
    
    # §2 检查 paths
    paths = registry.get("paths", {})
    if not paths:
        errors.append("§2 paths 段缺失")
    required_paths = ["pre_skill_dir", "memory_dir", "note_dir", "format_spec"]
    for rp in required_paths:
        if rp not in paths:
            errors.append(f"§2 必要路径缺失: {rp}")
        else:
            p = Path(paths[rp])
            if not p.exists():
                warnings.append(f"§2 路径不存在（可能还没移过来）: {p}")
    
    # §3 检查 interfaces
    interfaces = registry.get("interfaces", {})
    if not interfaces:
        errors.append("§3 interfaces 段缺失")
    required_ifs = ["read_knowledge", "write_knowledge", "archive_pipeline"]
    for rif in required_ifs:
        if rif not in interfaces:
            errors.append(f"§3 必要接口缺失: {rif}")
        else:
            iface = interfaces[rif]
            if "allowed_callers" not in iface:
                errors.append(f"§3 接口 {rif} 缺少 allowed_callers")
            if "side_effects" not in iface:
                errors.append(f"§3 接口 {rif} 缺少 side_effects 声明")
    
    # §4 检查 domains
    domains = registry.get("domains", {})
    if not domains:
        errors.append("§4 domains 段缺失")
    for domain_name, domain_def in domains.items():
        if "keywords" not in domain_def or not domain_def["keywords"]:
            warnings.append(f"§4 domain '{domain_name}' 无关键词")
        if "targets" not in domain_def or not domain_def["targets"]:
            warnings.append(f"§4 domain '{domain_name}' 无 targets")
    
    # §5 检查 contracts
    contracts = registry.get("contracts", {})
    if not contracts:
        warnings.append("§5 contracts 段为空（建议至少定义 1 个契约）")
    
    # §6 检查 bypass
    bypass = registry.get("bypass", {})
    if not bypass:
        errors.append("§6 bypass 段缺失")
    else:
        if "protected_paths" not in bypass or not bypass["protected_paths"]:
            errors.append("§6 bypass.protected_paths 为空（无保护路径=无拦截）")

def check_wiki_integrity(registry, results):
    """检查 wiki 目录结构与 registry 定义是否一致"""
    errors = results["errors"]
    warnings = results["warnings"]
    
    # 检查 wiki 顶层目录
    wiki_root = Path(registry.get("roots", {}).get("wiki_root", ""))
    if not wiki_root.exists():
        return
    
    expected_dirs = ["预skill", "记忆", "笔记", "项目", "_meta"]
    for d in expected_dirs:
        dp = wiki_root / d
        if not dp.exists():
            warnings.append(f"Wiki 缺少预期顶层目录: {d}（不在 {dp}）")
    
    # 检查预skill 结构
    ps_dir = wiki_root / "预skill"
    if ps_dir.exists():
        skills_dir = ps_dir / "skills"
        if not skills_dir.exists():
            warnings.append("预skill/ 下无 skills/ 目录（与格式规范不一致）")
    
    # 检查记忆目录结构
    mem_dir = wiki_root / "记忆"
    if mem_dir.exists():
        index_file = mem_dir / "_index.md"
        if not index_file.exists():
            warnings.append("记忆/ 缺少 _index.md")
        expected_subtypes = ["配置", "规则", "参考", "工具", "环境"]
        for st in expected_subtypes:
            st_dir = mem_dir / st
            if st_dir.exists():
                st_index = st_dir / "_index.md"
                if not st_index.exists():
                    warnings.append(f"记忆/{st}/ 缺少 _index.md")

def check_format_spec(registry, results):
    """检查格式规范文件是否存在（单源真理的完整性）"""
    warnings = results["warnings"]
    spec_path = Path(registry.get("paths", {}).get("format_spec", ""))
    if spec_path.exists():
        size = spec_path.stat().st_size
        if size < 1000:
            warnings.append(f"格式规范文件过小（{size} bytes），可能不完整: {spec_path}")

def main():
    results = {"errors": [], "warnings": [], "info": []}
    
    print("═" * 60)
    print("UER Registry Self-Check")
    print(f"Registry: {REGISTRY_PATH}")
    print(f"Wiki Root: {WIKI_ROOT}")
    print("═" * 60)
    
    if not REGISTRY_PATH.exists():
        print(f"\n❌ FATAL: registry.yaml not found at {REGISTRY_PATH}")
        sys.exit(1)
    
    # 加载
    try:
        registry = load_registry()
        results["info"].append(f"registry.yaml 加载成功（version={registry.get('version','?')}）")
    except Exception as e:
        results["errors"].append(f"registry.yaml 加载失败: {e}")
        print("\n❌ 加载失败")
        sys.exit(1)
    
    # 逐段检查
    check_section(registry, results)
    check_wiki_integrity(registry, results)
    check_format_spec(registry, results)
    
    # 输出
    status = "✅ PASS" if not results["errors"] else "❌ FAIL"
    print(f"\n┌─ 检查结果 [{status}]")
    
    for level in ["errors", "warnings", "info"]:
        items = results[level]
        if items:
            prefix = {"errors": "❌", "warnings": "⚠️", "info": "ℹ️"}[level]
            print(f"│  {level.upper()} ({len(items)}):")
            for item in items:
                print(f"│    {prefix} {item}")
        else:
            print(f"│  {level.upper()}: 0")
    
    print("└" + "─" * 59)
    return 1 if results["errors"] else 0

if __name__ == "__main__":
    sys.exit(main())
