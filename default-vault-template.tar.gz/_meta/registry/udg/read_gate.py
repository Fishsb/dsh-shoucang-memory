#!/usr/bin/env python3
"""
read_gate.py — UDG 读网关
职责：Wiki 知识检索的统一入口。
     - 轻度查询：search_files / read_file / _index.md 遍历
     - 语义查询：kb_retriever.py 三步检索
     - 只读，无副作用

用法：
    from udg.read_gate import search_knowledge, get_file

    results = search_knowledge(query="编排器 4-Gate", top_k=3)
    content = get_file("预skill/skills/hermes/workflow/xxx.md")
"""
import json
import subprocess
import sys
from pathlib import Path

GATE_DIR = Path(__file__).resolve().parent
REGISTRY_DIR = GATE_DIR.parent
WIKI_ROOT = REGISTRY_DIR.parent.parent
KB_RETRIEVER = WIKI_ROOT / "kb_retriever.py"


def search_knowledge(query: str, top_k: int = 5,
                     target_types: list = None) -> dict:
    """
    搜索知识库（三步 wiki 检索：预skill → 记忆 → 笔记）

    Args:
        query: 搜索关键词
        top_k: 每步返回上限
        target_types: 限定搜索目录，如 ["pre_skill", "memory"]

    Returns:
        {"results": [...], "total": N, "sources": {...}}
    """
    target_dirs = {
        "pre_skill": WIKI_ROOT / "预skill",
        "memory": WIKI_ROOT / "记忆",
        "note": WIKI_ROOT / "笔记",
        "persona": WIKI_ROOT / "画像",
    }

    # 守藏板块开关联动:关闭板块从搜索目录摘除(shoucang.config.yaml boards.*)
    try:
        from . import shoucang_config
        target_dirs = {t: d for t, d in target_dirs.items()
                       if shoucang_config.board_enabled(shoucang_config.board_of(t), WIKI_ROOT)}
    except ImportError:
        pass  # 配置模块缺失 = 出厂默认全开

    if target_types:
        dirs = {k: v for k, v in target_dirs.items() if k in target_types}
    else:
        dirs = target_dirs

    results = []
    sources = {}

    # 方法1：kb_retriever.py CLI（优先）
    if KB_RETRIEVER.exists():
        try:
            cmd = [sys.executable or "python", str(KB_RETRIEVER),
                   "retrieve", query]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                data = json.loads(r.stdout)
                if isinstance(data, dict) and "results" in data:
                    results = data["results"]
                    sources["kb_retriever"] = "CLI"
                    record_hits(results)
                    return {"results": results, "total": len(results),
                            "sources": sources}
        except Exception:
            pass  # 降级到文件搜索

    # 方法2：search_files 遍历（降级）
    for type_name, search_dir in dirs.items():
        if not search_dir.exists():
            continue
        try:
            cmd = ["grep", "-ril", query, str(search_dir)]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            if r.returncode == 0:
                files = r.stdout.strip().split("\n")[:top_k]
                for fp in files:
                    if fp:
                        p = Path(fp)
                        results.append({
                            "type": type_name,
                            "path": str(p),
                            "filename": p.name,
                            "source": "grep",
                        })
                sources[type_name] = len(files)
        except Exception:
            pass

    record_hits(results)
    return {"results": results, "total": len(results), "sources": sources}


def record_hits(results):
    """守藏 lifecycle:检索命中计数(.index_cache/hit_counts.json,lifecycle_settle 消费后清零)"""
    try:
        import json as _json
        hit_file = WIKI_ROOT / ".index_cache" / "hit_counts.json"
        counts = {}
        if hit_file.exists():
            try:
                counts = _json.loads(hit_file.read_text(encoding="utf-8"))
            except Exception:
                counts = {}
        for r in results:
            p = r.get("path", "")
            if not p:
                continue
            rel = str(p)
            try:
                rel = str(Path(p).relative_to(WIKI_ROOT)).replace("\\", "/")
            except Exception:
                pass
            counts[rel] = int(counts.get(rel, 0)) + 1
        hit_file.parent.mkdir(parents=True, exist_ok=True)
        hit_file.write_text(_json.dumps(counts, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass  # 计数失败不影响检索主路径


def get_file(relative_path: str) -> dict:
    """
    读取 Wiki 文件（相对路径）

    Args:
        relative_path: 如 "预skill/skills/hermes/workflow/xxx.md"

    Returns:
        {"path": "绝对路径", "content": "...", "exists": true}
    """
    abs_path = WIKI_ROOT / relative_path
    if not abs_path.exists():
        return {"path": str(abs_path), "exists": False}
    try:
        content = abs_path.read_text(encoding="utf-8")
        return {"path": str(abs_path), "content": content,
                "exists": True, "size": len(content)}
    except Exception as e:
        return {"path": str(abs_path), "exists": False, "error": str(e)}


def list_by_type(target_type: str) -> list:
    """
    列出某类型的所有文件

    Args:
        target_type: "pre_skill" | "memory" | "note"

    Returns:
        [{"path": "...", "title": "...", "tags": [...]}, ...]
    """
    type_paths = {
        "pre_skill": WIKI_ROOT / "预skill",
        "memory": WIKI_ROOT / "记忆",
        "note": WIKI_ROOT / "笔记",
        "persona": WIKI_ROOT / "画像",
    }
    # 守藏板块开关联动(与 search 一致)
    try:
        from . import shoucang_config
        if not shoucang_config.board_enabled(shoucang_config.board_of(target_type), WIKI_ROOT):
            return []
    except ImportError:
        pass
    search_dir = type_paths.get(target_type)
    if not search_dir or not search_dir.exists():
        return []

    files = sorted(search_dir.rglob("*.md"))
    results = []
    for f in files:
        if f.name == "_index.md":
            continue
        # 简单解析 title
        content = f.read_text(encoding="utf-8", errors="ignore")
        title = f.stem
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 2:
                for line in parts[1].split("\n"):
                    if line.startswith("title:"):
                        title = line.split(":", 1)[1].strip()
                        break
        results.append({
            "path": str(f.relative_to(WIKI_ROOT)),
            "title": title,
        })

    return results


# ── CLI 入口 ──
def main():
    import argparse
    parser = argparse.ArgumentParser(description="UDG Read Gate — 知识检索")
    parser.add_argument("action", choices=["search", "get", "list"],
                        help="search=搜索, get=读取文件, list=列出类型")
    parser.add_argument("query", nargs="?", default="",
                        help="搜索词/文件路径/类型名")
    parser.add_argument("--top-k", type=int, default=5,
                        help="返回上限（仅 search）")

    args = parser.parse_args()

    if args.action == "search":
        result = search_knowledge(args.query, top_k=args.top_k)
    elif args.action == "get":
        result = get_file(args.query)
    elif args.action == "list":
        result = list_by_type(args.query)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
