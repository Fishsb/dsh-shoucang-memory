#!/usr/bin/env python3
"""
write_gate.py — UDG 写网关
职责：Wiki 文件写入的唯一入口。
     - 校验 target_type/title/frontmatter 符合 registry 和 spec
     - 自动生成 frontmatter（按 wiki-目录格式规范.md）
     - 写入 .md 文件 + 更新 _index.md
     - 写入前过 bypass_inspector → 拦截直写

用法：
    from udg.write_gate import write_wiki_file

    result = write_wiki_file(
        target_type="pre_skill",
        title="某方法论",
        content="# 概述\\n...",
        frontmatter={"name": "xxx-yyy", "tags": [...]}  # 可选
    )
"""
import json
import re
import sys
from pathlib import Path
from datetime import datetime

try:
    from . import spec_reader
    HAS_SPEC_READER = True
except ImportError:
    HAS_SPEC_READER = False

# ── 自动发现位置 ──
GATE_DIR = Path(__file__).resolve().parent
REGISTRY_DIR = GATE_DIR.parent  # _meta/registry/
WIKI_ROOT = REGISTRY_DIR.parent.parent  # _meta/ → wiki
REGISTRY_YAML = REGISTRY_DIR / "registry.yaml"

# ── 允许写入的类型 ──
ALLOWED_TYPES = {"pre_skill", "memory", "note", "persona"}

# ── frontmatter 字段顺序（从 wiki-目录格式规范.md 提炼）──
FRONTMATTER_ORDER = {
    "pre_skill": [
        "type", "name", "title", "tags",
        "confidence", "iteration", "lifecycle",
        "created", "updated", "source",
        "description", "target", "domain"
    ],
    "memory": [
        "type", "name", "title", "subtype",
        "tags", "confidence", "created", "updated", "source"
    ],
    "note": [
        "type", "name", "title",
        "tags", "domain", "source",
        "confidence", "created", "updated"
    ],
    # 守藏画像板块（docs/画像格式规范-v1.md）
    "persona": [
        "type", "name", "title", "subtype",
        "tags", "confidence", "reliability", "lifecycle", "pinned",
        "supersedes", "superseded_by", "deprecated",
        "created", "updated", "source", "description"
    ],
}

# ── 类型→目录映射 ──
TYPE_DIR_MAP = {
    "pre_skill": "预skill/skills",
    "memory": "记忆",
    "note": "笔记",
    "persona": "画像",
}


def _sanitize_filename(title: str) -> str:
    """将 title 转为合法文件名（保留中文，空格/标点转 -）"""
    name = title.strip()
    name = re.sub(r'[^\w\-\u4e00-\u9fff]', '-', name)
    name = re.sub(r'-+', '-', name)
    return name[:120]


def _resolve_target_dir(target_type: str, domain: str = None, target: str = None,
                        frontmatter: dict = None) -> Path:
    """
    根据 type 和 tags 确定写入目录。
    pre_skill → 预skill/skills/<L1>/<L2>/
    memory   → 记忆/<subtype>/
    note     → 笔记/<domain>/
    """
    base = WIKI_ROOT / TYPE_DIR_MAP[target_type]

    if target_type == "pre_skill":
        # 预skill/skills/<L1>/<L2>/
        l1 = domain or "hermes"
        l2 = target or "workflow"
        return base / l1 / l2

    elif target_type == "memory":
        # v1 时间梯度路由（归档管线设计-v1 §3）：staging 配置的 {stage:'daily|week|month|year'} → 梯度目录；
        # 否则按 subtype 旧映射（存量条目迁移用）路由到 记忆/<subtype>/
        staging = None
        try:
            from . import shoucang_config
            staging = shoucang_config
        except ImportError:
            staging = None
        if staging is not None and frontmatter and frontmatter.get("stage"):
            stage = frontmatter.get("stage")
            tier_map = {
                "daily": "日记忆", "week": "长期记忆/周记忆",
                "month": "长期记忆/月记忆", "year": "长期记忆/年记忆",
            }
            # 先尝试走配置 tier_dir，退化为默映射
            try:
                tdir = staging.tier_dir(stage, WIKI_ROOT)
                if tdir.is_relative_to(WIKI_ROOT):
                    rel = tdir.relative_to(WIKI_ROOT)
                    if rel.as_posix().startswith("记忆"):
                        return base.parent / rel  # base=WIKI_ROOT/记忆
            except Exception:
                pass
            subdir = tier_map.get(stage, "日记忆")
            return base / subdir
        subtype_map = {
            "config": "配置", "rule": "规则", "reference": "参考",
            "tool": "工具", "env": "环境",
            # 中文直传(契约用中文 subtype,与 registry.yaml memory_subtype_map 双向一致)
            "配置": "配置", "规则": "规则", "参考": "参考",
            "工具": "工具", "环境": "环境"
        }
        subtype = subtype_map.get(target or "config", "配置")
        return base / subtype

    elif target_type == "note":
        return base / (domain or "general")

    elif target_type == "persona":
        # 守藏画像板块：subtype 我|你 双域（docs/画像格式规范-v1.md）
        subtype = (target or "").strip()
        if subtype not in ("我", "你"):
            return None  # 非法 subtype，由调用方报错
        return base / subtype

    return base


def _build_frontmatter(target_type: str, title: str,
                       frontmatter: dict = None) -> dict:
    """构造 frontmatter，缺省字段自动补全（按 spec 字段序）"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    fm = frontmatter or {}
    now_str = datetime.now().strftime("%Y-%m-%d")

    defaults = {
        "type": target_type,
        "name": fm.pop("name", _sanitize_filename(title).lower()),
        "title": fm.pop("title", title),
        "confidence": 60,
        "created": now_str,
        "updated": now_str,
    }

    if target_type == "pre_skill":
        # name fallback: 从 title 净化生成（CJK 标题无法自动转英文 kebab-case，
        # 调用方应单独传入 name 字段以满足 spec §1.1.2 主-宾-谓格式要求）
        defaults.update({
            "description": fm.pop("description", f"{title} 操作流程"),
            "tags": ["domain/hermes"],
            "domain": "hermes",
            "target": "workflow",
            "iteration": 1,
            "lifecycle": fm.pop("lifecycle", "draft"),
            "source": "orchestrator",
        })
    elif target_type == "memory":
        defaults.update({
            "subtype": "配置",
            "tags": ["domain/hermes"],
            "source": "archive",
        })
    elif target_type == "note":
        defaults.update({
            "tags": ["domain/hermes"],
            "domain": "hermes",
            "source": "external",
        })
    elif target_type == "persona":
        # 守藏画像板块缺省（docs/画像格式规范-v1.md）
        defaults.update({
            "subtype": fm.pop("subtype", "我"),
            "tags": ["偏好/协作"],
            "reliability": "verified",
            "lifecycle": "draft",
            "pinned": False,
            "source": "idle-review",
        })

    # 合并：fm 覆盖 defaults
    merged = {**defaults, **fm}

    # 🔴 守卫标记：L2 git pre-commit hook 依赖此字段
    # 此标记不可被 caller frontmatter 覆盖（写在合并后强制设置）
    merged["x-uer-writer"] = "write_gate"

    # 按规范字段序排序
    order = FRONTMATTER_ORDER.get(target_type, list(merged.keys()))
    ordered = {}
    for key in order:
        if key in merged:
            ordered[key] = merged[key]
    # 剩余字段追加在后
    for key, val in merged.items():
        if key not in ordered:
            ordered[key] = val

    return ordered


def _format_frontmatter_yaml(fm: dict) -> str:
    """将 frontmatter dict 格式化为 YAML 字符串"""
    lines = ["---"]
    for key, val in fm.items():
        if isinstance(val, list):
            items = "\n".join(f"  - {json.dumps(v, ensure_ascii=False)}" for v in val)
            lines.append(f"{key}:\n{items}")
        elif isinstance(val, dict):
            lines.append(f"{key}:")
            for k, v in val.items():
                lines.append(f"  {k}: {json.dumps(v, ensure_ascii=False)}")
        elif isinstance(val, bool):
            lines.append(f"{key}: {'true' if val else 'false'}")
        else:
            lines.append(f"{key}: {val}")
    lines.append("---")
    return "\n".join(lines)


def _update_index(target_dir: Path):
    """更新目标目录的 _index.md"""
    index_file = target_dir / "_index.md"
    if not index_file.exists():
        content = f"# {target_dir.name}\n\n"
        index_file.write_text(content, encoding="utf-8")
        return "created"

    # 检查是否已有条目
    content = index_file.read_text(encoding="utf-8")
    # 只需确保 _index.md 存在即可
    return "exists"


def write_wiki_file(target_type: str, title: str, content: str,
                    frontmatter: dict = None, domain: str = None,
                    target: str = None,
                    skip_quality_check: bool = False) -> dict:
    """
    UDG 写网关主函数 — 写入 Wiki 文件。

    Args:
        target_type: "pre_skill" | "memory" | "note"
        title: 文件标题（=文件名）
        content: Markdown 正文
        frontmatter: 可选 frontmatter 覆盖
        domain: domain 标签（用于目录路由）
        target: target 标签（用于子目录路由）
        skip_bypass: 跳过 bypass 检查（内部调用用）

    Returns:
        {"status": "created"|"updated"|"skipped",
         "file_path": "绝对路径",
         "index_updated": "created"|"exists"|"none",
         "validation": {"passed": true, "issues": []}}
    """

    # ── 0. 类型校验 ──
    if target_type not in ALLOWED_TYPES:
        return {"status": "error", "error": f"不支持的类型: {target_type}，允许: {ALLOWED_TYPES}"}

    # ── 0.5 守藏板块开关联动（shoucang.config.yaml boards.*）──
    try:
        from . import shoucang_config
        if not shoucang_config.board_enabled(shoucang_config.board_of(target_type), WIKI_ROOT):
            board = shoucang_config.board_of(target_type)
            return {"status": "error",
                    "error": f"板块 {board} 已在 shoucang.config.yaml 中关闭,拒绝写入 {target_type}"}
    except ImportError:
        pass  # 配置模块缺失 = 出厂默认全开

    # ── 1. bypass 检查 ──
    # 注意：write_gate 本身就是正确接口，只对外部直写做检测
    # 这里不做 bypass 检测，而是由外部调用方/工具层负责
    pass  # bypass 检测由上层编排器工具钩子负责

    # ── 2. 确定目标目录+路径 ──
    target_dir = _resolve_target_dir(target_type, domain, target, frontmatter)
    if target_dir is None:
        return {"status": "error",
                "error": f"persona subtype 非法（target={target!r}），允许: 我 | 你"}
    target_dir.mkdir(parents=True, exist_ok=True)

    filename = _sanitize_filename(title) + ".md"
    file_path = target_dir / filename

    # ── 3. 去重检查 ──
    status = "created"
    if file_path.exists():
        existing = file_path.read_text(encoding="utf-8")
        if content.strip() in existing:
            return {"status": "skipped", "file_path": str(file_path),
                    "reason": "内容重复, 跳过写入"}
        status = "updated"

    # ── 4. 构建 frontmatter ──
    fm = _build_frontmatter(target_type, title, frontmatter)
    fm_yaml = _format_frontmatter_yaml(fm)

    # ── 4.5 内容质量检查（格式合规门 — L1 强制）──
    if not skip_quality_check and HAS_SPEC_READER:
        fc = f"{fm_yaml}\n\n{content.strip()}\n"
        q = spec_reader.check_content_quality(fc, doc_type=target_type, file_path=str(file_path))
        if not q["pass"]:
            return {"status": "rejected",
                    "error": "❌ 内容质量检查未通过: " + "; ".join(q.get("reasons", ["格式不合规"])),
                    "checks": q.get("checks", {}),
                    "reasons": q.get("reasons", [])}

    # ── 5. 写入文件 ──
    full_content = f"{fm_yaml}\n\n{content.strip()}\n"
    file_path.write_text(full_content, encoding="utf-8")

    # ── 6. 更新 _index.md ──
    index_status = _update_index(target_dir)

    # ── 6.5 守藏向量索引:标记待重建(轻量,失败不影响主路径) ──
    try:
        import json as _json
        pend_file = WIKI_ROOT / ".index_cache" / "vector_pending.json"
        pending = []
        if pend_file.exists():
            try:
                pending = _json.loads(pend_file.read_text(encoding="utf-8"))
            except Exception:
                pending = []
        rel = file_path.relative_to(WIKI_ROOT).as_posix()
        if rel not in pending:
            pending.append(rel)
            pend_file.parent.mkdir(parents=True, exist_ok=True)
            pend_file.write_text(_json.dumps(pending, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

    # ── 7. 验证（含二次格式合规检查）──
    written_size = file_path.stat().st_size
    validation = {"passed": written_size > 100, "issues": []}
    if written_size < 100:
        validation["issues"].append(f"文件过小: {written_size} bytes")
    if not skip_quality_check and HAS_SPEC_READER:
        wc = file_path.read_text(encoding="utf-8")
        vq = spec_reader.check_content_quality(wc, doc_type=target_type, file_path=str(file_path))
        if not vq["pass"]:
            validation["passed"] = False
            validation["issues"].extend(vq.get("reasons", []))
            validation["quality_fail"] = True
        else:
            validation["quality_fail"] = False

    return {
        "status": status,
        "file_path": str(file_path),
        "target_type": target_type,
        "size_bytes": written_size,
        "index_updated": index_status,
        "validation": validation,
    }


def batch_write(entries: list) -> list:
    """
    批量写入多条 wiki 文件。

    Args:
        entries: [write_wiki_file 参数 dict, ...]

    Returns:
        [write_wiki_file 返回结果, ...]
    """
    results = []
    for entry in entries:
        result = write_wiki_file(**entry)
        results.append(result)
    return results


# ── CLI 入口 ──
def main():
    import argparse
    parser = argparse.ArgumentParser(description="UDG Write Gate — Wiki 文件写入")
    parser.add_argument("target_type", choices=list(ALLOWED_TYPES),
                        help="写入类型")
    parser.add_argument("title", help="文件标题")
    parser.add_argument("content", help="正文内容（支持 \\n 换行）")
    parser.add_argument("--domain", default=None, help="domain 标签")
    parser.add_argument("--target", default=None, help="target 标签")
    parser.add_argument("--frontmatter", default=None,
                        help="frontmatter JSON 覆写")

    args = parser.parse_args()
    content = args.content.replace("\\n", "\n")
    fm = json.loads(args.frontmatter) if args.frontmatter else None

    result = write_wiki_file(
        target_type=args.target_type,
        title=args.title,
        content=content,
        frontmatter=fm,
        domain=args.domain,
        target=args.target,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") not in ("error", "blocked_by_bypass") else 1


if __name__ == "__main__":
    sys.exit(main())
