#!/usr/bin/env python3
"""uer_watchdog.py — UER 一致性看门狗。

检测技能文件与 registry.yaml 的同步状态。
自动修复：如果发现可自动修复的问题，调用 generate_skill_assets.py。
不可自动修复的问题 → 写入 ~/.hermes/uer_drift_report.json，编排器在 G4 交付时读取。
"""

import json, os, subprocess, sys
from pathlib import Path

HERMES_HOME = Path(os.environ.get("HERMES_HOME", str(Path.home() / "AppData/Local/hermes")))
SCRIPTS_DIR = HERMES_HOME / "scripts"
DRIFT_FILE = HERMES_HOME / "uer_drift_report.json"
WIKI_REGISTRY = Path(r"D:\lk\Obsidian\wiki\_meta\registry\registry.yaml")


def run_script(name: str) -> subprocess.CompletedProcess:
    """运行 hermes scripts/ 下的 Python 脚本。"""
    script = SCRIPTS_DIR / name
    if not script.exists():
        return subprocess.CompletedProcess(args=[], returncode=-1, stdout=b"", stderr=b"script not found")
    return subprocess.run(
            ["python", str(script)],
            capture_output=True, text=True, timeout=30
    )


def check():
    """执行检查，自动修复，返回 (ok: bool, report: dict)。"""
    report = {
        "timestamp": subprocess.run(
            ["python", "-c", "from datetime import datetime; print(datetime.now().isoformat())"],
            capture_output=True, text=True).stdout.strip(),
        "auto_fix_attempted": False,
        "issues_before_fix": 0,
        "issues_after_fix": 0,
        "remaining_issues": [],
        "fixable": True,
    }

    # Step 1: check
    r = run_script("uersync.py")
    output = r.stdout
    report["issues_before_fix"] = r.returncode

    if r.returncode == 0:
        # No issues — clean
        if DRIFT_FILE.exists():
            DRIFT_FILE.unlink()
        report["remaining_issues"] = []
        report["issues_after_fix"] = 0
        return True, report

    # Step 2: auto-fix
    report["auto_fix_attempted"] = True
    r2 = run_script("uer_generate_assets.py")
    if r2.returncode != 0:
        report["fixable"] = False
    else:
        # Step 3: re-check
        r3 = run_script("uersync.py")
        report["issues_after_fix"] = r3.returncode

        if r3.returncode == 0:
            # Fixed! Clean up drift report
            if DRIFT_FILE.exists():
                DRIFT_FILE.unlink()
            return True, report

        # Still has issues — collect remaining
        for line in r3.stdout.split("\n"):
            if "❌" in line or "未匹配" in line or "不匹配" in line:
                report["remaining_issues"].append(line.strip())

    # Write drift report for orchestrator to read
    DRIFT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return False, report


def main():
    ok, report = check()

    if ok:
        print(f"✅ UER 看门狗: 同步状态健康 (auto_fix={report['auto_fix_attempted']})")
        return 0
    else:
        print(f"🔴 UER 看门狗: {len(report['remaining_issues'])} 个问题需要人工处理")
        for issue in report["remaining_issues"][:5]:
            print(f"   {issue}")
        print(f"   详细报告: {DRIFT_FILE}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
