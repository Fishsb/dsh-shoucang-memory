#!/usr/bin/env python3
"""
shoucang_config.py — 守藏配置加载器(零第三方依赖)

职责:
    - 从 <WIKI_ROOT>/shoucang.config.yaml 读取守藏板块开关等配置
    - 无 PyYAML 环境下用正则行解析兜底(仅解析 gate 所需的布尔/字符串键)
    - 配置文件不存在 = 出厂默认:三板块全开、归档开、语义路由禁用

被 write_gate / read_gate 引用;插件侧(Cordis JS)有独立同构实现。
"""
import re
from pathlib import Path

GATE_DIR = Path(__file__).resolve().parent
REGISTRY_DIR = GATE_DIR.parent
WIKI_ROOT_DEFAULT = REGISTRY_DIR.parent.parent  # _meta/registry/udg → wiki 根

CONFIG_NAME = "shoucang.config.yaml"

# 板块开关出厂默认(与 shoucang.config.example.yaml 一致)
DEFAULTS = {
    "boards": {"persona": True, "memory": True, "wiki": True},
    "archive": {"enabled": True, "ttl_multiplier": 2},
    "embedding": {"base_url": "", "enabled": False},
    "lifecycle": {"enabled": True},
}

# 记忆目录（2026-08-27 收敛：长期记忆三梯度已销毁；归档=顶层 归档/）
TIER_DIRS = {
    "daily": "记忆/日记忆",
    "archive": "归档",
}

# 档位保留基数(天) × ttl_multiplier(归档保留期)；三梯度销毁后仅 daily 使用
TIER_DAYS = {"daily": 1}

_TYPE_TO_BOARD = {
    "persona": "persona",
    "memory": "memory",
    "pre_skill": "wiki",
    "note": "wiki",
}


def _parse_scalar(raw: str):
    raw = raw.strip().strip('"').strip("'")
    if raw.lower() in ("true", "yes", "on"):
        return True
    if raw.lower() in ("false", "no", "off", ""):
        return False if raw.lower() in ("false", "no", "off") else ""
    try:
        return int(raw)
    except ValueError:
        return raw


def _strip_comment(s: str) -> str:
    """去掉行尾注释(# 之后的文本),但保留引号内的 #。"""
    in_q = False
    q = None
    for i, ch in enumerate(s):
        if ch in ('"', "'"):
            if not in_q:
                in_q, q = True, ch
            elif ch == q:
                in_q = False
        elif ch == "#" and not in_q:
            return s[:i].rstrip()
    return s.rstrip()


def _regex_parse(text: str) -> dict:
    """无 PyYAML 时的行解析兜底:基于缩进栈,支持 4 级嵌套。
    形如 shoucang > lifecycle > tiers > daily > dir 的任意深度都能解析。
    只提取 gate 关心的键;去行内注释。"""
    import re as _re
    cfg = {}
    # 缩进栈: [(indent, path_prefix)];path 是相对 shoucang 的段列表
    stack = []  # [(indent, [segments])]
    SECTIONS = ("boards", "archive", "embedding", "lifecycle", "injection", "scheduler")

    def insert(path, val):
        """把 val 写入 cfg[path...],path 是段列表(不含 shoucang)。"""
        node = cfg
        for seg in path[:-1]:
            node = node.setdefault(seg, {})
        node[path[-1]] = val

    for raw_line in text.splitlines():
        s = _strip_comment(raw_line).rstrip()
        if not s or not s.lstrip():
            continue
        indent = len(s) - len(s.lstrip(" "))
        stripped = s.strip()
        m = _re.match(r"([A-Za-z_][\w-]*):\s*(.*)$", stripped)
        if not m:
            continue
        key, val_raw = m.group(1), m.group(2).strip()
        has_val = val_raw != ""

        # 弹出栈中比当前 indent 更深的层
        while stack and stack[-1][0] >= indent:
            stack.pop()
        # 当前路径前缀 = 栈中浅层的段
        prefix = stack[-1][1] if stack else []
        # shoucang 顶层
        if indent == 0:
            stack = []
            if key == "shoucang":
                if has_val:
                    cfg["shoucang"] = _parse_scalar(val_raw)
                else:
                    stack = [(0, ["shoucang"])]
            else:
                cfg[key] = _parse_scalar(val_raw) if has_val else {}
            continue

        current = prefix + [key]
        if has_val:
            # 值行(段叶子)。若 path 指向 shoucang 直属或某个映射段。
            insert(current, _parse_scalar(val_raw))
            # 值行不作为容器入栈
        else:
            # 容器行(如 daily:, tiers:),入栈
            stack = [(i, p) for (i, p) in stack if p != current] + [(indent, current)]
    # 返回含 shoucang 包裹的完整 dict,由 load_config 统一 .get('shoucang')
    return cfg


def load_config(wiki_root: Path = None) -> dict:
    """读取守藏配置;返回合并出厂默认后的完整 dict。"""
    root = Path(wiki_root) if wiki_root else WIKI_ROOT_DEFAULT
    merged = {k: dict(v) if isinstance(v, dict) else v for k, v in DEFAULTS.items()}
    cfg_path = root / CONFIG_NAME
    if not cfg_path.exists():
        return merged
    try:
        text = cfg_path.read_text(encoding="utf-8")
    except Exception:
        return merged
    try:
        import yaml  # 有 PyYAML 用完整解析
        data = yaml.safe_load(text) or {}
        data = data.get("shoucang", data)
    except ImportError:
        data = _regex_parse(text)
        data = data.get("shoucang", data)
    except Exception:
        return merged
    if not isinstance(data, dict):
        return merged
    for k, v in data.items():
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k].update({kk: vv for kk, vv in v.items() if vv != ""})
        elif v != "" or k == "wiki_root":
            merged[k] = v
    return merged


def board_enabled(board: str, wiki_root: Path = None) -> bool:
    """查询某板块是否启用(persona/memory/wiki)。未知板块视为启用。"""
    return bool(load_config(wiki_root).get("boards", {}).get(board, True))


def board_of(target_type: str) -> str:
    """write/read 类型 → 板块名;未登记类型归 wiki。"""
    return _TYPE_TO_BOARD.get(target_type, "wiki")


def archive_enabled(wiki_root: Path = None) -> bool:
    return bool(load_config(wiki_root).get("archive", {}).get("enabled", True))


# ── v1 时间梯度辅助（归档管线设计-v1 / shoucang.config.yaml lifecycle.tiers）──

def tier_dir(stage: str, wiki_root: Path = None) -> Path:
    """档位 → 目录(绝对路径)。daily→记忆/日记忆；archive/未知/废弃梯度→顶层 归档/。"""
    base = WIKI_ROOT_DEFAULT if wiki_root is None else Path(wiki_root)
    cfg = load_config(wiki_root)
    tiers = cfg.get("lifecycle", {}).get("tiers", {})
    if isinstance(tiers, dict) and stage in tiers:
        entry = tiers[stage]
        cfg_dir = entry.get("dir") if isinstance(entry, dict) else None
        if cfg_dir:
            return base / cfg_dir
    if stage in TIER_DIRS:
        return base / TIER_DIRS[stage]
    return base / TIER_DIRS["archive"]  # 已销毁梯度/未知 → 顶层归档（不回退 daily）


def tier_ttl_days(stage: str, wiki_root: Path = None) -> int:
    """某梯度档位的归档保留天数 = 档位时间 × ttl_multiplier(默认 2)。"""
    multiplier = float(load_config(wiki_root).get("archive", {}).get("ttl_multiplier", 2) or 2)
    base = TIER_DAYS.get(stage, 1)
    return int(base * multiplier)


def archive_ttl_multiplier(wiki_root: Path = None) -> float:
    """归档保留乘数(默认 2):日2天/周14天/月约60天/年约730天。"""
    return float(load_config(wiki_root).get("archive", {}).get("ttl_multiplier", 2) or 2)
