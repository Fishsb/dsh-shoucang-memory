#!/usr/bin/env python3
"""
archive_gate.py — UDG 归档管线网关
职责：会话归档管线的唯一入口。
     - 接收归档请求（session list / cluster list）
     - 从 registry.yaml 注入路径配置，替代各脚本硬编码
     - 按阶段编排执行 Phase 2→9
     - 所有 Phase7 writeback 调用 write_gate.write_wiki_file()

用法：
    from udg.archive_gate import run_pipeline

    result = run_pipeline(cluster_id="cluster_000")
"""
import json
import subprocess
import os
import sys
from pathlib import Path

# ── 自动发现位置 ──
GATE_DIR = Path(__file__).resolve().parent
REGISTRY_DIR = GATE_DIR.parent
WIKI_ROOT = REGISTRY_DIR.parent.parent
REGISTRY_YAML = REGISTRY_DIR / "registry.yaml"




def _merge_local(data):
    """registry.local.yaml 本机覆盖合并（机器专属路径不入模板；不存在则原样返回）"""
    try:
        import yaml as _y
        _lp = REGISTRY_DIR / "registry.local.yaml"
        if _lp.exists():
            loc = _y.safe_load(_lp.read_text(encoding="utf-8")) or {}
            for _sec in ("roots", "paths"):
                if isinstance(loc.get(_sec), dict):
                    data.setdefault(_sec, {}).update(loc[_sec])
    except Exception:
        pass
    return data
def _load_registry_paths():
    """从 registry.yaml 加载路径（简化版，不走 yaml 依赖）"""
    import yaml
    raw = REGISTRY_YAML.read_text(encoding="utf-8")
    data = yaml.safe_load(raw)
    data = _merge_local(data)
    return data.get("paths", {}), data.get("roots", {})


def _get_archive_scripts_dir(roots: dict) -> Path:
    """获取归档脚本目录"""
    return Path(roots.get("archive_plugin_dir", ""))


def _get_archive_data_dir(paths: dict) -> Path:
    """获取归档中间产物目录"""
    raw = paths.get("archive_data_dir", "")
    if "${roots.wiki_root}" in raw:
        raw = raw.replace("${roots.wiki_root}", str(WIKI_ROOT))
    return Path(raw)


def run_pipeline(cluster_id: str = None, phases: list = None,
                 dry_run: bool = False, **kwargs) -> dict:
    """
    运行归档管线。

    Args:
        cluster_id: 指定处理某个 cluster（为空则扫描全部）
        phases: 要运行的阶段列表，默认全部（["phase2","phase3a",...]）
        dry_run: 预览模式（不实际执行）

    Returns:
        {"status": "completed"|"partial"|"error",
         "phases_completed": [...],
         "phases_failed": [...],
         "written_files": [...]}
    """
    paths, roots = _load_registry_paths()
    scripts_dir = _get_archive_scripts_dir(roots)
    archive_data_dir = _get_archive_data_dir(paths)

    if not scripts_dir.exists():
        return {"status": "error",
                "error": f"归档脚本目录不存在: {scripts_dir}"}

    archive_data_dir.mkdir(parents=True, exist_ok=True)

    all_phases = ["phase2", "phase3a", "phase3b", "phase3b+",
                  "phase4", "phase5", "phase6", "phase7", "phase8", "phase9"]
    phases = phases or all_phases

    # ── 阶段→脚本映射 ──
    phase_scripts = {
        "phase2":   "archive-cluster.py",
        "phase3a":  "generate_output.py",
        "phase3b":  "archive-type-detector.py",
        "phase3b+": "memory_attr_extractor.py",
        "phase4":   "archive-name-extractor.py",
        "phase5":   "archive-tag-extractor.py",
        "phase6":   "archive-retriever.py",
        "phase7":   "archive-writeback.py",
        "phase8":   "archive-validator.py",
        "phase9":   "archive-writeback.py",  # cleanup subcommand
    }

    # ── 阶段子命令 ──
    phase_args = {
        "phase2":  [],
        "phase3a": [],
        "phase3b": ["--cluster", cluster_id] if cluster_id else [],
        "phase3b+": ["--cluster", cluster_id] if cluster_id else [],
        "phase4":  ["--cluster", cluster_id] if cluster_id else [],
        "phase5":  ["--cluster", cluster_id] if cluster_id else [],
        "phase6":  ["--cluster", cluster_id] if cluster_id else [],
        "phase7":  ["writeback", cluster_id] if cluster_id else [],
        "phase8":  ["--cluster", cluster_id] if cluster_id else [],
        "phase9":  ["--cluster", cluster_id] if cluster_id else [],
    }

    completed = []
    failed = []
    written_files = []

    for phase in phases:
        script = scripts_dir / phase_scripts.get(phase, "")
        if not script.exists():
            failed.append({"phase": phase,
                           "error": f"脚本不存在: {script}"})
            continue

        args = phase_args.get(phase, [])
        cmd = [sys.executable or "python", str(script)] + args

        if phase == "phase7":
            cmd = [sys.executable or "python", str(script)] + ["writeback"]
            if cluster_id:
                cmd.append(cluster_id)
            # 注：此处应拦截 writeback 的直接执行，
            # 改为调用 write_gate 逐条写入
            # 但当前阶段先保持原样，后续再注入拦截

        if dry_run:
            completed.append({"phase": phase, "dry_run": True,
                              "command": " ".join(cmd)})
            continue

        try:
            result = subprocess.run(
                cmd,
                capture_output=True, text=True,
                timeout=300,
                cwd=str(scripts_dir)
            )
            status = "completed" if result.returncode == 0 else "failed"
            if status == "completed":
                completed.append({"phase": phase,
                                  "returncode": result.returncode})
            else:
                failed.append({"phase": phase,
                               "error": result.stderr[-500:] if result.stderr else "unknown"})
        except subprocess.TimeoutExpired:
            failed.append({"phase": phase, "error": "超时 (300s)"})

    overall = "error" if failed and not completed else \
              "partial" if failed else "completed"

    return {
        "status": overall,
        "phases_completed": [p["phase"] for p in completed],
        "phases_failed": [p["phase"] for p in failed],
        "written_files": written_files,
        "errors": failed if failed else None,
    }


def cleanup_sessions(session_ids: list, profile: str = "default") -> dict:
    """
    清理已归档会话。

    Args:
        session_ids: 要清理的 session ID 列表
        profile: 会话所属 profile

    Returns:
        {"status": "completed", "cleaned": N, "errors": [...]}
    """
    # 此函数对应 registry.yaml 中 session_cleanup 接口
    # 调用 Phase9 清理
    cleaned = 0
    errors = []

    # 从 registry.yaml 加载 state.db 路径
    try:
        import yaml
        reg = REGISTRY_YAML.read_text(encoding="utf-8")
        reg_data = yaml.safe_load(reg)
        paths_cfg = reg_data.get("paths", {})
        roots_cfg = reg_data.get("roots", {})
        state_db_profiles_cfg = paths_cfg.get("state_db_profiles", {})
        state_db_paths = {}
        for profile_name, rel_path in state_db_profiles_cfg.items():
            rel_path_str = str(rel_path)
            # 解析 ${roots.hermes_home} 变量
            if "${roots.hermes_home}" in rel_path_str:
                hermes_home = roots_cfg.get("hermes_home", "")
                if hermes_home:
                    rel_path_str = rel_path_str.replace("${roots.hermes_home}", hermes_home)
                else:
                    rel_path_str = rel_path_str.replace("${roots.hermes_home}", str(Path.home() / ".hermes"))
            p = Path(rel_path_str)
            if not p.is_absolute():
                p = WIKI_ROOT / p
            state_db_paths[profile_name] = p
    except Exception:
        # 降级：fallback 到默认路径
        state_db_paths = {
            "default": Path.home() / ".hermes" / "state.db",
            "writer": Path.home() / ".hermes" / "profiles" / "writer" / "state.db",
        }
    state_db = state_db_paths.get(profile)
    if not state_db or not state_db.exists():
        return {"status": "error",
                "error": f"state.db 未找到: {state_db}"}

    try:
        import sqlite3
        conn = sqlite3.connect(str(state_db))
        for sid in session_ids:
            conn.execute("DELETE FROM messages WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM sessions WHERE id=?", (sid,))
            cleaned += conn.total_changes
        conn.commit()
        conn.close()
    except Exception as e:
        errors.append(str(e))

    return {
        "status": "completed" if not errors else "partial",
        "cleaned": cleaned,
        "errors": errors if errors else None,
    }


# ── CLI 入口 ──
def main():
    import argparse
    parser = argparse.ArgumentParser(description="UDG Archive Gate — 归档管线")
    parser.add_argument("action", choices=["run", "cleanup"],
                        help="run=运行管线, cleanup=清理会话")
    parser.add_argument("--cluster", default=None, help="cluster ID")
    parser.add_argument("--dry-run", action="store_true", help="预览模式")
    parser.add_argument("--phases", nargs="+", default=None,
                        help="运行哪些阶段（默认全部）")

    args = parser.parse_args()

    if args.action == "run":
        result = run_pipeline(
            cluster_id=args.cluster,
            phases=args.phases,
            dry_run=args.dry_run,
        )
    elif args.action == "cleanup":
        result = {"status": "not_implemented",
                  "note": "cleanup 请通过编排器调用"}

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") != "error" else 1


if __name__ == "__main__":
    sys.exit(main())
