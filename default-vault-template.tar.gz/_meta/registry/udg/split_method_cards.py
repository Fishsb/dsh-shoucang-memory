#!/usr/bin/env python3
"""
Split the 242KB Method Card file into independent entries.

This script reads the write_gate module and creates each new file.
"""
import sys
import os
from pathlib import Path

# Ensure write_gate is importable
sys.path.insert(0, str(Path(__file__).resolve().parent))
from write_gate import batch_write, write_wiki_file

# ── Config ──
SOURCE_PATH = Path("D:/lk/Obsidian/wiki/预skill/skills/dev/fix/codex-核心插件项目文档说明书-完整源码重建版.md")

SUPERSEDED_BY = [
    "knowledge-base-architecture-overview",
    "knowledge-base-knowledge-types",
    "knowledge-base-mcp-tools-kb-server",
    "knowledge-base-sabc-confidence-tiering",
    "knowledge-base-m1-m6-quality-gates",
    "knowledge-base-write-post-hooks",
    "knowledge-base-archive-integration",
    "orchestrator-core-principle",
    "orchestrator-five-irreducible-facts",
    "orchestrator-four-gates-pipeline",
    "orchestrator-module-a-understand",
    "orchestrator-module-b-plan",
    "orchestrator-module-c-execute-verify",
    "orchestrator-module-d-synthesize-learn",
    "orchestrator-module-e-audit",
    "orchestrator-tool-integration",
    "archive-behavior-matrix",
    "archive-pipeline-phases",
    "archive-mcp-tools-archive-server",
    "archive-cron-scheduling",
    "archive-scripts-reference",
    "archive-rebuild-checklist",
]


def make_method_card(title, workflow_body, checklist_items,
                     domain="hermes", target="workflow", tags=None):
    """Build a Method Card with standard 4-section format."""
    if tags is None:
        tags = [f"domain/{domain}", f"target/{target}", "type/methodology"]
    
    overview = f"本文档描述 {domain} 领域的 {title} 方法。"
    
    when_to_use = f"适合需要对 {title} 进行标准化操作的场景。"

    content = f"""# 概述

{overview}

## 适用场景

{when_to_use}

## 工作流程

{workflow_body}

## 校验清单

{checklist_items}
"""
    return content


def make_note(title, content_body, domain="hermes"):
    """Build a note-style document."""
    content = f"""# {title}

{content_body}
"""
    return content


def clean_content(text: str) -> str:
    """Remove JSON dump residuals and normalize whitespace."""
    import re
    # Remove lines that are pure JSON array values like "1.0.0",
    text = re.sub(r'^"[^"]*",?\s*$', '', text, flags=re.MULTILINE)
    # Remove standalone JSON closing braces
    text = re.sub(r'^}\s*$', '', text, flags=re.MULTILINE)
    # Remove standalone opening braces
    text = re.sub(r'^{\s*$', '', text, flags=re.MULTILINE)
    # Remove lines like `  "key": "value",`
    text = re.sub(r'^\s+"[^"]+":\s*".*",?\s*$', '', text, flags=re.MULTILINE)
    # Clean up excessive blank lines
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


# ══════════════════════════════════════════════════
# Content extraction helpers
# ══════════════════════════════════════════════════

def section_architecture():
    """## 附录：Architecture (line 1806)"""
    workflow = """1. 了解 Codex Plugin 目录结构：`~/.codex/plugins/knowledge-base/`
2. `kb/` 目录包含：
   - `knowledge.db` — SQLite 主数据库（HermesDB schema）
   - `scripts/` — kb_search.py, kb_write.py, kb_maintenance.py
   - `mcp/` — kb_server.py（MCP 知识库服务器）
3. 数据库层处理 FTS5 全文搜索与向量搜索
4. 脚本层提供搜索、写入、维护功能
5. MCP 服务器层将功能暴露为 MCP Tool"""
    
    checklist = """- [ ] 了解 knowledge-base 插件目录结构
- [ ] 理解 knowledge.db 的作用
- [ ] 掌握 scripts/ 中各脚本职责
- [ ] 理解 MCP 服务器的角色"""
    
    return make_method_card(
        "Knowledge Base 插件架构",
        workflow,
        checklist,
        domain="hermes",
        target="architecture",
        tags=["domain/hermes", "target/architecture", "type/methodology"]
    )


def section_knowledge_types():
    """## 附录：Knowledge Types (10 types) (line 1829)"""
    workflow = """Knowledge Base 支持 10 种知识类型，按使用频率和生命周期分类：

| Type | Write Freq | Read Freq | Lifecycle | Example |
|:-----|:--------:|:-------:|:---------|:-------|
| **config** | Low | High | Permanent | Env vars, paths, config |
| **rule** | Low | Very High | Permanent | Behavior constraints, safety rules |
| **workflow** | Medium | High | Long-term | Multi-step workflows |
| **knowledge** | Medium | High | Long-term | Methodology, tech concepts |
| **reference** | Low | High | Permanent | Parameter tables, command refs |
| **error** | Medium | High (when failing) | Permanent | Error stack + resolution |
| **session** | High | Low | Short->summary | Decision records (distilled after archive) |
| **project** | Medium | High | Project cycle | Project status, specs |

选择知识类型的决策步骤：
1. 评估数据的写入频率和读取频率
2. 判断生命周期的长短（永久/长期/短期）
3. 根据类型示例匹配合适分类
4. 写入时附带正确的 type 字段"""
    
    checklist = """- [ ] 知识条目有明确的 type 字段
- [ ] 写入频率与读取频率匹配所选的 type
- [ ] 生命周期描述准确
- [ ] 示例与实际情况一致"""
    
    return make_method_card(
        "Knowledge Base 知识类型定义",
        workflow,
        checklist,
        domain="hermes",
        target="reference",
        tags=["domain/hermes", "target/reference", "type/methodology"]
    )


def section_mcp_tools_kb():
    """## 附录：MCP Tools (via kb-server) (line 1850)"""
    workflow = """Knowledge Base 提供以下 MCP Tool：

1. **kb_search(query)** — 搜索 KB（FTS5 + 可选向量搜索）
   - 查询参数：自然语言查询字符串
   - 返回：匹配的知识条目列表

2. **kb_get(id)** — 精确 ID 查询
   - 参数：条目 ID
   - 返回：单个条目的完整内容

3. **kb_write(type, title, content, tags)** — 写入知识（M1-M6 门控）
   - 参数：类型、标题、内容、标签
   - 自动触发 M1-M6 质量门控检查

4. **kb_stats()** — 统计信息
   - 返回：KB 的统计概览

5. **kb_flag(id, reason)** — 标记不可靠
   - 用于标记置信度低的条目"""
    
    checklist = """- [ ] 熟悉 5 个 KB MCP Tool 的功能
- [ ] 掌握 kb_write 的调用参数
- [ ] 了解 kb_flag 的使用场景"""
    
    return make_method_card(
        "Knowledge Base MCP Tools",
        workflow,
        checklist,
        domain="hermes",
        target="tools",
        tags=["domain/hermes", "target/tools", "type/methodology"]
    )


def section_sabc():
    """## 附录：SABC Confidence Tiering (line 1865)"""
    workflow = """### SABC 置信度分级

| Tier | Score | Meaning | Search behavior |
|:----:|:----:|:--------|:---------------|
| **S** | >= 90 | Core high-frequency | Auto-pinned |
| **A** | 60-89 | Reliable | Normal recall, 0.8x weight |
| **B** | 30-59 | Pending verification | Weighted down, 0.65x weight |
| **C** | < 30 | Low confidence/flagged | Visible only with `include_low=true` |

### 置信度更新机制（事件驱动，无 Cron）

| Event | Effect | Cap/floor |
|:------|:-------|:---------:|
| Search hit | confidence +2 | Cap 100 |
| Isotopic replacement (similar new entry) | same-domain similar -5/-10/-20 | Floor 30 |
| flag marking | confidence -> 20 | Immediate |
| deprecated | confidence -> 10 | status changes too |
"""
    
    checklist = """- [ ] 每个知识条目有正确的 SABC 置信度分级
- [ ] 置信度更新机制正常运行
- [ ] flag 标记正确降低置信度到 20
- [ ] deprecated 标记正确降低置信度到 10"""
    
    return make_method_card(
        "SABC 置信度分级体系",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_m1m6():
    """## 附录：M1-M6 Quality Gates (line 1892)"""
    workflow = """每次写入 KB 前必须通过 M1-M6 质量门控：

| # | Criterion | Meaning | Violation consequence |
|:-:|:----------|:--------|:---------------------|
| M1 | **Reusable method** | Detached from current scene | Search hit unusable |
| M2 | **Abstract** | Removed concrete time/path/session ID | Next search outdated |
| M3 | **Semantically independent** | Understandable without original conversation | Knowledge island |
| M4 | **Stable persistent** | Valid for > 30 days | KB bloat |
| M5 | **Complete narration** | Has background + steps + notes | User queries again |
| M6 | **Actionable result** | Has Method Card core sections | Downgraded to reference |

### Decision Tree

```
M1? -> No -> Skip write
M1? -> Yes -> M2? -> No -> Skip write
M2? -> Yes -> M3? -> No -> Skip write
M3? -> Yes -> M4? -> No -> Skip write
M4? -> Yes -> M5? -> No -> Skip write
M5? -> Yes -> (M6? -> Yes -> type=knowledge/workflow | No -> type=reference)
```"""
    
    checklist = """- [ ] M1：内容是否脱离当前场景可复用？
- [ ] M2：是否已移除具体时间/路径/session ID？
- [ ] M3：无需原始对话即可理解？
- [ ] M4：有效期超过 30 天？
- [ ] M5：有背景、步骤和备注？
- [ ] M6：有 Method Card 核心章节？"""
    
    return make_method_card(
        "M1-M6 质量门控体系",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_post_hooks():
    """## 附录：Write Post-hooks (line 1929)"""
    workflow = """每次 `kb_write()` 自动触发 3 个后置钩子：

1. **Isotopic replacement decay** (_isotopic_replacement)
   - Same domain + same tags → by cosine similarity
   - >= 0.85 → -20 + supersedes mark
   - 0.70-0.84 → -10
   - 0.50-0.69 → -5
   - Floor 30

2. **Conflict detection** (_conflict_detection)
   - FAISS nearest neighbor (>= 0.80) + polar keyword comparison
   - Found conflict → flag (confidence=20)

3. **Merge trigger** (_merge_trigger)
   - Same type+domain active items > 5 AND last merge > 24h
   - Trigger async merge script"""
    
    checklist = """- [ ] 同位替换衰减正确按相似度降分
- [ ] 冲突检测正确标记（FAISS >= 0.80 + 极性词比较）
- [ ] 合并触发器在条件满足时触发
- [ ] 所有操作都在 Floor 30 之上"""
    
    return make_method_card(
        "Knowledge Base 写入后置钩子",
        workflow,
        checklist,
        domain="hermes",
        target="workflow",
        tags=["domain/hermes", "target/workflow", "type/methodology"]
    )


def section_archive_integration():
    """## 附录：Integration with Archive (line 1956)"""
    workflow = """1. Archive Phase 3 LLM refine 输出直接进入 KB
2. 通过 `kb_write()` 写入知识库
3. 每个方法论写入自动通过 M1-M6 门控检查"""
    
    checklist = """- [ ] Archive 输出正确路由到 KB
- [ ] 写入通过 M1-M6 检查
- [ ] 知识类型正确分类"""
    
    return make_method_card(
        "Knowledge Base 与 Archive 集成",
        workflow,
        checklist,
        domain="hermes",
        target="integration",
        tags=["domain/hermes", "target/integration", "type/methodology"]
    )


# ── Orchestrator sections ──

def section_core_principle():
    """## 附录：Core Principle (line 2906)"""
    workflow = """Orchestrator 的核心原则：

> Do not execute directly — only decompose, dispatch, verify, and aggregate.

当收到复杂目标 G 时，严格遵循 4-Gate 管线：
- **不执行**具体工作
- **只做**分解、分派、验证和聚合
- 将实际工作委托给子代理（subagents）
- 验证子代理的输出质量"""
    
    checklist = """- [ ] 不越界执行子代理的工作
- [ ] 严格遵循 4-Gate 管线
- [ ] 每次委托都有验证环节"""
    
    return make_method_card(
        "Orchestrator 核心原则",
        workflow,
        checklist,
        domain="hermes",
        target="principle",
        tags=["domain/hermes", "target/principle", "type/methodology"]
    )


def section_five_facts():
    """## 附录：The 5 Irreducible Facts (line 2911)"""
    workflow = """Orchestrator 的 5 个不可约事实：

| # | Fact | Meaning |
|:-:|------|---------|
| F1 | Orchestrator receives a user goal **G** | No input = no work |
| F2 | Orchestrator **does not execute** work | Orchestrator = delegate + verify |
| F3 | Knowledge base is queryable and writable | History is reusable |
| F4 | Subagents have capacity limits | Large tasks must be decomposed |
| F5 | Results must be verifiable | No verify = no done |

这些事实是所有编排器设计决策的基础约束。"""
    
    checklist = """- [ ] 明确当前目标 G（F1）
- [ ] 不执行子代理工作（F2）
- [ ] 查询 KB 获取历史经验（F3）
- [ ] 大型任务正确分解（F4）
- [ ] 所有结果可验证（F5）"""
    
    return make_method_card(
        "Orchestrator 5 个不可约事实",
        workflow,
        checklist,
        domain="hermes",
        target="principle",
        tags=["domain/hermes", "target/principle", "type/methodology"]
    )


def section_four_gates():
    """## 附录：The 4 Gates (line 2926)"""
    workflow = """### 4-Gate Pipeline

```
G --> Module A (Understand) --> G1 Gate --> Module B (Plan) --> G2 Gate
--> Module C (Execute & Verify) --> G3 Gate --> Module D (Synthesize & Learn)
--> G4 Gate --> Deliver to User

Module E (Audit) runs cross-session in background
```

### Gate Prerequisites

| Gate | Question | Derived from |
|:----:|----------|:------------:|
| **G1 Goal Clear** | Do I know exactly what G means? | F1 |
| **G2 Plan Feasible** | Is the decomposition correct? Each block verifiable? | F2 + F4 |
| **G3 Result Reliable** | Is each block independently verified? | F5 |
| **G4 Delivery Complete** | Aggregated? Learned? Zero residue? | F3 |
"""
    
    checklist = """- [ ] G1：目标 G 清晰定义
- [ ] G2：计划正确，每个块可验证
- [ ] G3：每个块独立验证通过
- [ ] G4：结果聚合，学习完成，无残留"""
    
    return make_method_card(
        "Orchestrator 4-Gate 管线",
        workflow,
        checklist,
        domain="hermes",
        target="pipeline",
        tags=["domain/hermes", "target/pipeline", "type/methodology"]
    )


def section_module_a():
    """## 附录：Module A: Understand (line 2953)"""
    workflow = """**Goal**: Refine fuzzy raw goal G into actionable G': clear boundary + verification criteria + uncertainty resolved.

### A1 - Knowledge Retrieval
1. Search Codex session history and memories for related past work
2. Read the Knowledge Base via `kb_search` MCP tool for relevant methodologies
3. Load relevant installed Skill descriptions as reference

### A2 - Uncertainty Classification
After retrieval, classify uncertainties in G:
- `fact_uncertain`: version numbers, API params, tool behavior → **Verify with web_search, NEVER ask the user**
- `intent_uncertain`: direction choices, boundary definitions → **Clarify back to the user**
- `mixed_uncertain`: both fact and intent components → **Parallel: ask user + web_search**
- `scope_uncertain`: task scope is fuzzy → **Ask user to clarify scope first**

### A3 - Force Three Self-Check (before every clarification)
```
Q1: Am I making a directional decision for the user?
Q2: Is this information only the user can provide?
Q3: Am I assuming "the user would probably..." instead of asking?
Any "yes" → MUST clarify
```

### Gate G1 - Goal Clear
- [ ] G' boundary is clear (what's in, what's out)
- [ ] G' verification criteria are clear
- [ ] Uncertainty classification has been executed
- [ ] Force Three has been executed
- [ ] All necessary clarifying questions have been asked"""
    
    checklist = """- [ ] G' 边界清晰（定义范围）
- [ ] G' 验证标准明确
- [ ] 不确定性已分类（fact/intent/mixed/scope）
- [ ] Force Three 自检已执行
- [ ] 所有必要的澄清问题已提出"""
    
    return make_method_card(
        "Orchestrator Module A：理解阶段",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_module_b():
    """## 附录：Module B: Plan (line 3012)"""
    workflow = """**Goal**: Generate executable plan P = {task list, dependency DAG, context mapping}

### B1 - WBS Decomposition (Core!)
Follow **MECE** principle: Mutually Exclusive, Collectively Exhaustive.

**Atomicity Stop Conditions** (ALL must be true):
| # | Condition | Meaning |
|:-:|-----------|---------|
| A1 | Single verifiable deliverable | Output independently verifiable |
| A2 | Single execution domain | Only one tool set needed |
| A3 | No internal parallelism | Splitting would add coordination cost |
| A4 | Within single subagent capacity | One subagent can do it alone |

Max recursion depth: 3 levels.

**Output format**:
```
Level 0: G' -> [S1, S2, S3]
  +-- S1: Atomic? [No] -> recursive
  |     +-- [S1a, S1b]
  |           +-- S1a: Atomic? [Yes]
  |           +-- S1b: Atomic? [Yes]
  +-- S2: Atomic? [Yes]
  +-- S3: Atomic? [Yes]
```
Dependency markers: `[P]` parallel / `[C]` context-depends / `[D]` data-depends

### B2 - Success Criteria
Each task must have verifiable success criteria:
- `[Yes] Verifiable`: "File written to /tmp/X.conf containing Y"
- `[No] Not verifiable`: "Configuration optimized"

### B3 - Dependency DAG
| Relationship | Mark | Handling |
|:------------|:----:|:---------|
| A needs B's output value | `[D]` true dependency | Serial |
| A only needs B's context | `[C]` context dependency | Parallel after context injection |
| A, B independent | `[P]` parallel | Full parallel |

### B4 - Parallelism Optimization
Topological sort by DAG → Layer 0 all parallel → Layer N depends on previous → parallel within layer, serial between layers.

### B5 - Sub-task Context Construction
Each sub-task gets a **self-contained context**: goal, file paths, config, boundary conditions, neighbor info, tool set, verification checklist.

### Gate G2 - Plan Feasible
- [ ] Sub-tasks MECE
- [ ] Each sub-task has verifiable success criteria
- [ ] Dependency DAG has no cycles
- [ ] Context contains sufficient information source
- [ ] Parallelism is maximized
- [ ] All sub-tasks satisfy 4 atomicity conditions"""
    
    checklist = """- [ ] WBS 分解遵循 MECE 原则
- [ ] 所有子任务满足 A1-A4 原子性条件
- [ ] 依赖 DAG 无循环
- [ ] 子任务上下文自包含
- [ ] 并行度已最大化
- [ ] G2 门控全部通过"""
    
    return make_method_card(
        "Orchestrator Module B：规划阶段",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_module_c():
    """## 附录：Module C: Execute & Verify (line 3115)"""
    workflow = """**Goal**: Transform plan P into verified result set.

### C1 - Layer-by-Layer Dispatch
1. Dispatch by dependency DAG layers (Layer 0 → Layer 1 → ...)
2. All tasks within a layer dispatched **in parallel** to subagents
3. Wait for all subagents in current layer before dispatching next
4. Each subagent receives: `goal`, `context` (self-contained), restricted tool set

### C2 - Per-block Verification (Critical!)
**Verify as each subagent returns, not waiting for all.**

| Output type | Verification method |
|:-----------|:-------------------|
| File write | Read back file content, item-by-item check |
| Web research | Cross-verify (second subagent independently checks) |
| Code changes | Read back + syntax check + logical audit |
| Information synthesis | Require original source citations |

**Found hallucination → immediately goto C3 fix, do NOT wait for other subagents.**

### C3 - Bug Fix Loop (FIX_LOOP)
```
Record defect → Reconstruct context → Re-dispatch → Re-verify
  → Converged → [Yes] Done
  → Not converging → Record to KB + notify user
```

Escalation chain:
1. Auto-retry (same goal + context)
2. Retry with reconstructed context (more detailed guidance)
3. Record as known limitation, notify user

### Gate G3 - Result Reliable
- [ ] ALL sub-tasks verified (zero omissions)
- [ ] No hallucinated output
- [ ] All defects have converged
- [ ] Fact claims have sources"""
    
    checklist = """- [ ] 按 DAG 层级分派任务
- [ ] 每层内并行执行
- [ ] 每块返回时立即验证（不等全部）
- [ ] 发现幻觉 → 立即 G3 修复
- [ ] 升级链：重试 → 重构上下文 → 记录限制"""
    
    return make_method_card(
        "Orchestrator Module C：执行与验证阶段",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_module_d():
    """## 附录：Module D: Synthesize & Learn (line 3176)"""
    workflow = """**Goal**: Transform verified results into deliverable + KB update.

### D1 - Merge and Deduplicate
1. Remove "subagent1 says... subagent2 says..." framing
2. Duplicate content kept once only
3. Arrange by WBS structure logical order

### D2 - Consistency Resolution
When cross-sub-task conclusions conflict:
1. Trace back to original data (subagent raw output)
2. Rely on verifiable data
3. Cannot decide → ask user

### D3 - Format Standardization
- Conclusion first
- Structure: Background → Approach → Result → Notes
- Delivery report includes WBS retrospective

### D4 - Knowledge Solidification
Write reusable experience to Knowledge Base:
- **Only write methodology** (how to do it), not raw data
- Must pass M1-M6 quality gates
- Follow Wiki-目录格式规范.md format
- Use kb_write() with Wiki-spec fields

### Gate G4 - Delivery Complete
- [ ] User's requested output is delivered
- [ ] Knowledge Base has been updated (D4 executed)
- [ ] No content added beyond scope
- [ ] Directional choices have user source; mark unverified assumptions

All pass → Deliver."""
    
    checklist = """- [ ] 合并并去重，去除 subagent 框架
- [ ] 一致性冲突已解决
- [ ] 格式按 Background → Approach → Result → Notes
- [ ] D4 知识固化已执行
- [ ] G4 门控全部通过"""
    
    return make_method_card(
        "Orchestrator Module D：综合与学习阶段",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_module_e():
    """## 附录：Module E: Audit (Cross-session) (line 3241)"""
    workflow = """**Non-blocking** to current task. Runs continuously across sessions:

1. Record task types and duration
2. Track Gate pass rates
3. Track self-execution rate (did orchestrator do work it should have delegated?)
4. Identify recurring bottleneck patterns

Audit data is used for self-improvement: **same mistake not repeated**."""
    
    checklist = """- [ ] 跨会话审计不阻塞当前任务
- [ ] 审计数据记录任务类型和时长
- [ ] 门控通过率已跟踪
- [ ] 自执行率已监控
- [ ] 瓶颈模式已识别"""
    
    return make_method_card(
        "Orchestrator Module E：审计阶段",
        workflow,
        checklist,
        domain="hermes",
        target="methodology",
        tags=["domain/hermes", "target/methodology", "type/methodology"]
    )


def section_tool_integration():
    """## 附录：Tool Integration (line 3254)"""
    workflow = """### MCP Tools (via orchestrator-server)
| Tool | Function |
|:-----|:---------|
| `wbs_create(goal, context)` | Create WBS decomposition |
| `wbs_get(id)` | Get WBS state |
| `wbs_update(id, status)` | Update task status |
| `wbs_status(id)` | Get full pipeline status |

### Knowledge Base Integration
- Orchestrator uses `kb_search()` via knowledge-base plugin MCP for context retrieval
- Orchestrator uses `kb_write()` via knowledge-base plugin MCP for knowledge solidification (D4)
- Orchestrator only **reads** KB; writes are done by subagents"""
    
    checklist = """- [ ] 熟悉 orchestrator 的 MCP 工具
- [ ] 了解 wbs_create/wbs_get/wbs_update/wbs_status
- [ ] 理解 KB 集成模式（orchestrator 只读，子代理写）"""
    
    return make_method_card(
        "Orchestrator 工具集成",
        workflow,
        checklist,
        domain="hermes",
        target="tools",
        tags=["domain/hermes", "target/tools", "type/methodology"]
    )


# ── Session Archive sections ──

def section_behavior_matrix():
    """## 附录：Behavior Matrix (line 9576)"""
    workflow = """Session Archive 插件根据用户输入选择入口点：

| User action | Pipeline entry | Behavior |
|:------------|:---------------|:---------|
| No attachments, invokes plugin | Phase 0 (Scan) | Scan idle Codex sessions, user selects targets |
| Attaches file(s) or URL(s) | Phase A (Ingest) | Extract text → auto-cluster → Phases 3b-9 |
| Attaches both files and sessions | Phase A + Phase 0 parallel | Process separately |

当文件/URL 被附加且无其他指令时，插件默认行为：
1. Extract text from files/URLs
2. Create a single cluster with all extracted content
3. Auto-run Phases 3b-9 (type → name → tags → retrieve → write → validate → cleanup)"""
    
    checklist = """- [ ] 正确识别用户输入类型
- [ ] 无附件时走 Phase 0 扫描
- [ ] 有附件时走 Phase A 摄入
- [ ] 同时有时并行处理"""
    
    return make_method_card(
        "Session Archive 行为矩阵",
        workflow,
        checklist,
        domain="hermes",
        target="workflow",
        tags=["domain/hermes", "target/workflow", "type/methodology"]
    )


def section_archive_pipeline():
    """## 附录：The Archive Pipeline (Phase A + 9 Phases) (line 9599)"""
    workflow = """### Pipeline Overview

```
Phase A: Ingest           → Extract text from files/URLs
Phase 0: Scan             → Identify idle sessions
Phase 1: User Select      → User confirms archive targets
Phase 2: Cluster          → Topic clustering preprocessing
Phase 3a: Refine          → Subagent methodology extraction (parallel)
Phase 3b: Type Detect     → Classify as Memory | Proto-skill | Mixed
Phase 4: Name Extract     → Extract subject-verb-object name
Phase 5: Tag Extract      → Three-level tag extraction
Phase 6: Retrieve         → Cross-session/KB search + merge/conflict
Phase 7: Writeback        → Write to KB (Obsidian _archive/ + SQLite KB)
Phase 8: Validate         → Validate written files
Phase 9: Cleanup          → Delete sessions on pass | Mark archived=1 on fail
```

### Phase A - File/URL Ingestion
Supported formats: .md, .txt, .py, .js, .ts, .json, .yaml, .toml, .csv, .log, .sh, .env, .pdf, .docx, .pptx, .xlsx, .xls, web URLs

### Phase 0 - Scan
Idle criteria: no activity for `idle_threshold_days` (default: 7), archived=0, messages > 2.

### Phase 3b - Type Detection
Signal-based scoring: step flow (+3), troubleshooting (+3), config (+3), method guide (+2), observation (+2), fact/preference (+2), knowledge reference (+2).

### Phase 4 - Name Extraction
Format: `<subject>-<object>-<verb>`. Scan title + topic + key messages, classify into subject/object/verb.

### Phase 5 - Tag Extraction
Three-level: domain/<L1>, target/<L2>, task/<L3>. Name-anchored content scan.
"""
    
    checklist = """- [ ] 理解各阶段的职责和顺序
- [ ] Phase A 支持所有声明格式
- [ ] Phase 3b 信号矩阵正确配置
- [ ] Phase 4 名称格式正确
- [ ] Phase 5 三级标签提取正确
- [ ] Phase 8 验证编码/frontmatter/章节/路径"""
    
    return make_method_card(
        "Archive 管线各阶段详解",
        workflow,
        checklist,
        domain="hermes",
        target="pipeline",
        tags=["domain/hermes", "target/pipeline", "type/methodology"]
    )


def section_archive_mcp_tools():
    """## 附录：MCP Tools (via archive-server) (line 9926)"""
    workflow = """Session Archive 提供以下 MCP Tool：

| Tool | Phase | Description |
|:-----|:------|:------------|
| `archive_ingest()` | Phase A | Ingest files/URLs and auto-run pipeline |
| `archive_scan()` | Phase 0 | Scan idle sessions, output list |
| `archive_select(ids)` | Phase 1 | Lock archive targets after user selection |
| `archive_cluster()` | Phase 2 | Cluster preprocessing |
| `archive_auto_cluster()` | Phase 0-2 | Scan unnamed idle sessions + cluster directly |
| `archive_detect_type()` | Phase 3b | Memory vs Proto-skill type detection |
| `archive_extract_name()` | Phase 4 | Subject-verb-object name extraction |
| `archive_extract_tags()` | Phase 5 | Three-level tag extraction |
| `archive_retrieve()` | Phase 6 | Cross-session/KB retrieval + merge |
| `archive_writeback()` | Phase 7+9 | Write KB (with cleanup) |
| `archive_validate()` | Phase 8 | Validate written files |
| `archive_run_pipeline()` | Phase 3b-9 | Full pipeline on single cluster |
| `archive_status()` | - | Query archive pipeline progress |"""
    
    checklist = """- [ ] 熟悉 13 个 archive MCP Tool
- [ ] 了解各工具对应的管线阶段
- [ ] 掌握 archive_run_pipeline() 的端到端用法"""
    
    return make_method_card(
        "Archive MCP Tools",
        workflow,
        checklist,
        domain="hermes",
        target="tools",
        tags=["domain/hermes", "target/tools", "type/methodology"]
    )


def section_cron_scheduling():
    """## 附录：Cron Scheduling (line 9957)"""
    workflow = """### Schedule Frequencies
| Archive type | Recommended frequency | Description |
|:-------------|:---------------------|:------------|
| Daily archive (unnamed) | Daily (0 2 * * *) | Auto-clean unnamed idle sessions |
| Deep archive (named) | Weekly (0 4 * * 0) | User-selectable named session archiving |

### Cron modes
| Mode | Behavior |
|:-----|:---------|
| `auto` | Phase 0 → auto-select unnamed → Phase 2-9 pipeline |
| `named` | Phase 2-9 on already-selected sessions (after user Phase 1) |
| `scan` | Phase 0 only (report only) |"""
    
    checklist = """- [ ] 每日归档 cron 正确配置
- [ ] 每周深度归档 cron 正确配置
- [ ] cron 模式选择正确（auto/named/scan）"""
    
    return make_method_card(
        "Archive Cron 调度方案",
        workflow,
        checklist,
        domain="hermes",
        target="workflow",
        tags=["domain/hermes", "target/workflow", "type/methodology"]
    )


# ── Notes ──

def note_scripts_reference():
    """## 附录：Scripts (line 9980)"""
    body = """| Script | Phase | Function |
|:-------|:------|:---------|
| `archive-ingestor.py` | A | File/URL text extraction + auto-pipeline |
| `archive-scanner.py` | 0 | Scan idle sessions |
| `archive-cluster.py` | 2 | Topic clustering + --refine mode |
| `archive-type-detector.py` | 3b | Signal-based Memory/Proto-skill classification |
| `archive-name-extractor.py` | 4 | Subject-verb-object name extraction |
| `archive-tag-extractor.py` | 5 | Three-level tag extraction |
| `archive-retriever.py` | 6 | Cross-session/KB retrieval + merge |
| `archive-writeback.py` | 7+9 | Write to Obsidian/SQLite + cleanup |
| `archive-validator.py` | 8 | File validation checks |
| `archive-cron-wrapper.py` | 0-9 | Full cron cycle orchestration |"""
    return make_note("Archive Scripts 参考表", body)


def note_rebuild_checklist():
    """## 附录：重建核对清单 (line 10005)"""
    body = """### Knowledge Base
- [ ] `.codex-plugin/plugin.json`
- [ ] `.mcp.json`
- [ ] `kb/scripts/kb_config.py`
- [ ] `kb/scripts/kb_config_proxy.py`
- [ ] `kb/scripts/spec_adapter.py`
- [ ] `kb/scripts/kb_write.py`
- [ ] `kb/scripts/kb_search.py`
- [ ] `kb/scripts/kb_maintenance.py`
- [ ] `kb/mcp/kb_server.py`
- [ ] `skills/knowledge-base/SKILL.md`

### Orchestrator
- [ ] `.codex-plugin/plugin.json`
- [ ] `.mcp.json`
- [ ] `mcp/orchestrator_server.py`
- [ ] `scripts/spec_adapter.py`
- [ ] `scripts/session_state.py`
- [ ] `scripts/wbs_template.py`
- [ ] `hooks/hooks.json`
- [ ] `hooks/session_start.py`
- [ ] `hooks/post_tool_use.py`
- [ ] `skills/orchestrator/SKILL.md`

### Session Archive
- [ ] `.codex-plugin/plugin.json`
- [ ] `.mcp.json`
- [ ] `mcp/archive_server.py`
- [ ] `scripts/archive-scanner.py`
- [ ] `scripts/archive-cluster.py`
- [ ] `scripts/archive-ingestor.py`
- [ ] `scripts/archive-name-extractor.py`
- [ ] `scripts/archive-tag-extractor.py`
- [ ] `scripts/archive-type-detector.py`
- [ ] `scripts/archive-retriever.py`
- [ ] `scripts/archive-validator.py`
- [ ] `scripts/archive-writeback.py`
- [ ] `scripts/archive-cron-wrapper.py`
- [ ] `scripts/spec_adapter.py`
- [ ] `skills/session-archive/SKILL.md`"""
    return make_note("Codex 插件重建核对清单", body)


# ══════════════════════════════════════════════════
# Main execution
# ══════════════════════════════════════════════════

if __name__ == "__main__":
    entries = []
    results = []

    # ── 20 Method Cards (pre_skill) ──

    # 1. KB Plugin sections
    entries.append({
        "target_type": "pre_skill",
        "title": "Knowledge Base 插件架构",
        "content": section_architecture(),
        "domain": "hermes",
        "target": "architecture",
        "frontmatter": {
            "name": "knowledge-base-architecture-overview",
            "tags": ["domain/hermes", "target/architecture", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Knowledge Base 知识类型定义",
        "content": section_knowledge_types(),
        "domain": "hermes",
        "target": "reference",
        "frontmatter": {
            "name": "knowledge-base-knowledge-types",
            "tags": ["domain/hermes", "target/reference", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Knowledge Base MCP Tools",
        "content": section_mcp_tools_kb(),
        "domain": "hermes",
        "target": "tools",
        "frontmatter": {
            "name": "knowledge-base-mcp-tools-kb-server",
            "tags": ["domain/hermes", "target/tools", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "SABC 置信度分级体系",
        "content": section_sabc(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "knowledge-base-sabc-confidence-tiering",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "M1-M6 质量门控体系",
        "content": section_m1m6(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "knowledge-base-m1-m6-quality-gates",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Knowledge Base 写入后置钩子",
        "content": section_post_hooks(),
        "domain": "hermes",
        "target": "workflow",
        "frontmatter": {
            "name": "knowledge-base-write-post-hooks",
            "tags": ["domain/hermes", "target/workflow", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Knowledge Base 与 Archive 集成",
        "content": section_archive_integration(),
        "domain": "hermes",
        "target": "integration",
        "frontmatter": {
            "name": "knowledge-base-archive-integration",
            "tags": ["domain/hermes", "target/integration", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    # 2. Orchestrator sections
    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator 核心原则",
        "content": section_core_principle(),
        "domain": "hermes",
        "target": "principle",
        "frontmatter": {
            "name": "orchestrator-core-principle",
            "tags": ["domain/hermes", "target/principle", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator 5 个不可约事实",
        "content": section_five_facts(),
        "domain": "hermes",
        "target": "principle",
        "frontmatter": {
            "name": "orchestrator-five-irreducible-facts",
            "tags": ["domain/hermes", "target/principle", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator 4-Gate 管线",
        "content": section_four_gates(),
        "domain": "hermes",
        "target": "pipeline",
        "frontmatter": {
            "name": "orchestrator-four-gates-pipeline",
            "tags": ["domain/hermes", "target/pipeline", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator Module A：理解阶段",
        "content": section_module_a(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "orchestrator-module-a-understand",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator Module B：规划阶段",
        "content": section_module_b(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "orchestrator-module-b-plan",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator Module C：执行与验证阶段",
        "content": section_module_c(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "orchestrator-module-c-execute-verify",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator Module D：综合与学习阶段",
        "content": section_module_d(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "orchestrator-module-d-synthesize-learn",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator Module E：审计阶段",
        "content": section_module_e(),
        "domain": "hermes",
        "target": "methodology",
        "frontmatter": {
            "name": "orchestrator-module-e-audit",
            "tags": ["domain/hermes", "target/methodology", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Orchestrator 工具集成",
        "content": section_tool_integration(),
        "domain": "hermes",
        "target": "tools",
        "frontmatter": {
            "name": "orchestrator-tool-integration",
            "tags": ["domain/hermes", "target/tools", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    # 3. Session Archive sections
    entries.append({
        "target_type": "pre_skill",
        "title": "Session Archive 行为矩阵",
        "content": section_behavior_matrix(),
        "domain": "hermes",
        "target": "workflow",
        "frontmatter": {
            "name": "archive-behavior-matrix",
            "tags": ["domain/hermes", "target/workflow", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Archive 管线各阶段详解",
        "content": section_archive_pipeline(),
        "domain": "hermes",
        "target": "pipeline",
        "frontmatter": {
            "name": "archive-pipeline-phases",
            "tags": ["domain/hermes", "target/pipeline", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Archive MCP Tools",
        "content": section_archive_mcp_tools(),
        "domain": "hermes",
        "target": "tools",
        "frontmatter": {
            "name": "archive-mcp-tools-archive-server",
            "tags": ["domain/hermes", "target/tools", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    entries.append({
        "target_type": "pre_skill",
        "title": "Archive Cron 调度方案",
        "content": section_cron_scheduling(),
        "domain": "hermes",
        "target": "workflow",
        "frontmatter": {
            "name": "archive-cron-scheduling",
            "tags": ["domain/hermes", "target/workflow", "type/methodology"],
            "lifecycle": "draft",
        }
    })

    # 4. Notes
    entries.append({
        "target_type": "note",
        "title": "Archive Scripts 参考表",
        "content": note_scripts_reference(),
        "domain": "hermes",
        "frontmatter": {
            "name": "archive-scripts-reference",
            "tags": ["domain/hermes", "type/reference"],
        }
    })

    entries.append({
        "target_type": "note",
        "title": "Codex 插件重建核对清单",
        "content": note_rebuild_checklist(),
        "domain": "hermes",
        "frontmatter": {
            "name": "archive-rebuild-checklist",
            "tags": ["domain/hermes", "type/reference"],
        }
    })

    # ── Execute batch write ──
    print(f"Total entries to write: {len(entries)}")
    results = batch_write(entries)

    success = 0
    errors = 0
    for r in results:
        status = r.get("status", "ERROR")
        path = r.get("file_path", "N/A")
        print(f"  [{status}] {path}")
        if status in ("created", "updated"):
            success += 1
        elif status == "error":
            errors += 1
            print(f"    ERROR: {r.get('error', 'unknown')}")
        else:
            print(f"    {r}")

    print(f"\nDone. {success} succeeded, {errors} failed out of {len(entries)}.")
