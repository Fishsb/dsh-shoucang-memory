#!/usr/bin/env python3
"""spec_reader.py — 从 registry.yaml 动态加载知识库格式规则

🔒 受 bypass_inspector 保护（registry.yaml bypass.protected_paths）
——禁止在此文件中新增硬编码值。任何新规则必须写入 registry.yaml 后再通过 reader 读取。
——所有 _fallback_* 函数是"倒忙降级"用，registry.yaml 正常时永不触发。
——如需修改规则，只改 registry.yaml §archive / §kb。

采用与 registry_loader.py 相同的降级模式：registry.yaml 不可读时
返回最小功能集，管线不崩溃。

左移设计：改规则只改 registry.yaml 一处 → spec_reader 自动生效。
"""

import logging
import json
import re
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# ── 运行时 fallback 追踪（防无声降级）──
_FALLBACK_ACTIVE = False  # 任何 _fallback_* 被调用时改为 True
_BYPASS_LOG = None


def _get_bypass_log() -> Path:
    global _BYPASS_LOG
    if _BYPASS_LOG:
        return _BYPASS_LOG
    try:
        reg = _load_yaml()
        p = reg.get("bypass", {}).get("log_path", "")
        if "${hermes_home}" in p:
            p = p.replace("${hermes_home}", str(Path.home() / "AppData/Local/hermes"))
        if p:
            _BYPASS_LOG = Path(p)
            return _BYPASS_LOG
    except Exception:
        pass
    _BYPASS_LOG = Path.home() / "AppData/Local/hermes/logs/bypass.log"
    return _BYPASS_LOG


def _warn_fallback(func_name: str, hint: str = ""):
    """记录 fallback 触发到 bypass.log（registry.yaml 不可读时无声降级会遗漏）。"""
    global _FALLBACK_ACTIVE
    _FALLBACK_ACTIVE = True
    msg = f"[SPEC_READER_FALLBACK] {func_name} 使用 fallback 值: {hint}"
    logger.warning(msg)
    try:
        log_path = _get_bypass_log()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "detected_at": __import__("datetime").datetime.now().isoformat(),
                "module": "spec_reader",
                "function": func_name,
                "message": f"registry.yaml 不可读，使用 fallback: {hint}",
            }, ensure_ascii=False) + "\n")
    except Exception:
        pass


def check_fallback_status() -> dict:
    """检查是否有任何 spec_reader 函数使用了 fallback 值。

    返回:
        {"fallback_active": bool, "message": str}
        如果 fallback_active=True，表示 registry.yaml 可能不可读。
    """
    return {
        "fallback_active": _FALLBACK_ACTIVE,
        "message": "Fallback 已触发 — registry.yaml 可能不可读，请检查"
        if _FALLBACK_ACTIVE else "All values loaded from registry.yaml",
    }

# ── 自动发现位置 ──
_LOADER_DIR = Path(__file__).resolve().parent
_REGISTRY_DIR = _LOADER_DIR.parent  # _meta/registry/
_REGISTRY_YAML = _REGISTRY_DIR / "registry.yaml"


# ═══════════════════════════════════════════════════
# 核心加载
# ═══════════════════════════════════════════════════

def _load_yaml():
    """加载 registry.yaml"""
    try:
        import yaml
        raw = _REGISTRY_YAML.read_text(encoding="utf-8")
        return yaml.safe_load(raw)
    except Exception as e:
        logger.warning(f"registry.yaml 加载失败: {e}")
        return None


def _get(data, *keys, default=None):
    """安全嵌套取值。"""
    for k in keys:
        if not isinstance(data, dict):
            return default
        data = data.get(k)
    return data if data is not None else default


# ═══════════════════════════════════════════════════
# R1: 字段顺序（源自 kb.frontmatter_field_orders）
# ═══════════════════════════════════════════════════

def load_field_order(type_name: str) -> list[str]:
    """返回指定类型的 frontmatter 字段顺序列表。

    Args:
        type_name: pre_skill / memory / note

    Returns:
        list[str]: 字段名列表，按 spec §2.x 定义的顺序
    """
    data = _load_yaml()
    orders = _get(data, "kb", "frontmatter_field_orders")
    if orders and type_name in orders:
        return [f.strip() for f in orders[type_name] if f.strip()]
    return _fallback_field_order(type_name)


def _fallback_field_order(type_name: str) -> list[str]:
    """降级：返回最小字段顺序"""
    _warn_fallback("_fallback_field_order", f"type={type_name}")
    common = ["type", "name", "title", "tags"]
    if type_name == "memory":
        return common + ["subtype", "confidence", "created", "updated", "source"]
    return common + ["confidence", "created", "updated", "source", "description"]


# ═══════════════════════════════════════════════════
# R2: 谓词表（源自 archive.predicate_table = §1.1.3）
# ═══════════════════════════════════════════════════

def load_predicate_table() -> list[str]:
    """返回谓词表。"""
    data = _load_yaml()
    preds = _get(data, "archive", "predicate_table")
    if preds:
        return [p.strip() for p in preds if p.strip()]
    return _fallback_predicate_table()


def _fallback_predicate_table() -> list[str]:
    _warn_fallback("_fallback_predicate_table")
    return ["配置方法", "部署教程", "故障排查", "调研报告",
            "note", "guide", "setup", "fix", "reference", "参考"]


# ═══════════════════════════════════════════════════
# R3: 必要章节（源自 kb.required_sections = §2.3.6）
# ═══════════════════════════════════════════════════

def load_required_sections(type_name: str = "pre_skill") -> list[str]:
    """返回指定类型的必要 Markdown 章节头列表（含 ## 前缀）。"""
    data = _load_yaml()
    sections = _get(data, "kb", "required_sections")
    if sections and type_name in sections:
        return [s.strip() for s in sections[type_name] if s.strip()]
    if type_name == "pre_skill":
        return ["## 概述", "## 工作流程"]  # 最小集合
    return []


def check_section_present(section_header: str, body: str) -> bool:
    """检查正文是否包含某章节头（大小写不敏感）。"""
    pattern = r"(?:^|\n)\s*" + re.escape(section_header) + r"\s*$"
    return bool(re.search(pattern, body, re.MULTILINE | re.IGNORECASE))


# ═══════════════════════════════════════════════════
# R4: 必填 frontmatter 字段（源自 kb.required_frontmatter = §1.3）
# ═══════════════════════════════════════════════════

def load_required_frontmatter(type_name: str) -> list[str]:
    """返回指定类型文件必须包含的 frontmatter 字段名列表。"""
    data = _load_yaml()
    required = _get(data, "kb", "required_frontmatter")
    if required and type_name in required:
        return [f.strip() for f in required[type_name] if f.strip()]
    return ["type", "name", "title", "tags", "confidence", "created", "updated"]


# ═══════════════════════════════════════════════════
# R5: 类型检测信号 + 阈值 + 默认值（源自 archive.type_detection）
# ═══════════════════════════════════════════════════

def load_type_signals() -> list[dict]:
    """返回类型检测信号模式列表。

    每条: {"pattern": str, "proto": int, "memory": int}
    """
    data = _load_yaml()
    signals = _get(data, "archive", "type_detection", "signals")
    if signals:
        return [
            {"pattern": s["pattern"], "proto": int(s["proto"]), "memory": int(s["memory"])}
            for s in signals if isinstance(s, dict)
        ]
    return _fallback_type_signals()


def _fallback_type_signals() -> list[dict]:
    _warn_fallback("_fallback_type_signals")
    return [
        {"pattern": r"(步骤|第一步|然后|接下来|最后|完成)", "proto": 3, "memory": 0},
        {"pattern": r"(error|fix|repair|resolve)", "proto": 3, "memory": 0},
        {"pattern": r"(install|config|setup|deploy)", "proto": 3, "memory": 0},
        {"pattern": r"(found|noticed|discovered)", "proto": 0, "memory": 2},
        {"pattern": r"(prefer|like|favor|偏好)", "proto": 0, "memory": 2},
    ]


def load_type_thresholds() -> dict:
    """返回类型判定阈值。

    返回:
        {"pre_skill": {"proto_min": 5},
         "memory": {"proto_max": 3, "memory_min": 4},
         "mixed": {"proto_min": 3, "memory_min": 3}}
    """
    data = _load_yaml()
    thresholds = _get(data, "archive", "type_detection", "thresholds")
    if thresholds:
        return thresholds
    return {
        "pre_skill": {"proto_min": 5},
        "memory": {"proto_max": 3, "memory_min": 4},
        "mixed": {"proto_min": 3, "memory_min": 3},
    }


def load_defaults() -> dict:
    """返回归档管线默认值配置。

    返回:
        {"fallback_type": "memory",
         "initial_confidence": 66,
         "initial_iteration": 1,
         "initial_lifecycle": "draft",
         "source_prefix": "archive:ingest:"}
    """
    data = _load_yaml()
    defaults = _get(data, "archive", "type_detection", "defaults")
    if defaults:
        return defaults
    return {
        "fallback_type": "memory",
        "initial_confidence": 66,
        "initial_iteration": 1,
        "initial_lifecycle": "draft",
        "source_prefix": "archive:ingest:",
    }


# ═══════════════════════════════════════════════════
# R6: 标签/路径/评分规则（源自 archive.routing = §9.10）
# ═══════════════════════════════════════════════════

def load_target_keywords() -> dict[str, list[str]]:
    """返回 L2 target → 关键词映射。"""
    data = _load_yaml()
    keywords = _get(data, "archive", "routing", "target_keywords")
    if keywords:
        return keywords
    return _fallback_target_keywords()


def _fallback_target_keywords() -> dict:
    _warn_fallback("_fallback_target_keywords")
    return {
        "plugin": ["plugin", "插件", "mcp"],
        "agent": ["agent", "编排器", "orchestrator", "delegate"],
        "proxy": ["proxy", "代理", "qwen", "千问"],
        "config": ["config", "配置", "profile", "env"],
    }


def load_l3_keywords() -> dict[str, list[str]]:
    """返回 L3 task → 关键词映射。"""
    data = _load_yaml()
    keywords = _get(data, "archive", "routing", "l3_keywords")
    if keywords:
        return keywords
    return _fallback_l3_keywords()


def _fallback_l3_keywords() -> dict:
    _warn_fallback("_fallback_l3_keywords")
    return {
        "setup": ["install", "setup", "config", "部署", "安装"],
        "fix": ["fix", "repair", "troubleshoot", "修复", "排查"],
        "analyze": ["analyze", "分析", "audit", "审查", "检查"],
        "archive": ["archive", "归档", "cleanup", "清理"],
    }


def load_search_directories() -> list[str]:
    """返回 KB 检索目标目录列表。"""
    data = _load_yaml()
    dirs = _get(data, "archive", "routing", "search_directories")
    if dirs:
        return [d.strip() for d in dirs if d.strip()]
    return ["预skill", "记忆", "笔记"]


def load_scoring_rules() -> dict:
    """返回检索评分规则。"""
    data = _load_yaml()
    scoring = _get(data, "archive", "routing", "scoring")
    if scoring:
        return scoring
    return {"filename_match": 90, "tag_match": 60}


def load_write_path_template(type_name: str = "pre_skill") -> str:
    """返回目标类型的写入路径模板。

    模板占位符: {domain}, {target}, {title}, {subtype}, {name}
    """
    data = _load_yaml()
    template_str = _get(data, "archive", "routing", "write_path_template")
    if not template_str:
        return "预skill/skills/{domain}/{target}/{title}.md"
    # 逐行解析，按 type 查找
    for line in template_str.strip().split("\n"):
        line = line.strip()
        if type_name == "pre_skill" and line.startswith("预skill"):
            return line
        if type_name == "memory" and line.startswith("记忆"):
            return line
        if type_name == "note" and line.startswith("笔记"):
            return line
    return "预skill/skills/{domain}/{target}/{title}.md"


# ═══════════════════════════════════════════════════
# write_gate 配置（源自 kb.default_type_config / kb.memory_subtype_map）
# ═══════════════════════════════════════════════════

def load_memory_subtype_map() -> dict[str, str]:
    """返回 memory subtype 映射（英文→中文，中文→中文自映射）。"""
    data = _load_yaml()
    sm = _get(data, "kb", "memory_subtype_map")
    if sm:
        return sm
    return {
        "config": "配置", "rule": "规则", "reference": "参考",
        "tool": "工具", "env": "环境",
        "配置": "配置", "规则": "规则", "参考": "参考",
        "工具": "工具", "环境": "环境",
    }


def load_default_tags() -> list[str]:
    """返回默认 tags。"""
    data = _load_yaml()
    tags = _get(data, "kb", "default_tags")
    if tags:
        return tags
    return ["domain/hermes"]


def load_type_default_config(type_name: str = "pre_skill") -> dict:
    """返回指定类型的默认配置。

    包含 description_template / domain / target / lifecycle / source 等。
    """
    data = _load_yaml()
    cfg = _get(data, "kb", "default_type_config")
    if cfg and type_name in cfg:
        return cfg[type_name]
    return {}


def load_allowed_types() -> set[str]:
    """返回允许写入的类型集合（源自 interfaces.write_knowledge.schema）。"""
    data = _load_yaml()
    enum = _get(data, "interfaces", "write_knowledge", "schema", "target_type", "enum")
    if enum:
        return set(enum)
    return {"pre_skill", "memory", "note"}


# ═══════════════════════════════════════════════════
# R7: 内容质量规则（源自 kb.content_quality = §1.9）
# ═══════════════════════════════════════════════════

def load_content_quality_rules() -> dict:
    """返回内容质量规则全量配置。

    包含：最小正文长度、模板短语黑名单、伪文件模式等。
    镜像自 wiki-目录格式规范.md §1.9。

    返回:
        dict: 与 registry.yaml §kb.content_quality 结构一致
    """
    data = _load_yaml()
    quality = _get(data, "kb", "content_quality")
    if quality:
        return dict(quality)
    return _fallback_content_quality()


def _fallback_content_quality() -> dict:
    """降级：返回最小内容质量规则。"""
    _warn_fallback("_fallback_content_quality")
    return {
        "min_body_chars": {"pre_skill": 200, "memory": 100, "note": 150},
        "min_sections": {"pre_skill": 3, "note": 2},
        "min_workflow_steps": 3,
        "template_phrases": [
            "本文档描述", "暂无详细工作流程", "(待补充)",
            "To be refined by LLM subagent",
        ],
        "template_ratio_threshold": 0.30,
        "ban_pseudo_file": True,
        "pseudo_patterns": [
            r"^(# [a-z_-]+)$",
            r"^\[\[.+\]\]\n\n\[\[.+\]\]$",
            r"^---\n---\n?$",
        ],
    }


def load_template_phrases() -> list[str]:
    """返回禁止模板占位符短语列表。"""
    rules = load_content_quality_rules()
    return rules.get("template_phrases", [])


def load_pseudo_patterns() -> list[str]:
    """返回伪文件识别正则列表。"""
    rules = load_content_quality_rules()
    return rules.get("pseudo_patterns", [])


def load_quality_min_body(doc_type: str = "pre_skill") -> int:
    """返回指定类型的最小正文字符数。"""
    rules = load_content_quality_rules()
    return rules.get("min_body_chars", {}).get(doc_type, 100)


def _is_asset_path(file_path: str) -> bool:
    """判断文件路径是否属于 _assets/ 资产目录。

    资产文件不做 wiki 内容解析，跳过全部质量检查。
    子目录由大模型按三级标签动态创建，不硬编码。"""
    if not file_path:
        return False
    normalized = file_path.replace("\\", "/")
    return "/_assets/" in normalized or normalized.startswith("_assets/")


def check_content_quality(content: str, doc_type: str = "pre_skill",
                          file_path: str = None) -> dict:
    """对给定内容执行内容质量检查。

    检查项:
        - 正文长度 ≥ min_body_chars
        - 模板短语占比 < template_ratio_threshold
        - 伪文件模式不匹配
        - 必要章节数（pre-skill/note）
        - 工作流程步骤数（pre-skill）

    Args:
        content: 完整文件内容（含 frontmatter）
        doc_type: pre_skill / memory / note

    Returns:
        {"pass": bool, "checks": dict[str, bool], "reasons": list[str]}
    """
    # 资产文件（_assets/）跳过全部内容质量检查
    if file_path and _is_asset_path(file_path):
        return {"pass": True, "checks": {"asset_skip": True}, "reasons": []}

    rules = load_content_quality_rules()
    reasons = []
    checks = {}

    # 提取正文（跳过 frontmatter）
    body = content
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            body = parts[2].strip()
        else:
            body = ""
    elif "---" in content:
        parts = content.split("---", 1)
        body = parts[1].strip() if len(parts) > 1 else content

    body_len = len(body)

    # 检查1: 正文长度
    min_body = rules.get("min_body_chars", {}).get(doc_type, 100)
    checks["min_body"] = body_len >= min_body
    if not checks["min_body"]:
        reasons.append(f"正文仅 {body_len} 字符，需 ≥ {min_body}")

    # 检查2: 模板短语比例
    phrases = rules.get("template_phrases", [])
    ratio_threshold = rules.get("template_ratio_threshold", 0.30)
    if phrases and body_len > 0:
        template_chars = sum(body.count(p) * len(p) for p in phrases)
        ratio = template_chars / body_len
        checks["no_template"] = ratio < ratio_threshold
        if not checks["no_template"]:
            reasons.append(f"模板占位符占比 {ratio:.0%}，需 < {ratio_threshold:.0%}")
    else:
        checks["no_template"] = True

    # 检查3: 伪文件模式
    if rules.get("ban_pseudo_file", False):
        import re
        is_pseudo = False
        for pat in rules.get("pseudo_patterns", []):
            if re.search(pat, content.strip()):
                is_pseudo = True
                reasons.append(f"匹配伪文件模式: {pat}")
                break
        checks["not_pseudo"] = not is_pseudo
    else:
        checks["not_pseudo"] = True

    # 检查4: 最少章节数（仅 pre-skill）
    min_sec = rules.get("min_sections", {}).get(doc_type, 0)
    if min_sec > 0:
        section_count = sum(1 for line in body.splitlines()
                            if line.strip().startswith("## ") and len(line.strip()) > 4)
        checks["min_sections"] = section_count >= min_sec
        if not checks["min_sections"]:
            reasons.append(f"仅 {section_count} 个章节，需 ≥ {min_sec}")
    else:
        checks["min_sections"] = True

    # 检查5: 外部文件路径引用（§1.10 自包含原则）
    if rules.get("ban_external_source_refs", False):
        import re
        ext_patterns = rules.get("external_ref_patterns", [])
        allowed_prefixes = rules.get("allowed_ref_prefixes", [])
        has_external_ref = False
        for pat in ext_patterns:
            for m in re.finditer(pat, body):
                ref = m.group()
                # 检查是否在允许前缀内
                is_allowed = any(ref.startswith(p) for p in allowed_prefixes)
                if not is_allowed:
                    has_external_ref = True
                    reasons.append(f"含外部路径引用: {ref[:60]}")
                    break
            if has_external_ref:
                break
        checks["no_external_ref"] = not has_external_ref
    else:
        checks["no_external_ref"] = True

    all_pass = all(v for v in checks.values())
    return {"pass": all_pass, "checks": checks, "reasons": reasons}


# ═══════════════════════════════════════════════════
# 批量加载（供子代理/CLI 一次性获取）
# ═══════════════════════════════════════════════════

def get_all_format_rules() -> dict:
    """返回所有格式规则的汇总 dict，供一次性使用。"""
    return {
        "field_orders": {
            "pre_skill": load_field_order("pre_skill"),
            "memory": load_field_order("memory"),
            "note": load_field_order("note"),
        },
        "predicate_table": load_predicate_table(),
        "required_sections": {
            "pre_skill": load_required_sections("pre_skill"),
            "memory": load_required_sections("memory"),
            "note": load_required_sections("note"),
        },
        "required_frontmatter": {
            "pre_skill": load_required_frontmatter("pre_skill"),
            "memory": load_required_frontmatter("memory"),
            "note": load_required_frontmatter("note"),
        },
        "type_signals": load_type_signals(),
        "type_thresholds": load_type_thresholds(),
        "defaults": load_defaults(),
        "target_keywords": load_target_keywords(),
        "l3_keywords": load_l3_keywords(),
        "search_directories": load_search_directories(),
        "scoring": load_scoring_rules(),
        "content_quality": load_content_quality_rules(),
    }


def print_all():
    """CLI: 打印所有格式规则。"""
    import json
    rules = get_all_format_rules()
    for key, val in rules.items():
        print(f"\n{'=' * 60}")
        print(f"  {key}")
        print(f"{'=' * 60}")
        print(json.dumps(val, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    print_all()
