#!/usr/bin/env python3
"""
archive_shim.py — UDG 归档管线包装器
职责：在存档管线各 phase 脚本中注入 registry.yaml 配置，替代其内部硬编码映射。
     不修改原始脚本（Codex 更新会覆盖），通过 Python 运行时注入实现。

用法：
    python archive_shim.py phase5 --cluster cluster_000
    等价于运行 archive-tag-extractor.py 但 DOMAIN_KEYWORDS 等从 registry.yaml 读取。

原理：
    archive_shim 生成一个临时 _uer_phase_patch.py 到归档脚本目录，
    该文件在目标脚本导入前覆写其模块级常量，然后执行目标脚本的入口逻辑。
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# ── 自动发现位置 ──
SHIM_DIR = Path(__file__).resolve().parent
UDG_DIR = SHIM_DIR
REGISTRY_DIR = SHIM_DIR.parent
WIKI_ROOT = REGISTRY_DIR.parent.parent

# 归档脚本目录（从 registry.yaml 读取）
_ARCHIVE_YAML_DIR = None  # lazy-loaded


def _merge_local(data):
    """registry.local.yaml 本机覆盖合并（机器专属路径不入模板；不存在则原样返回）"""
    try:
        import yaml as _y
        _lp = REGISTRY_DIR / "registry.local.yaml"
        if _lp.exists():
            loc = _y.safe_load(_lp.read_text(encoding="utf-8")) or {}
            for _sec in ("roots", "paths"):
                if isinstance(loc.get(_sec), dict):
                    data.setdefault(_sec, {}).update(loc[_sec])
    except Exception:
        pass
    return data
def _get_archive_dir():
    global _ARCHIVE_YAML_DIR
    if _ARCHIVE_YAML_DIR:
        return _ARCHIVE_YAML_DIR
    try:
        import yaml
        raw = (REGISTRY_DIR / "registry.yaml").read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
        data = _merge_local(data)
        path = data.get("roots", {}).get("archive_plugin_dir", "")
        if path:
            _ARCHIVE_YAML_DIR = Path(path)
            return _ARCHIVE_YAML_DIR
    except Exception:
        pass
    return Path("")  # 本机路径经 registry.local.yaml 提供；缺失时返回空

ARCHIVE_DIR = _get_archive_dir()

# ── 阶段→脚本名注入变量对应表 ──
# 每个 phase 需要覆写哪些变量
PHASE_OVERRIDES = {
    "phase2":  ("archive-cluster.py", ["TOPIC_PATTERNS"]),
    "phase3b": ("archive-type-detector.py", []),
    "phase3b+":("memory_attr_extractor.py", ["domain_keywords"]),
    "phase4":  ("archive-name-extractor.py", ["SUBJECT_KEYWORDS"]),
    "phase5":  ("archive-tag-extractor.py", [
        "TOPIC_DOMAIN_MAP", "TOPIC_TARGET_MAP",
        "DOMAIN_KEYWORDS", "TARGET_KEYWORDS"]),
    "phase6":  ("archive-retriever.py", []),
    "phase8":  ("archive-validator.py", []),
}

# registry.yaml 中变量名 → override 函数名映射
REGISTRY_MAP = {
    "TOPIC_PATTERNS":   "get_topic_patterns",
    "TOPIC_DOMAIN_MAP": "get_topic_domain_map",
    "TOPIC_TARGET_MAP": "get_topic_target_map",
    "DOMAIN_KEYWORDS":  "get_domain_keywords",
    "TARGET_KEYWORDS":  "get_target_keywords",
    "SUBJECT_KEYWORDS": "get_subject_keywords",
    "domain_keywords":  "get_domain_keywords",
}


def _generate_patch_script(override_vars: list, registry_loader_path: str) -> str:
    """
    生成补丁脚本源代码。
    这个脚本的作用：加载 registry_loader → 覆写指定变量 → 导入并执行目标脚本。
    """
    # 构造变量覆写代码
    override_lines = []
    for var_name in override_vars:
        func_name = REGISTRY_MAP.get(var_name)
        if func_name:
            override_lines.append(
                f"{var_name} = loader.{func_name}()"
            )

    patch_code = f'''#!/usr/bin/env python3
"""UER Registry Injection — 由 archive_shim 自动生成"""
import sys
import json
from pathlib import Path

# ── Step 1: 加载 registry_loader ──
_LOADER_PATH = Path({json.dumps(registry_loader_path)})
sys.path.insert(0, str(_LOADER_PATH.parent))
import registry_loader as loader

# ── Step 2: 覆写目标脚本中的模块级变量 ──
{chr(10).join(override_lines)}

# ── Step 3: 定位并执行目标脚本 ──
_TARGET_SCRIPT = Path(sys.argv[1]).resolve()
sys.argv = sys.argv[1:]  # 透传 CLI 参数
sys.path.insert(0, str(_TARGET_SCRIPT.parent))

# 加载目标模块
import importlib.util
_spec = importlib.util.spec_from_file_location("target_module", _TARGET_SCRIPT)
_module = importlib.util.module_from_spec(_spec)

# 将覆写变量注入模块命名空间
{chr(10).join(f'_module.{var_name} = {var_name}' for var_name in override_vars)}

_spec.loader.exec_module(_module)
'''
    return patch_code


def run_patched(phase: str, script_args: list = None) -> dict:
    """
    以 registry 注入模式运行归档 phase 脚本。

    Args:
        phase: "phase2" ~ "phase8"
        script_args: 传给目标脚本的 CLI 参数，如 ["--cluster", "cluster_000"]

    Returns:
        {"status": "completed"|"failed", "stdout": "...", "stderr": "...", "returncode": N}
    """
    if phase not in PHASE_OVERRIDES:
        return {"status": "error", "error": f"不支持的阶段: {phase}"}

    script_name, override_vars = PHASE_OVERRIDES[phase]
    script_path = ARCHIVE_DIR / script_name

    if not script_path.exists():
        return {"status": "error", "error": f"脚本不存在: {script_path}"}

    override_vars = [v for v in override_vars
                     if v in REGISTRY_MAP]  # 过滤：只在 registry 中有定义的才注入

    if not override_vars:
        # 没有需要覆写的变量 → 直接运行原脚本
        cmd = [sys.executable or "python", str(script_path)] + (script_args or [])
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                               cwd=str(ARCHIVE_DIR))
            return {
                "status": "completed" if r.returncode == 0 else "failed",
                "stdout": r.stdout,
                "stderr": r.stderr,
                "returncode": r.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"status": "failed", "error": "超时 (300s)"}

    # 有需要覆写的变量 → 生成补丁脚本
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    ) as f:
        patch_code = _generate_patch_script(override_vars, str(UDG_DIR / "registry_loader.py"))
        f.write(patch_code)
        patch_path = f.name

    try:
        cmd = [sys.executable or "python", patch_path, str(script_path)] + (script_args or [])
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                           cwd=str(ARCHIVE_DIR))
        result = {
            "status": "completed" if r.returncode == 0 else "failed",
            "stdout": r.stdout,
            "stderr": r.stderr,
            "returncode": r.returncode,
        }
    except subprocess.TimeoutExpired:
        result = {"status": "failed", "error": "超时 (300s)"}
    finally:
        Path(patch_path).unlink(missing_ok=True)

    return result


def run_pipeline_phases(phases: list = None, cluster_id: str = None,
                        dry_run: bool = False) -> dict:
    """
    运行管线指定的多个阶段（支持注册表注入）。

    Args:
        phases: ["phase2", "phase3b", "phase5", ...]
        cluster_id: 指定 cluster
        dry_run: 预览模式

    Returns:
        {"status": "completed"|"partial", "phases": {...}}
    """
    all_phases = ["phase2", "phase3a", "phase3b", "phase3b+",
                  "phase4", "phase5", "phase6", "phase7", "phase8", "phase9"]
    phases = phases or all_phases

    completed = {}
    failed = {}

    for phase in phases:
        script_args = []
        if phase in ("phase3b", "phase3b+", "phase4", "phase5", "phase6", "phase8"):
            if cluster_id:
                script_args = ["--cluster", cluster_id]
        elif phase == "phase7":
            script_args = ["writeback"]
            if cluster_id:
                script_args.append(cluster_id)

        if dry_run:
            script_name = PHASE_OVERRIDES.get(phase, [None])[0] or phase
            completed[phase] = {"dry_run": True, "script": script_name}
            continue

        result = run_patched(phase, script_args)
        if result["status"] == "completed":
            completed[phase] = result
        else:
            failed[phase] = result

    status = "completed" if not failed else "partial"
    return {
        "status": status,
        "phases_completed": list(completed.keys()),
        "phases_failed": list(failed.keys()),
        "completed": completed,
        "failed": failed,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description="UDG Archive Shim — 归档管线包装器")
    parser.add_argument("action", choices=["run", "list", "dry-run"],
                        help="run=运行阶段, list=列出阶段, dry-run=预览")
    parser.add_argument("phase", nargs="?", default=None,
                        help="阶段名 (phase2~phase8)，省略则运行全部")
    parser.add_argument("--cluster", default=None, help="cluster ID")
    parser.add_argument("--args", nargs="*", default=None,
                        help="透传给脚本的额外参数")

    args = parser.parse_args()

    if args.action == "list":
        print("可用阶段:")
        for phase, (script, vars_list) in sorted(PHASE_OVERRIDES.items()):
            vars_str = ", ".join(vars_list) if vars_list else "(无注入)"
            print(f"  {phase:12s} → {script:35s} 覆写: {vars_str}")
        return

    phases = [args.phase] if args.phase else None
    result = run_pipeline_phases(phases=phases, cluster_id=args.cluster,
                                  dry_run=(args.action == "dry-run"))

    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(1 if result.get("status") == "error" else 0)


if __name__ == "__main__":
    main()
