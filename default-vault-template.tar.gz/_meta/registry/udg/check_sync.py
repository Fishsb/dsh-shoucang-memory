#!/usr/bin/env python3
"""check_sync.py — 全技能域交叉验证。

遍历 ~/AppData/Local/hermes/skills/ 下所有 .md 文件，
与 registry.yaml §orchestrator 声明的版本号/编号/路径比对，
报告一切分歧。
"""
import yaml, re, sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

# Registry discovery: try known paths in order
_REGISTRY_CANDIDATES = [
    SCRIPT_DIR.parent.parent / "registry.yaml",           # _meta/registry/udg/ → _meta/registry.yaml
    Path(r"D:\lk\Obsidian\wiki\_meta\registry\registry.yaml"),  # absolute fallback
]

REGISTRY = None
for p in _REGISTRY_CANDIDATES:
    if p.exists():
        REGISTRY = p
        break

SKILLS_ROOT = Path.home() / "AppData/Local/hermes/skills"

# Registry discovery: try paths in order for WIKI_ROOT
_WIKI_CANDIDATES = [
    Path(r"D:\lk\Obsidian\wiki"),  # primary fallback
]
# Try reading from registry.yaml if available
_reg_try = Path(__file__).resolve().parent.parent.parent / "registry.yaml"
if _reg_try.exists():
    try:
        import yaml
        _reg = yaml.safe_load(_reg_try.read_text(encoding="utf-8"))
        _rw = _reg.get("roots", {}).get("wiki_root")
        if _rw:
            _WIKI_CANDIDATES.insert(0, Path(_rw))
    except Exception:
        pass

WIKI_ROOT = _WIKI_CANDIDATES[0]

def load_registry():
    with open(REGISTRY, encoding="utf-8") as f:
        return yaml.safe_load(f)

def find_md_files(root):
    return list(root.rglob("*.md"))

def check_version(orc, files):
    """检查所有技能文件中对 orchestrator-constraint 版本号的引用。"""
    declared = orc.get("version", "unknown")
    _LEGACY_MARKER = "uer-legacy-reference"
    issues = []
    pattern = re.compile(r'orchestrator-constraint.*?v(\d+\.\d+\.\d+)')
    
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        # Skip legacy-reference files
        if _LEGACY_MARKER in text:
            continue
        for m in pattern.finditer(text):
            ref_ver = m.group(1)
            if ref_ver != declared:
                rel = f.relative_to(SKILLS_ROOT)
                issues.append((str(rel), ref_ver, declared))
    
    return issues

def check_old_numbering(files):
    """检查是否仍在使用旧编号 B1/B5/D4u/D4e（迁移表中已知的旧名）。"""
    old_patterns = {
        r'\bB1\b(?!\d)(?![-\w])': 'B1 → B10',
        r'\bB5\b(?!\d)(?![-\w])': 'B5 → B50',
        r'\bB6\b(?!\d)(?![-\w])': 'B6 → B60',
        r'\bB7\b(?!\d)(?![-\w])': 'B7 → B70',
        r'\bD1\b(?!\d)': 'D1 → D10',
        r'\bD2\b(?!\d)': 'D2 → D20',
        r'\bD3\b(?!\d)': 'D3 → D30',
        r'\bD4u\b': 'D4u → D45',
        r'\bD5\b(?!\d)': 'D5 → D50',
        r'\bD6\b(?!\d)': 'D6 → D60',
        r'\bE1\b(?!\d)': 'E1 → E10',
        r'\bE2\b(?!\d)': 'E2 → E20',
        r'\bE3\b(?!\d)': 'E3 → E30',
        r'\bE4\b(?!\d)': 'E4 → E40',
        r'\bE5\b(?!\d)': 'E5 → E50',
    }
    # Exclusions: files marked with uer-legacy-reference marker
    # Any file can opt out by containing the string "uer-legacy-reference" 
    # (as a comment, frontmatter tag, or any markdown text)
    _LEGACY_MARKER = "uer-legacy-reference"
    
    issues = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        # Skip legacy-reference files
        if _LEGACY_MARKER in text:
            continue
        rel = str(f.relative_to(SKILLS_ROOT)).replace("\\", "/")
        for pat, hint in old_patterns.items():
            if re.search(pat, text):
                issues.append((rel, hint))
                break  # one issue per file is enough
    
    return issues

def check_gate_state_ref(files):
    """检查是否还有 _gate_state.json 引用。"""
    issues = []
    _LEGACY_MARKER = "uer-legacy-reference"
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if _LEGACY_MARKER in text:
            continue
        if "_gate_state.json" in text or "g6_approved" in text:
            rel = f.relative_to(SKILLS_ROOT)
            issues.append(str(rel))
    return issues


def check_kb_frontmatter(files, kb_spec):
    """检查 KB wiki 文件 frontmatter 字段序是否与 registry 声明一致。"""
    _LEGACY_MARKER = "uer-legacy-reference"
    field_orders = kb_spec.get("frontmatter_field_orders", {})
    
    # Known legacy: accept subtype in position 2 OR 4 (spec vs reality gap)
    _ACCEPTED_VARIANTS = {
        "memory": [
            ["type", "subtype", "name", "title"],  # spec order
            ["type", "name", "title", "subtype"],  # actual common order
        ]
    }
    
    issues = []
    
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if _LEGACY_MARKER in text:
            continue
            
        # Only check files under wiki paths (预skill/ 记忆/ 笔记/)
        rel = str(f).replace("\\", "/")
        # Skip _index.md files (structural indexes, not content files)
        if "_index.md" in rel:
            continue
        file_type = None
        if "/预skill/" in rel:
            file_type = "pre_skill"
        elif "/记忆/" in rel:
            file_type = "memory"
        elif "/笔记/" in rel:
            file_type = "note"
        else:
            continue
            
        # Parse frontmatter
        try:
            import yaml
            parts = text.split("---", 2)
            if len(parts) < 3:
                continue
            fm = yaml.safe_load(parts[1])
            if not isinstance(fm, dict):
                continue
        except Exception:
            continue
            
        # Check field order against accepted variants
        expected = field_orders.get(file_type, [])
        if not expected:
            continue
        actual_keys = list(fm.keys())
        expected_base = expected[:4]  # check first 4 fields
        accepted = _ACCEPTED_VARIANTS.get(file_type, [expected_base])
        present_first4 = [k for k in actual_keys if k in expected_base][:4]
        
        if present_first4 not in accepted:
            short = rel[-60:] if len(rel) > 60 else rel
            issues.append((short, f"{file_type}: 字段序不符, 期望 {expected_base}, 实际 {present_first4}"))
            
    return issues


def check_archive_phases(arc_spec):
    """检查 Archive 管线 phase 定义完整性。"""
    phases = arc_spec.get("pipeline_phases", [])
    issues = []
    
    phase_ids = [p.get("phase", "?") for p in phases]
    if "7" not in phase_ids:
        issues.append("缺少 Phase 7 (writeback)")
    
    for p in phases:
        if "output" not in p:
            issues.append(f"Phase {p.get('phase', '?')} 缺少 output 定义")
        if "script" not in p:
            issues.append(f"Phase {p.get('phase', '?')} 缺少 script 定义")
    
    return issues

def main():
    print("=" * 60)
    print("UER 同步检查 — check_sync.py")
    print("=" * 60)
    
    reg = load_registry()
    orc = reg.get("orchestrator", {})
    if not orc:
        print("❌ registry.yaml 缺少 orchestrator 段")
        sys.exit(1)
    
    declared_ver = orc.get("version", "unknown")
    print(f"\n注册表声明版本: {declared_ver}")
    print(f"Pitfalls: {len(orc.get('pitfalls', {}))} 条")
    print(f"路径数: {len(reg.get('paths', {}))} 条\n")
    
    files = find_md_files(SKILLS_ROOT)
    print(f"扫描文件: {len(files)} 个\n")
    
    # --- 版本号检查 ---
    ver_issues = check_version(orc, files)
    if ver_issues:
        print(f"❌ 版本号不匹配 ({len(ver_issues)} 处):")
        for f, ref, dec in ver_issues:
            print(f"   {f}: 引用 v{ref} ≠ 声明 v{dec}")
    else:
        print("✅ 版本号全部一致")
    
    # --- 旧编号检查 ---
    num_issues = check_old_numbering(files)
    if num_issues:
        print(f"❌ 旧编号残留 ({len(num_issues)} 处):")
        for f, hint in num_issues:
            print(f"   {f}: {hint}")
    else:
        print("✅ 无旧编号残留")
    
    # --- _gate_state.json 检查 ---
    gate_issues = check_gate_state_ref(files)
    if gate_issues:
        print(f"❌ _gate_state.json 残留 ({len(gate_issues)} 处):")
        for f in gate_issues:
            print(f"   {f}")
    else:
        print("✅ 无 _gate_state.json 引用")
    
    # --- 汇总 ---
    total = len(ver_issues) + len(num_issues) + len(gate_issues)
    
    # --- KB 检查 ---
    kb = reg.get("kb", {})
    if kb:
        kb_issues = check_kb_frontmatter(files, kb)
        total += len(kb_issues)
        if kb_issues:
            print(f"❌ KB frontmatter 对齐问题 ({len(kb_issues)} 处):")
            for f, detail in kb_issues[:5]:
                print(f"   {f}: {detail}")
        else:
            print("✅ KB frontmatter 全部一致")
        # Also scan wiki directory
        wiki_files = list(WIKI_ROOT.rglob("*.md"))
        wiki_issues = check_kb_frontmatter(wiki_files, kb)
        total += len(wiki_issues)
        if wiki_issues:
            print(f"❌ Wiki 文件 frontmatter 字段序问题 ({len(wiki_issues)} 处):")
            for f, detail in wiki_issues[:5]:
                print(f"   {f}: {detail}")
        else:
            print("✅ Wiki 文件 frontmatter 字段序全部一致")
    
    # --- Archive 检查 ---
    archive = reg.get("archive", {})
    if archive:
        archive_issues = check_archive_phases(archive)
        total += len(archive_issues)
        if archive_issues:
            print(f"❌ Archive 管线对齐问题 ({len(archive_issues)} 处):")
            for issue in archive_issues[:5]:
                print(f"   {issue}")
        else:
            print("✅ Archive 管线状态一致")
    if total == 0:
        print(f"\n🎉 UER 同步状态: 健康 (0 issues)")
    else:
        print(f"\n🔴 UER 同步状态: {total} 个问题待修复")
    
    return total

if __name__ == "__main__":
    sys.exit(main())
