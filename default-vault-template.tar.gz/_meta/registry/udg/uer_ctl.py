#!/usr/bin/env python3
"""uer_ctl.py — UER 统一控制台。

CLI 接口管理编排器/KB/Archive 三组件的所有受管理字段。
改一处 = 校验 + 写入 registry + 推送下游 + 验证零漂移。
"""
import argparse, json, sys, re, subprocess
from pathlib import Path

# Registry discovery
_SCRIPT_DIR = Path(__file__).resolve().parent
_CANDIDATES = [
    _SCRIPT_DIR.parent.parent / "registry.yaml",          # _meta/registry/udg/ → _meta/registry.yaml
    Path(r"D:\lk\Obsidian\wiki\_meta\registry\registry.yaml"),  # fallback
]
REGISTRY_PATH = None
for p in _CANDIDATES:
    if p.exists():
        REGISTRY_PATH = p
        break
if not REGISTRY_PATH:
    print("❌ registry.yaml 未找到")
    sys.exit(1)
SCRIPTS_DIR = Path.home() / "AppData/Local/hermes/scripts"
GENERATE = SCRIPTS_DIR / "uer_generate_assets.py"
UERSYNC = SCRIPTS_DIR / "uersync.py"

VALID_PITFALL_GROUPS = {"G1", "G2", "G3", "G4", "全流程通用"}
VALID_CONTRACT_TYPES = {"str", "int", "bool", "list", "dict"}
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")


def _load():
    import yaml
    return yaml.safe_load(REGISTRY_PATH.read_text(encoding="utf-8"))


def _save(data):
    import yaml
    REGISTRY_PATH.write_text(
        yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False, indent=2),
        encoding="utf-8"
    )


def _run_script(path):
    r = subprocess.run(["python", str(path)], capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        print(f"  ⚠️  {path.name} 返回 {r.returncode}: {r.stderr[:200]}")
    return r.returncode == 0


def _check_aligned():
    """运行 uersync 并解析结果。返回 (ok, detail)。"""
    r = subprocess.run(["python", str(UERSYNC)], capture_output=True, text=True, timeout=120)
    ok = r.returncode == 0
    issues = [l.strip() for l in r.stdout.split("\n") if "❌" in l]
    return ok, issues


def cmd_set_version(args):
    """uer_ctl set version X.Y.Z"""
    ver = args.value
    if not VERSION_RE.match(ver):
        print(f"❌ 版本号格式错误: {ver}，需要 X.Y.Z")
        return 1

    data = _load()
    old = data.get("orchestrator", {}).get("version", "?")
    data.setdefault("orchestrator", {})["version"] = ver
    data["orchestrator"]["last_updated"] = "2026-07-13"
    _save(data)
    print(f"📝 registry.yaml: {old} → {ver}")

    if _run_script(GENERATE):
        ok, issues = _check_aligned()
        if ok:
            print(f"✅ 版本已更新: {old} → {ver}，下游全部同步，零漂移")
        else:
            print(f"⚠️  版本已更新但检出 {len(issues)} 个问题:")
            for i in issues[:3]:
                print(f"   {i}")
    return 0


def cmd_add_pitfall(args):
    """uer_ctl add pitfall P32 name G3"""
    pid = args.id.upper()
    name = args.name
    group = args.group

    if not re.match(r"^P\d+$", pid):
        print(f"❌ Pitfall ID 格式错误: {pid}，需要 P 后接数字")
        return 1
    if group not in VALID_PITFALL_GROUPS:
        print(f"❌ 分组错误: {group}，需要 {{{','.join(sorted(VALID_PITFALL_GROUPS))}}}")
        return 1

    data = _load()
    pitfalls = data.setdefault("orchestrator", {}).setdefault("pitfalls", {})
    if pid in pitfalls:
        print(f"❌ {pid} 已存在: {pitfalls[pid]['name']}")
        return 1

    pitfalls[pid] = {"name": name, "group": group}
    _save(data)
    print(f"📝 registry.yaml: {pid} ({name}) 已添加至 {group} 组")

    if _run_script(GENERATE):
        ok, issues = _check_aligned()
        if ok:
            print(f"✅ {pid} 已添加，§0 迁移表已同步")
        else:
            print(f"⚠️  添加成功但检出问题，建议 manual check")
    return 0


def cmd_add_module(args):
    """uer_ctl add module B80 模块名"""
    mid = args.id.upper()
    title = args.title

    if not re.match(r"^[BDE]\d{2}$", mid):
        print(f"❌ 模块编号格式错误: {mid}，需要 B/D/E + 两位数")
        return 1

    data = _load()
    module_map = {"B": "module_b", "D": "module_d", "E": "module_e"}
    key = module_map[mid[0]]
    lst = data.setdefault("orchestrator", {}).setdefault(key, [])
    if mid in lst:
        print(f"❌ {mid} 已存在于 {key}")
        return 1

    lst.append(mid)
    lst.sort(key=lambda x: int(x[1:]))
    _save(data)
    print(f"📝 registry.yaml: {mid} 已添加至 {key}")

    if _run_script(GENERATE):
        ok, _ = _check_aligned()
        if ok:
            print(f"✅ {mid} 已添加，SKILL.md 章节顺序建议后续手动插入")
        else:
            print(f"⚠️  添加成功但建议 manual check")
    return 0


def cmd_set_contract(args):
    """uer_ctl set contract field_name type required"""
    field = args.field
    ftype = args.type
    required = args.required.lower() in ("true", "yes", "1")

    if ftype not in VALID_CONTRACT_TYPES:
        print(f"❌ 类型错误: {ftype}，需要 {{{','.join(sorted(VALID_CONTRACT_TYPES))}}}")
        return 1

    data = _load()
    contract = data.setdefault("orchestrator", {}).setdefault("subagent_return_contract", {})
    if field in contract:
        print(f"⚠️  覆盖已有字段 {field}: {contract[field]}")
    contract[field] = {"type": ftype, "required": required}
    _save(data)
    print(f"📝 registry.yaml: contract.{field} = {{type: {ftype}, required: {required}}}")

    if _run_script(GENERATE):
        print(f"✅ 契约字段 {field} 已更新，gate-source.md 已同步")
    return 0


def cmd_add_phase(args):
    """uer_ctl add phase A 会话摄取 archive-ingestor.py input.json"""
    phase_id = args.phase
    name = args.name
    script = args.script
    output = args.output

    data = _load()
    phases = data.setdefault("archive", {}).setdefault("pipeline_phases", [])
    existing = [p["phase"] for p in phases]
    if phase_id in existing:
        print(f"❌ Phase {phase_id} 已存在")
        return 1

    entry = {"phase": phase_id, "name": name, "script": script, "output": output}
    # Insert Phase A at beginning, others after existing phases
    if phase_id == "A":
        phases.insert(0, entry)
    else:
        phases.append(entry)
    _save(data)
    print(f"📝 registry.yaml: Phase {phase_id} ({name}) 已添加")
    print(f"✅ Phase {phase_id} 已添加至 archive pipeline")
    return 0


def cmd_status(args):
    """uer_ctl status — 运行完整一致性检查"""
    ok, issues = _check_aligned()
    if ok:
        print("✅ UER 同步状态: 健康 (0 issues)")
    else:
        print(f"🔴 检出 {len(issues)} 个问题:")
        for i in issues:
            print(f"   {i}")
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(
        description="UER 统一控制台 — 管理编排器/KB/Archive 受管理字段",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  uer_ctl set version 7.1.0
  uer_ctl add pitfall P32 对抗验证循环退出 G2
  uer_ctl add module B80 新模块
  uer_ctl set contract debug_mode bool false
  uer_ctl add phase A 会话摄取 archive-ingestor.py input.json
  uer_ctl status
""")
    sub = parser.add_subparsers(dest="command", required=True)

    # set version
    sp = sub.add_parser("set", help="设置值 (version/contract)")
    sp.add_argument("field", choices=["version", "contract"], help="字段名")
    sp.add_argument("value", nargs="?", help="值 (version 时)")

    # set contract
    sp_c = sub.add_parser("set-contract", help="设置契约字段 (旧语法)")
    sp_c.add_argument("field")
    sp_c.add_argument("type")
    sp_c.add_argument("required")

    # add pitfall
    sp_p = sub.add_parser("add-pitfall", help="添加 Pitfall (旧语法)")
    sp_p.add_argument("id")
    sp_p.add_argument("name")
    sp_p.add_argument("group")

    sp_p2 = sub.add_parser("add", help="添加 (pitfall/module/phase)")
    sp_p2.add_argument("entity", choices=["pitfall", "module", "phase"])

    # status
    sub.add_parser("status", help="运行一致性检查")

    # Parse and route
    # Use a simple approach: manual parse for better UX
    raw_args = sys.argv[1:]
    if not raw_args:
        parser.print_help()
        return 1

    cmd = raw_args[0]

    if cmd == "set":
        if len(raw_args) >= 3 and raw_args[1] == "version":
            return cmd_set_version(argparse.Namespace(value=raw_args[2]))
        elif len(raw_args) >= 5 and raw_args[1] == "contract":
            return cmd_set_contract(argparse.Namespace(
                field=raw_args[2], type=raw_args[3], required=raw_args[4]))
        else:
            print("用法: uer_ctl set version X.Y.Z")
            print("      uer_ctl set contract field_name type required")
            return 1

    elif cmd == "add" and len(raw_args) >= 2:
        entity = raw_args[1]
        if entity == "pitfall" and len(raw_args) >= 5:
            return cmd_add_pitfall(argparse.Namespace(id=raw_args[2], name=raw_args[3], group=raw_args[4]))
        elif entity == "module" and len(raw_args) >= 4:
            return cmd_add_module(argparse.Namespace(id=raw_args[2], title=raw_args[3]))
        elif entity == "phase" and len(raw_args) >= 6:
            return cmd_add_phase(argparse.Namespace(phase=raw_args[2], name=raw_args[3],
                                                     script=raw_args[4], output=raw_args[5]))
        else:
            print("用法: uer_ctl add pitfall P32 name G3")
            print("      uer_ctl add module B80 标题")
            print("      uer_ctl add phase A 名称 script.py output.json")
            return 1

    elif cmd == "add-pitfall" and len(raw_args) >= 4:
        return cmd_add_pitfall(argparse.Namespace(id=raw_args[1], name=raw_args[2], group=raw_args[3]))

    elif cmd == "set-contract" and len(raw_args) >= 4:
        return cmd_set_contract(argparse.Namespace(field=raw_args[1], type=raw_args[2], required=raw_args[3]))

    elif cmd == "status":
        return cmd_status(None)

    else:
        print(f"未知命令: {cmd}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
