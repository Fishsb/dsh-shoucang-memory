#!/usr/bin/env python3
"""
registry_loader.py — UER 配置加载器
职责：从 registry.yaml 加载 domain/topic 映射，以归档脚本需要的数据格式提供。

🔒 受 bypass_inspector 保护（registry.yaml bypass.protected_paths）
——禁止在此文件中新增硬编码值。任何新规则必须写入 registry.yaml 后再通过 reader 读取。
——所有 _fallback_* 函数是"倒忙降级"用，registry.yaml 正常时永不触发。
——如需修改映射值，只改 registry.yaml §domains。

导入时自动检测是否启用了 fallback（即 registry.yaml 不可读），
结果写入 wiki/_meta/registry/bypass.log。

所有取值函数返回的数据结构与归档脚本 expect 的完全一致，
加 "_from_registry" 后缀避免命名冲突。
"""
import sys
from pathlib import Path

# 自动发现位置
_LOADER_DIR = Path(__file__).resolve().parent
_REGISTRY_DIR = _LOADER_DIR.parent  # _meta/registry/
_WIKI_ROOT = _REGISTRY_DIR.parent.parent
_REGISTRY_YAML = _REGISTRY_DIR / "registry.yaml"




def _merge_local(data):
    """registry.local.yaml 本机覆盖合并（机器专属路径不入模板；不存在则原样返回）"""
    try:
        import yaml as _y
        _lp = _REGISTRY_DIR / "registry.local.yaml"
        if _lp.exists():
            loc = _y.safe_load(_lp.read_text(encoding="utf-8")) or {}
            for _sec in ("roots", "paths"):
                if isinstance(loc.get(_sec), dict):
                    data.setdefault(_sec, {}).update(loc[_sec])
    except Exception:
        pass
    return data
def _load_yaml():
    """加载 registry.yaml（含 registry.local.yaml 本机覆盖）"""
    try:
        import yaml
        raw = _REGISTRY_YAML.read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
        return _merge_local(data)
    except Exception as e:
        print(f"[UER] ⚠️ registry.yaml 加载失败: {e}", file=sys.stderr)
        return None


# ── DOMAIN_KEYWORDS ──
# 格式: {"domain": ["keyword1", "keyword2", ...]}
# 对应: archive-tag-extractor.py, archive-ingestor.py, memory_attr_extractor.py
def get_domain_keywords() -> dict:
    """从 registry.yaml 生成 DOMAIN_KEYWORDS（替代 3 个硬编码副本）"""
    data = _load_yaml()
    if not data or "domains" not in data:
        return _fallback_domain_keywords()
    
    result = {}
    for name, defn in data["domains"].items():
        keywords = defn.get("keywords", [])
        if keywords:
            result[name] = keywords
    return result if result else _fallback_domain_keywords()


def _fallback_domain_keywords() -> dict:
    """降级：当 registry.yaml 不可读时返回最小集合"""
    return {
        "hermes": ["hermes", "编排器", "orchestrator", "编排", "子代理", "delegate", "4-Gate"],
        "codex": ["codex", "gpt", "会话归档", "automation", "mcp", "plugin"],
        "python": ["python", "pip", "poetry", "venv"],
        "network": ["ssh", "dns", "http", "网络", "代理", "vpn", "proxy"],
    }


# ── TOPIC_PATTERNS ──
# 格式: [("topic_name", ["strong_kw1", ...], ["weak_kw1", ...])]
# 对应: archive-cluster.py
def get_topic_patterns() -> list:
    """从 registry.yaml 生成 TOPIC_PATTERNS"""
    data = _load_yaml()
    if not data or "domains" not in data:
        return _fallback_topic_patterns()
    
    patterns = []
    for name, defn in data["domains"].items():
        keywords = defn.get("keywords", [])
        targets = defn.get("targets", [])
        if keywords:
            # 前 5 个关键词作为强关键词
            strong = keywords[:5]
            # 剩余作为弱关键词
            weak = keywords[5:] + targets
            patterns.append((f"uer-{name}", strong, weak))
    return patterns if patterns else _fallback_topic_patterns()


def _fallback_topic_patterns() -> list:
    """降级：最小话题模式"""
    return [
        ("hermes-orchestrator", ["Hermes", "编排器", "4-Gate", "orchestrator"],
         ["G1", "G2", "WBS", "子代理", "delegate_task", "G4"]),
        ("uer-archive", ["归档", "archive", "session"], ["聚类", "writeback"]),
    ]


# ── TOPIC_DOMAIN_MAP ──
# 格式: {"topic": "domain_value"}
# 对应: archive-tag-extractor.py
def get_topic_domain_map() -> dict:
    """从 registry.yaml 生成 TOPIC_DOMAIN_MAP"""
    data = _load_yaml()
    if not data or "domains" not in data:
        return _fallback_topic_domain_map()
    
    mapping = {}
    for name, defn in data["domains"].items():
        for target in defn.get("targets", []):
            mapping[f"uer-{name}"] = name
        # key 用 domain 名自身
        mapping[name] = name
    return mapping if mapping else _fallback_topic_domain_map()


def _fallback_topic_domain_map() -> dict:
    return {"hermes-orchestrator": "hermes", "uer-archive": "archive"}


# ── TOPIC_TARGET_MAP / TARGET_KEYWORDS ──
# 格式: {"topic": "target_value"}  /  {"target": ["kw1", ...]}
# 对应: archive-tag-extractor.py
def get_topic_target_map() -> dict:
    data = _load_yaml()
    if not data or "domains" not in data:
        return _fallback_topic_target_map()
    mapping = {}
    for name, defn in data["domains"].items():
        targets = defn.get("targets", [])
        if targets:
            mapping[f"uer-{name}"] = targets[0]
    return mapping if mapping else _fallback_topic_target_map()


def _fallback_topic_target_map() -> dict:
    return {"hermes-orchestrator": "agent", "uer-archive": "pipeline"}


def get_target_keywords() -> dict:
    """从 registry.yaml 生成 TARGET_KEYWORDS"""
    data = _load_yaml()
    if not data or "domains" not in data:
        return _fallback_target_keywords()
    mapping = {}
    for name, defn in data["domains"].items():
        targets = defn.get("targets", [])
        if targets:
            mapping[name] = targets  # 把 target 名作为关键词
    return mapping if mapping else _fallback_target_keywords()


def _fallback_target_keywords() -> dict:
    return {"hermes": ["agent", "workflow", "gate"], "archive": ["pipeline", "ingestion"]}


# ── SUBJECT_KEYWORDS ──
# 格式: ["keyword1", "keyword2", ...]
# 对应: archive-name-extractor.py
def get_subject_keywords() -> list:
    """从 domain 关键词列表生成 SUBJECT_KEYWORDS"""
    dk = get_domain_keywords()
    subjects = set()
    for keywords in dk.values():
        for kw in keywords:
            subjects.add(kw.lower())
    # 加入主题词
    subjects.update(["hermes", "orchestrator", "archive", "pipeline",
                     "gate", "delegate", "subagent", "wbs"])
    return sorted(subjects)


# ── 全量加载函数（用于 archive_shim 注入）──
def get_all_mappings():
    """返回所有映射的 dict，供 archive_shim 注入"""
    return {
        "DOMAIN_KEYWORDS": get_domain_keywords(),
        "TOPIC_PATTERNS": get_topic_patterns(),
        "TOPIC_DOMAIN_MAP": get_topic_domain_map(),
        "TOPIC_TARGET_MAP": get_topic_target_map(),
        "TARGET_KEYWORDS": get_target_keywords(),
        "SUBJECT_KEYWORDS": get_subject_keywords(),
    }


# ── 编排器元数据 ──
def load_orchestrator_meta() -> dict:
    """从 registry.yaml §orchestrator 读取编排器元数据。

    返回:
    {
        "version": "7.0.0",
        "module_b": ["B10", ...],
        "module_d": ["D10", ...],
        "module_e": ["E10", ...],
        "gate_sequence": ["NONE", ...],
        "gate_list": ["G0", ...],
        "subagent_return_contract": {...},
        "pitfalls": {"P1": {"name": "...", "group": "..."}, ...},
    }
    """
    data = _load_yaml()
    if not data or "orchestrator" not in data:
        return _fallback_orchestrator_meta()
    meta = data["orchestrator"]
    required_keys = ["version", "module_b", "module_d", "module_e",
                     "gate_sequence", "gate_list", "subagent_return_contract", "pitfalls"]
    if all(k in meta for k in required_keys):
        return meta
    return _fallback_orchestrator_meta()


def _fallback_orchestrator_meta() -> dict:
    """降级：最小编排器元数据"""
    return {
        "version": "7.0.0",
        "module_b": ["B10", "B20", "B30", "B40", "B50", "B60", "B70"],
        "module_d": ["D10", "D20", "D30", "D40", "D45", "D50", "D60"],
        "module_e": ["E10", "E20", "E30", "E40", "E50"],
        "gate_sequence": ["NONE", "G0", "G05", "G29", "C1", "G3", "G35", "G4"],
        "gate_list": ["G0", "G05", "G1", "G2", "G29", "G3", "G35", "G4"],
        "subagent_return_contract": {},
        "pitfalls": {},
    }


def print_orchestrator():
    """CLI: 打印编排器元数据"""
    import json
    meta = load_orchestrator_meta()
    print(json.dumps(meta, ensure_ascii=False, indent=2))


def print_all():
    """CLI: 打印所有映射"""
    import json
    mappings = get_all_mappings()
    for key, val in mappings.items():
        print(f"\n{'='*60}")
        print(f"  {key}")
        print(f"{'='*60}")
        print(json.dumps(val, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    print_all()
