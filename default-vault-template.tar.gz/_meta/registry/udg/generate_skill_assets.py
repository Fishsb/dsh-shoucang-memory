#!/usr/bin/env python3
"""generate_skill_assets.py — 从 registry.yaml 生成同步资产。

UER 单源真理。修改 registry.yaml §orchestrator 后运行此脚本，
自动更新所有下游引用文件。

当前更新目标：
  - orchestrator-constraint SKILL.md 的 §0 迁移对照表
  - agent-framework-enforcement references/orchestrator-gate-source.md 的 GATE_SEQUENCE
"""
import yaml, re, sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

# Registry discovery: try paths in order
_REG_CANDIDATES = [
    SCRIPT_DIR.parent.parent / "registry.yaml",           # _meta/registry/udg/ → _meta/
    Path(r"D:\lk\Obsidian\wiki\_meta\registry\registry.yaml"),  # absolute fallback
]

REGISTRY = None
for p in _REG_CANDIDATES:
    if p.exists():
        REGISTRY = p
        break
if not REGISTRY:
    raise FileNotFoundError("registry.yaml 未找到")

SKILLS_BASE = Path.home() / "AppData/Local/hermes/skills/hermes"

ORCHESTRATOR_SKILL = SKILLS_BASE / "orchestrator-constraint" / "SKILL.md"
GATE_SOURCE = SKILLS_BASE / "agent-framework-enforcement" / "references" / "orchestrator-gate-source.md"


def load_registry():
    with open(REGISTRY, encoding="utf-8") as f:
        return yaml.safe_load(f)


MIGRATION_TABLE = """**v6.8.0 → v{ver} 迁移对照**
| 旧编号 | 新编号 | 变更类型 |
|:-------|:-------|:---------|
| B1    | B10   | 十进制区间化 |
| B2    | B20   | 十进制区间化 |
| B3    | B30   | 十进制区间化 |
| B4    | B40   | 十进制区间化 |
| B5    | B50   | 十进制区间化 + 前移（与B60交换顺序） |
| B6    | B60   | 十进制区间化 + 后移 |
| B7    | B70   | 十进制区间化 |
| D1    | D10   | 十进制区间化 |
| D2    | D20   | 十进制区间化 |
| D3    | D30   | 十进制区间化 |
| D4    | D40   | 十进制区间化 + D4e嵌入§4 |
| D4u   | D45   | 十进制区间化 |
| D5    | D50   | 十进制区间化 |
| D6    | D60   | 十进制区间化 |
| G2⑨  | G2.9  | Unicode→标准符号 |
| D4e   | D40§4 | 并入D40第4子节 |
| Pitfall ID | 不变 | P1-P31为永久ID，只按Gate分组重排文档 |"""


def sync_orchestrator_skill(orc):
    """更新 orchestrator-constraint SKILL.md:
       - §0 迁移对照表
       - frontmatter version (line 2)
    """
    ver = orc.get("version", "?")
    table = MIGRATION_TABLE.format(ver=ver)
    
    content = ORCHESTRATOR_SKILL.read_text(encoding="utf-8")
    lines = content.split("\n")
    
    # Update frontmatter version (find "version: X.Y.Z" in frontmatter)
    import re
    ver_updated = False
    lines = content.split("\n")
    for i, line in enumerate(lines):
        m = re.match(r'^version:\s*(\d+\.\d+\.\d+)', line)
        if m and m.group(1) != ver:
            old = m.group(1)
            lines[i] = f"version: {ver}"
            print(f"  frontmatter: v{old} → v{ver}")
            ver_updated = True
            break
        elif m:
            ver_updated = True  # already correct
            break
    if not ver_updated:
        print("⚠️  未在 frontmatter 中找到 version 字段")
    
    # Update description line's version reference
    for i, line in enumerate(lines):
        if line.startswith("description:") and "v" in line:
            import re
            new_line = re.sub(r'v\d+\.\d+\.\d+', f'v{ver}', line)
            if new_line != line:
                lines[i] = new_line
                print(f"  description: 版本号已更新")
            break
    
    content = "\n".join(lines)
    
    # Find and replace the migration table
    start_marker = "**v6.8.0 → v"
    end_marker = "Pitfall ID | 不变"
    
    s = content.find(start_marker)
    e = content.find(end_marker, s)
    if s == -1 or e == -1:
        print("⚠️  未找到迁移表")
        return False
    
    eol2 = content.find("\n\n", content.find("\n", e))
    if eol2 == -1:
        eol2 = len(content)
    
    content = content[:s] + table + content[eol2:]
    ORCHESTRATOR_SKILL.write_text(content, encoding="utf-8")
    print(f"✅ orchestrator-constraint SKILL.md 已同步 (v{ver})")
    return True


GATE_SEQUENCE_BLOCK = """GATE_SEQUENCE = {seq!r}

def _is_valid_transition(from_state: str, to_state: str) -> bool:
    try:
        from_idx = GATE_SEQUENCE.index(from_state)
        to_idx = GATE_SEQUENCE.index(to_state)
    except ValueError:
        return False
    return to_idx >= from_idx  # 只允许向前（含同态）"""


def sync_gate_source(orc):
    """更新 orchestrator-gate-source.md 中的 GATE_SEQUENCE 定义。"""
    seq = orc.get("gate_sequence", [])
    block = GATE_SEQUENCE_BLOCK.format(seq=seq)
    
    content = GATE_SOURCE.read_text(encoding="utf-8")
    
    # Find existing GATE_SEQUENCE definition
    marker = "GATE_SEQUENCE = ["
    s = content.find(marker)
    if s == -1:
        print("⚠️  未在 gate-source.md 中找到 GATE_SEQUENCE")
        return False
    
    # Find end of the function block
    fn_end = content.find("\n\n", s)
    if fn_end == -1:
        fn_end = len(content)
    
    old_block = content[s:fn_end]
    new_content = content[:s] + block + content[fn_end:]
    
    GATE_SOURCE.write_text(new_content, encoding="utf-8")
    print(f"✅ gate-source.md GATE_SEQUENCE 已更新 ({' → '.join(seq)})")
    return True


def main():
    print("=" * 60)
    print("UER 资产生成器 — generate_skill_assets.py")
    print("=" * 60)
    
    reg = load_registry()
    orc = reg.get("orchestrator", {})
    if not orc:
        print("❌ registry.yaml 缺少 orchestrator 段")
        sys.exit(1)
    
    print(f"\n单源版本: {orc.get('version', '?')}")
    print(f"Gate序列: {' → '.join(orc.get('gate_sequence', []))}")
    print(f"Pitfalls: {len(orc.get('pitfalls', {}))} 条\n")
    
    ok1 = sync_orchestrator_skill(orc)
    ok2 = sync_gate_source(orc)
    
    if ok1 and ok2:
        print("\n✅ 所有资产同步完成")
    else:
        print("\n⚠️  部分同步失败")
        sys.exit(1)


if __name__ == "__main__":
    main()
