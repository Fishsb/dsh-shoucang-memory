#!/usr/bin/env node
/**
 * embed_server.cjs — 守藏本地向量嵌入服务（OpenAI 兼容 · 2026-08-27）
 *
 * 设计：克隆生态范本（dsh layered-memory 时代 bge-m3-openai-server.cjs：transformers.js 离线加载 +
 * OpenAI 兼容端点），去硬编码/去项目耦合，作为守藏「模型一键下载配置」的服务骨架。
 *
 * 调用：node embed_server.cjs <模型目录> <维度> <池化:cls|mean> <端口> [日志路径]
 * 依赖：@huggingface/transformers 需可从本文件所在目录向上解析到（部署脚本负责准备 runtime）。
 *
 * 端点：
 *   GET  /health        → {ok, model, dims, pooling}
 *   GET  /v1/models     → {object:"list", data:[{id, owned_by}]}
 *   POST /v1/embeddings → OpenAI 兼容 {input: string|[string], model} → {data:[{embedding,index}]}
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

const MODEL_DIR = process.argv[2];
const DIMS = parseInt(process.argv[3], 10) || 1024;
const POOLING = process.argv[4] || 'cls';
const PORT = parseInt(process.argv[5], 10) || 9917;
const LOG = process.argv[6] || '';
if (!MODEL_DIR) { console.error('usage: node embed_server.cjs <modelDir> <dims> [pooling] [port] [log]'); process.exit(2); }

let transformers = null;
try { transformers = require('@huggingface/transformers'); } catch (e) { /* runtime 缺失由部署脚本诊断 */ }
const { pipeline, env } = transformers || {};

if (env) {
  env.allowRemoteModels = false;      // 离线：只加载本地文件
  env.localModelPath = MODEL_DIR;     // transformers.js 本地模型根
}

function log(m) {
  if (!LOG) return;
  try { fs.appendFileSync(LOG, new Date().toISOString() + ' ' + m + '\n'); } catch (e) { /* 日志失败无害 */ }
}

let extractor = null;
let modelName = path.basename(MODEL_DIR);

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = '';
    req.on('data', (c) => { buf += c; if (buf.length > 8 * 1024 * 1024) { req.destroy(); reject(new Error('body too large')); } });
    req.on('end', () => resolve(buf));
    req.on('error', reject);
  });
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  });
  res.end(body);
}

async function embedOne(text) {
  const out = await extractor(String(text), { pooling: POOLING, normalize: true });
  const data = out.data ?? out.tolist?.()?.[0];
  const vec = Array.from(data ?? []);
  if (vec.length !== DIMS) throw new Error(`dim mismatch: got ${vec.length}, want ${DIMS}`);
  return vec;
}

async function loadModel() {
  if (!transformers) throw new Error('@huggingface/transformers 缺失：请先部署 runtime（npm install --prefix <runtime> @huggingface/transformers）');
  const device = 'cpu';
  try {
    extractor = await pipeline('feature-extraction', MODEL_DIR, { device, dtype: 'q8' });
  } catch (e1) {
    log('q8 load failed: ' + e1.message);
    extractor = await pipeline('feature-extraction', MODEL_DIR, { device });
  }
  // 校验实际维度
  const probe = await embedOne('维度自检');
  log(`model ready dims=${probe.length}`);
}

async function main() {
  try { await loadModel(); log('server ready on :' + PORT); } catch (e) {
    log('load error: ' + (e && e.message));
    console.error('model load failed: ' + (e && e.message));
    process.exit(3);
  }
  http.createServer(async (req, res) => {
    const url = req.url || '/';
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
      if (req.method === 'GET' && (url === '/health' || url.startsWith('/health'))) {
        send(res, 200, { ok: true, model: modelName, dims: DIMS, pooling: POOLING });
        return;
      }
      if (req.method === 'GET' && url === '/v1/models') {
        send(res, 200, { object: 'list', data: [{ id: modelName, owned_by: 'shoucang', dimensions: DIMS }] });
        return;
      }
      if (req.method === 'POST' && url === '/v1/embeddings') {
        const body = JSON.parse(await readBody(req) || '{}');
        const input = body.input;
        const texts = Array.isArray(input) ? input.map(String) : [String(input)];
        const vectors = [];
        for (let i = 0; i < texts.length; i++) vectors.push(await embedOne(texts[i]));
        send(res, 200, { object: 'list', data: vectors.map((v, i) => ({ object: 'embedding', embedding: v, index: i })), model: body.model || modelName });
        return;
      }
      send(res, 404, { error: 'not found' });
    } catch (e) {
      log('req error: ' + e.message);
      send(res, 500, { error: e.message });
    }
  }).listen(PORT, '127.0.0.1', () => {
    log('listening on 127.0.0.1:' + PORT);
    console.log(JSON.stringify({ ok: true, port: PORT, model: modelName, dims: DIMS }));
  });
}

main();