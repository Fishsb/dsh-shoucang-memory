# -*- coding: utf-8 -*-
"""
lifecycle_settle.py — SABC 置信度生命周期结算 + 归档 TTL 扫描（守藏 Phase 4/7）
2026-08-27：长期记忆三梯度（周/月/年）已销毁，管线收敛为「日记忆 + 顶层 归档/」两段；晋升瀑布移除。
依据: wiki-目录格式规范.md §1.5-1.6 / docs/归档管线设计-v1.md §0 合规红线 / shoucang.config.yaml lifecycle.tiers

子命令:
    python lifecycle_settle.py                    # 默认: 置信度结算(干跑,只报告变更)
    python lifecycle_settle.py --apply            # 置信度结算实际写回 + 清零 hit_counts
    python lifecycle_settle.py archive-daily      # 成熟日记忆按类型归档到长期目录(干跑)
    python lifecycle_settle.py archive-daily --apply
    python lifecycle_settle.py archive-sweep      # 扫 归档/ 到期自动销毁(干跑)
    python lifecycle_settle.py archive-sweep --apply

规则:
    - boost: +boost_per_hit × 周期内命中数(.index_cache/hit_counts.json, 上限100)
    - decay: 周期内零命中 −decay(下限0); 各梯度 decay 取自 config.lifecycle.tiers（现行仅日记忆）
    - 豁免: 项目/ 目录、lifecycle: stable、pinned: true
    - archive-sweep: 归档保留 = 来源层档位时间 × ttl_multiplier, 到期即销毁
"""
import io
import json
import re
import sys
from pathlib import Path
from datetime import datetime, timedelta

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8")

WIKI_ROOT = Path(__file__).resolve().parent.parent
HIT_FILE = WIKI_ROOT / ".index_cache" / "hit_counts.json"
BOARDS = ["画像", "记忆", "预skill", "笔记"]

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent / "registry" / "udg"))
    import shoucang_config as sc
except Exception:
    sc = None

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import index_rules as ir  # 归档合规：_index.md 为目录格式权威，不满足→扩展目录类型
except Exception:
    ir = None

ARGS = set(sys.argv[1:])
APPLY = "--apply" in ARGS
CMD = None
for _c in ("archive-daily", "archive-sweep"):
    if _c in ARGS:
        CMD = _c
        break

def _tier_dir(stage):
    # 2026-08-27：长期记忆三梯度（周/月/年）已销毁，管线仅保留顶层归档区
    return WIKI_ROOT / "归档"

def _exempt(fm, rel):
    if rel.startswith("项目"):
        return True
    if str(fm.get("pinned", False)).lower() == "true" or fm.get("pinned") is True:
        return True
    if str(fm.get("lifecycle", "")).lower() == "stable":
        return True
    return False

def parse_frontmatter(text):
    if not text.startswith("---"):
        return None, 0
    end = text.find("---", 3)
    if end == -1:
        return None, 0
    fm_text = text[3:end].rstrip("\n")
    fm = {}
    for line in fm_text.split("\n"):
        m = re.match(r"^([A-Za-z_][\w]*)\s*:\s*(.*)$", line.strip())
        if m:
            k, v = m.group(1), m.group(2).strip().strip('"').strip("'")
            if v.lower() in ("true", "false"):
                fm[k] = v.lower() == "true"
            else:
                try:
                    fm[k] = int(v)
                except ValueError:
                    fm[k] = v
    return fm, end + 3

def serialize_frontmatter(fm):
    lines = ["---"]
    for k, v in fm.items():
        if isinstance(v, bool):
            lines.append(f"{k}: {'true' if v else 'false'}")
        else:
            lines.append(f"{k}: {v}")
    lines.append("---")
    return "\n".join(lines)

def rewrite(fm, body_off, text):
    return serialize_frontmatter(fm) + text[body_off:]

def load_hits():
    try:
        return json.loads(HIT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

# ── 置信度结算 (v0) ──
def settle():
    hits = load_hits()
    boosts = decays = skipped = 0
    report = []
    for board in BOARDS:
        for md in (WIKI_ROOT / board).rglob("*.md"):
            if md.name == "_index.md":
                continue
            rel = md.relative_to(WIKI_ROOT).as_posix()
            try:
                text = md.read_text(encoding="utf-8")
            except Exception:
                continue
            fm, body_off = parse_frontmatter(text)
            if not fm or "confidence" not in fm:
                continue
            if _exempt(fm, rel):
                skipped += 1
                continue
            old = int(fm["confidence"])
            n_hit = int(hits.get(rel, 0))
            new = old + n_hit * 2 if n_hit > 0 else old - 2
            new = max(0, min(100, new))
            if new != old:
                fm["confidence"] = new
                report.append(f"{rel}: {old} -> {new} ({'boost x'+str(n_hit) if n_hit>0 else 'decay'})")
                if APPLY:
                    md.write_text(rewrite(fm, body_off, text), encoding="utf-8")
                boosts += n_hit > 0
                decays += n_hit == 0
    print(json.dumps({"mode": "APPLY" if APPLY else "DRY-RUN", "cmd": "settle",
        "boosted": boosts, "decayed": decays, "exempt_or_skip": skipped, "changes": report[:20]}, ensure_ascii=False, indent=1))
    if APPLY and HIT_FILE.exists():
        HIT_FILE.write_text("{}", encoding="utf-8")

# ── 日记忆 → 长期类型目录 归档（2026-08-27 目标调整） ──
SUBTYPE_DIR = {
    "env": "环境", "环境": "环境",
    "rule": "规则", "规则": "规则",
    "tool": "工具", "工具": "工具",
    "config": "配置", "配置": "配置",
    "ref": "参考", "reference": "参考", "参考": "参考",
}
DEFAULT_DIR = "参考"

def archive_daily():
    """成熟日记忆按类型归档到 记忆/ 下长期目录（参考/工具/规则/环境/配置…）。

    - 门槛：confidence ≥ lifecycle.archive.min_confidence（默认 50）且 created ≥ age_days（默认 1）
    - 目标目录：frontmatter.subtype → SUBTYPE_DIR 映射；未知 subtype → 扩展目录类型
      （ir.ensure_type_dir 建目录并登记父 _index.md，见归档合规红线）
    - 源层移除；目标条目 stage=settled + archived_at；DRY 默认，--apply 执行
    """
    daily_dir = WIKI_ROOT / "记忆" / "日记忆"
    if not daily_dir.exists():
        print(json.dumps({"mode": "APPLY" if APPLY else "DRY-RUN", "cmd": "archive-daily",
            "note": "日记忆目录不存在", "moved": []}, ensure_ascii=False, indent=1))
        return
    min_conf, age_days, default_dir = 50, 1.0, DEFAULT_DIR
    mode = "age"
    fixed_time = "21:30"
    apply_confirm = True
    merge_enabled = True
    if sc:
        try:
            arc = sc.load_config(WIKI_ROOT).get("lifecycle", {}).get("archive", {})
            min_conf = int(arc.get("min_confidence", 50))
            age_days = float(arc.get("age_days", 1))
            default_dir = str(arc.get("default_dir", DEFAULT_DIR))
            mode = str(arc.get("mode", "age") or "age")
            fixed_time = str(arc.get("fixed_time", "21:30") or "21:30")
            apply_confirm = bool(arc.get("apply_confirm", True))
        except Exception:
            pass
    today = datetime.now()
    moved = []
    for md in sorted(daily_dir.glob("*.md")):
        if md.name == "_index.md":
            continue
        try:
            text = md.read_text(encoding="utf-8")
        except Exception:
            continue
        fm, body_off = parse_frontmatter(text)
        if not fm or fm.get("type") != "memory":
            continue
        if int(fm.get("confidence", 0)) < min_conf:
            moved.append(f"{md.name}: 置信{fm.get('confidence')} < {min_conf}, 留日记忆")
            continue
        created = str(fm.get("created") or "")[:10]
        if mode == "fixed":
            # 固定时间模式：当前时刻已达当日 fixed_time → 到期归档（每次蒸馏触发日计划检查）
            try:
                ft = datetime.strptime(fixed_time, "%H:%M").time()
                due = today.time() >= ft
            except Exception:
                due = False
            if not due:
                moved.append(f"{md.name}: 未到每日归档时间 {fixed_time}（fixed 模式）, 留日记忆")
                continue
        else:
            try:
                cdate = datetime.strptime(created, "%Y-%m-%d")
                if (today - cdate) < timedelta(days=age_days):
                    moved.append(f"{md.name}: 未满 {age_days} 天, 留日记忆")
                    continue
            except Exception:
                pass
        subtype = str(fm.get("subtype", "") or "").strip().split("/")[0].strip().strip("\\")
        # 目标目录：已知映射；未知非空 subtype → 扩展目录类型（**必须先网络检索补全新类型 _index.md 规则**，禁止不检索扩展）
        if not subtype:
            target = default_dir
        elif subtype in SUBTYPE_DIR:
            target = SUBTYPE_DIR[subtype]
        elif (WIKI_ROOT / "记忆" / subtype).exists():
            target = subtype  # 既有目录（仅结构化登记，不算新类型扩展）
        else:
            moved.append(f"{md.name}: 未知类型“{subtype}”需先检索补全 _index.md 规则（needs_research_extension），跳过")
            continue
        dst_dir = WIKI_ROOT / "记忆" / target
        if ir:
            ir.ensure_type_dir(dst_dir.parent, target, f"长期记忆目录（{target} 类）", apply=APPLY)
        else:
            dst_dir.mkdir(parents=True, exist_ok=True)
        # 合并去重（合并去重设计-v1 规则层）：目标目录存在同名/高重合条目 → 合并进既有条目而非双份
        merged_into = None
        if merge_enabled and APPLY:
            try:
                cand_path = (dst_dir / md.name)
                exists_same = cand_path.exists()
                if not exists_same:
                    same_name = list(dst_dir.glob(md.name))
                    exists_same = bool(same_name)
                if exists_same:
                    import sys as _mc_sys
                    _mc_dir = Path(__file__).resolve().parent
                    if str(_mc_dir) not in _mc_sys.path:
                        _mc_sys.path.insert(0, str(_mc_dir))
                    import merge_check as _mc
                    new_text = md.read_text(encoding="utf-8")
                    cfg_merge = _mc.load_config().get("merge", {})
                    thr = float(cfg_merge.get("fingerprint_threshold", 0.85))
                    floor = float(cfg_merge.get("complement_floor", 0.4))
                    rows = _mc.scan_dir(target)
                    fm2, body2 = _mc.parse_frontmatter(new_text)
                    decision, tgt, ev, by = _mc.decide(str(fm2.get("name", "") or ""), body2, rows, thr, floor)
                    if decision in ("exact_duplicate", "complement_merge") and tgt:
                        _mc.apply_backup(tgt["path"])
                        new_txt = tgt["text"]
                        if decision == "complement_merge":
                            new_txt += f"\n## 补充（{today.strftime('%Y-%m-%d')}·归档合并）\n{body2.strip()}\n"
                        new_txt = _mc.apply_meta(new_txt, add_source=str(fm2.get("source", "") or ""), link_ids=str(fm2.get("name", "") or ""))
                        tgt["path"].write_text(new_txt, encoding="utf-8")
                        merged_into = tgt["path"].relative_to(WIKI_ROOT).as_posix()
                    elif decision == "suspect" and tgt:
                        # 时序 supersede：旧条目标记不删，新文件走正常移动（含 supersedes 链）
                        _mc.apply_backup(tgt["path"])
                        old_txt = tgt["text"]
                        fmo, _ = _mc.parse_frontmatter(old_txt)
                        fmo["superseded_at"] = today.strftime("%Y-%m-%d")
                        tgt["path"].write_text(_mc.meta_block(fmo) + "\n" + (old_txt.split("---", 2)[2].lstrip("\n") if old_txt.startswith("---") else old_txt), encoding="utf-8")
                        candidate_supersedes = str(fm2.get("name", "") or "")
                        suspect_new = dst_dir / (md.stem + "-new" + md.suffix)
                        moved.append(f"{md.name}: 归档时冲突 supersede（旧条目标记 superseded_at，新条目 {suspect_new.name.split('.')[0]} 含 supersedes 链）")
            except Exception as _me:
                merged_into = None  # 合并失败 → 回落常规移动
        if merged_into:
            moved.append(f"{md.name}: 归档时合并进既有条目 {merged_into}（{decision}，不建双份）")
            if APPLY:
                md.unlink()  # 已并入，源层移除
            continue
        ns = dict(fm)
        if "candidate_supersedes" in dir() and candidate_supersedes and "supersedes" not in ns:
            ns["supersedes"] = candidate_supersedes
        ns["stage"] = "settled"
        ns["archived_at"] = today.strftime("%Y-%m-%d")
        moved.append(f"{md.name}: 日记忆(conf={fm.get('confidence')}, subtype={subtype or '-'}) → 记忆/{target}")
        if APPLY:
            out_p = suspect_new if ("suspect_new" in dir() and suspect_new) else (dst_dir / md.name)
            out_p.write_text(rewrite(ns, body_off, text), encoding="utf-8")
            md.unlink()  # 源层移除（内容已归档至长期类型目录）
    print(json.dumps({"mode": "APPLY" if APPLY else "DRY-RUN", "cmd": "archive-daily",
        "src": str(daily_dir), "changes": moved}, ensure_ascii=False, indent=1))

# ── 归档 TTL 扫描 (v1.3) ──
def archive_sweep():
    """扫 归档/（顶层，2026-08-27 迁移），按来源层档位时间×ttl_multiplier 判定到期销毁。"""
    arc_dir = _tier_dir("archive")
    if sc is None:
        print(json.dumps({"cmd": "archive-sweep", "note": "配置模块缺失, 用默认 TTL", "changes": []}, ensure_ascii=False))
    if not arc_dir.exists():
        print(json.dumps({"cmd": "archive-sweep", "note": "归档区不存在", "changes": []}, ensure_ascii=False))
        return
    today = datetime.now()
    expired = []
    multiplier = sc.archive_ttl_multiplier(WIKI_ROOT) if sc else 2
    for md in sorted(arc_dir.glob("*.md")):
        if md.name == "_index.md":
            continue
        try:
            text = md.read_text(encoding="utf-8")
        except Exception:
            continue
        fm, _ = parse_frontmatter(text)
        # 归档条目标记来源档位时间(晋升快照/淘汰条目都带 stage 或 _archived_at)
        stage = fm.get("_source_stage") or fm.get("stage") or fm.get("_archived_stage")
        if not stage:
            continue
        base_days = sc.tier_ttl_days(stage, WIKI_ROOT) if sc else 1 * multiplier
        # 归档时间
        archived_at = fm.get("_archived_at") or fm.get("created") or ""
        try:
            adate = datetime.strptime(str(archived_at)[:10], "%Y-%m-%d")
        except Exception:
            continue
        age_days = (today - adate).days
        if age_days >= base_days:
            expired.append(f"{md.name}: 归档{age_days}天 >= TTL {base_days}天, 到期销毁")
            if APPLY:
                md.unlink()
        else:
            expired.append(f"{md.name}: 归档{age_days}天 < TTL {base_days}天, 保留")
    print(json.dumps({"mode": "APPLY" if APPLY else "DRY-RUN", "cmd": "archive-sweep",
        "ttl_multiplier": multiplier, "changes": expired[:30]}, ensure_ascii=False, indent=1))

if __name__ == "__main__":
    if CMD == "archive-daily":
        archive_daily()
    elif CMD == "archive-sweep":
        archive_sweep()
    else:
        settle()
