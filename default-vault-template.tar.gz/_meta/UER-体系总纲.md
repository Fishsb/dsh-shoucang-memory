---
type: meta
name: uer-architecture-overview
title: UER 环境注册表体系总纲
tags: [uer, architecture, registry, guard]
confidence: 90
created: 2026-07-11
updated: 2026-07-11
source: orchestrator
---

# UER 环境注册表体系总纲

## 一、为什么需要 UER

知识库（Wiki）↔ 编排器（Orchestrator）↔ 会话归档（Archive）三个组件之间存在大量数据引用和写入操作，历史问题：

| 问题 | 表现 | 根因 |
|:-----|:------|:------|
| 数据漂移 | 同一概念在不同组件认知不同 | 路径/domain/mapping 三处硬编码 |
| 写入路径分裂 | 5 条写路径各自为政 | 无统一写入网关 |
| LLM 绕过 | 子代理直接 write_file 绕过校验 | 框架无约束 |

## 二、总纲：单源 + 三层守卫

```
┌─────────────────────────────────────────────────────────┐
│                   单源注册表 (registry.yaml)              │
│  所有路径、接口、domain 映射只有一处定义                   │
└─────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│  编排器          │ │  知识库 (Wiki)   │ │  会话归档        │
│  (Orchestrator)  │ │                  │ │  (Archive)      │
│                  │ │  预skill/        │ │                  │
│  读: read_gate   │ │  记忆/            │ │  注入: registry │
│  写: delegate    │ │  笔记/            │ │          _loader│
│      → write    │ │  项目/            │ │  写: archive    │
│         _gate   │ │  _meta/          │ │      _shim      │
│                  │ │  _staging/       │ │      → write    │
│                  │ │                  │ │         _gate   │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

## 三、三层守卫体系

所有对知识库（Wiki 文件）的写操作受三层约束，层层递进、互相补位。

### L0 — 编排器自执约束（SOUL.md 层）

| 维度 | 约束 |
|:-----|:------|
| 作用对象 | 编排器自身 |
| 约束方式 | SOUL.md 规则 + orchestrator-constraint skill |
| 核心规则 | 编排器不可直接 write_file/patch 到 wiki 路径，必须 delegate_task 给子代理 |
| 违规后果 | 违反 SOUL.md，触发自恢复协议 |
| 绕过方式 | **绕不过**——SOUL.md 编排器第一优先级加载 |

**规则文本**（已在 orchestrator-constraint 中）：  
> 任何涉及应用代码写入（wiki 目录/预skill/记忆/笔记）的任务 → 必须 delegate_task。
> 即使改动只有一行，也不得自执。

### L1 — 工具集约束（Hermes 框架层）

| 维度 | 约束 |
|:-----|:------|
| 作用对象 | 子代理 |
| 约束方式 | delegate_task 的 enabled_toolsets 参数 |
| 核心规则 | 涉及 wiki 写入的 delegate_task → 排除 file 工具集 |
| 违规后果 | 子代理调用 write_file → 框架返回 ❌ + 正确接口指引 |
| 绕过方式 | **绕不过**——框架层拦截，LLM 无法选择「不 import」|

**原理**：
```python
# 编排器派发时指定工具集
delegate_task(
    goal="写 Method Card 到预skill",
    context={...},
    toolsets=["terminal", "web"]
    # ↑ 不包含 "file"
)

# 子代理调用 write_file → 框架层返回：
# ❌ 工具 'write_file' 不在可用工具集中
# 可用工具: terminal, web
# 如需写入 wiki，请通过 terminal 调用 write_gate:
#   python .../write_gate.py pre_skill "标题" "内容"
```

为什么绕不过：

| 绕过尝试 | 结果 |
|:---------|:------|
| 子代理 `write_file("预skill/x.md")` | ❌ 框架层拒绝 + 指引 |
| 子代理 `terminal echo > 预skill/x.md` | ✅ terminal 可用 → 但文件写入后会被…… |
| 子代理 `terminal python -c "write_file('...')"` | ✅ terminal 可用 → 但…… |

**L1 只拦工具调用，不拦 terminal 中的 shell 命令**。所以 L1 需要配合 L2。

### L2 — 接口层（UDG write_gate）

| 维度 | 约束 |
|:-----|:------|
| 作用对象 | 所有写路径（包括 terminal 直写） |
| 约束方式 | write_gate 作为唯一写入口 + 写入标记 |
| 核心规则 | 通过 write_gate 写入的文件 frontmatter 自动带 `x-uer-writer: write_gate` |
| 违规处理 | 无标记的文件被 L2 守卫发现后 revert（git checkout）|
| 绕过方式 | 除非 LLM 知道在 frontmatter 中伪造 `x-uer-writer` 标记 |

**L2 守卫**（不轮询，靠 git hook + cron 最小触发）：

```yaml
# registry.yaml
guard:
  mode: "p reactive"  # 被动检查 + git 恢复
  check_on_git_action: true  # 仅 git add/commit 时触发
  marker_key: "x-uer-writer"
  marker_value: "write_gate"
  protected_dirs: ["预skill/", "记忆/", "笔记/"]
```

**工作方式**：

```
被保护目录中的文件变更
    │
    ├─ 来自 write_gate → frontmatter 自带标记 → ✅ 保留
    │
    └─ 来自其他路径（terminal/python直接写） → 无标记
         │
         └─ git 操作时 pre-commit hook 拦截：
            ❌ 预skill/xxx.md 缺少 x-uer-writer 标记
            ✅ 正确做法：
               python .../write_gate.py pre_skill "标题" "内容"
```

**不需要轮询，不需要 cron**——只在 git 操作（提交/推送）时检查，零常驻开销。

---

## 四、三种场景的拦截实例

### 场景 A：Agent 想写一条知识到预skill

```
Agent 错误路径                                 Agent 正确路径
────────────────────                         ────────────────────
write_file("预skill/xxx.md")                  delegate_task(
    │                                             toolsets=["terminal"],
    └─ L1 工具集约束: ❌ 框架拒绝                     context={"write_gate_cli": "python .../write_gate.py"}
        子代理用 terminal 绕过                        )
            │                                    └─ 子代理调 terminal:
            └─ L2 守卫: ❌ git pre-commit 拦截           python write_gate.py ...
                文件无标记 → 不允许提交                      │
                                                          └─ ✅ 通过 + 自动加标记
```

### 场景 B：归档管线想写回 Wiki

```
archive-writeback.py 写入
    │
    └─ 原始：直接 write_file → 无标记 → git ❌ 拦截
    │
    └─ 正确：通过 archive_shim 包装 → 调用 write_gate → 带标记 → git ✅
```

### 场景 C：修改归档脚本的 DOMAIN_KEYWORDS

```
修改 archive-tag-extractor.py 中的硬编码 dict
    │
    └─ ❌ 已被 registry_loader 替代
    │     脚本内的 dict 不再生效
    │     修改 registry.yaml 的 domains 段才是正确路径
    │
    └─ ✅ 正确：编辑 registry.yaml → 运行 registry_validator.py 验证
```

---

## 五、已部署文件清单

```
wiki/_meta/registry/
├── registry.yaml              ← 单源注册表（路径/接口/domain映射）
├── registry_validator.py      ← 自检脚本
├── bypass_inspector.py        ← 旁路拦截（编排器层）
│
└── udg/
    ├── write_gate.py          ← 写网关（wiki 文件写入唯一入口）
    ├── read_gate.py           ← 读网关
    ├── archive_gate.py        ← 归档管道网关
    ├── archive_shim.py        ← 归档注入器（用 registry 替代硬编码）
    └── registry_loader.py     ← 配置加载器

wiki/_meta/UER-体系总纲.md      ← 本文档

orchestrator-constraint skill （已更新）
  ├── B5: 注入 UER 注册表上下文
  ├── D4e: 走 write_gate 写入（不自执）
  ├── D4u: 走 memory 而非废弃的 HermesDB
  └── 工具域：wiki 写任务排除 file 工具集
```

## 六、关键原则

| 原则 | 内容 |
|:-----|:------|
| **写必过接口** | 任何对知识库（预skill/记忆/笔记）的写操作必须经过 `write_gate` |
| **接口自标记** | 通过接口写入的文件自带 `x-uer-writer: write_gate` 标记 |
| **无标记不提交** | git 拒绝提交无标记的保护目录文件 |
| **映射从注册表** | domain/topic/path 所有映射从 registry.yaml 读取，不硬编码 |
| **框架级约束** | 子代理工具集由编排器指定，框架层拦截不合规调用 |
