---
type: wiki/spec
name: wiki-directory-format-spec-v4
title: 守藏目录格式规范（v4.0）
tags:
  - 规则/wiki/format
  - 规则/memory
  - 规则/note
confidence: 95
iteration: 4
created: 2026-07-11
updated: 2026-08-27
source: manual / 2026-08-27 架构重构
description: 守藏总体格式规范 v4：目录体系（画像/记忆/笔记/归档）+ 三层记忆 + 命名/谓词/标签/frontmatter 横切标准；各目录 _index.md 为目录级格式权威
---

# Wiki 目录格式规范（v4.0）

> 2026-08-27 重构：取代 v3.0（备份 `wiki-目录格式规范.v3.0.bak-20260827.md`）。
> 变化：目录体系收敛为 画像/记忆/笔记/归档 四域（删除 项目/预skill 板块）；引入**三层记忆（热/温/冷）**与**规则层（每个目录 `_index.md` = 该目录格式权威，本文件=总体纲+横切标准）**；归档=顶层 `归档/`（TTL 销毁）+ `archive-daily` 按类型归档；指针化红线与「扩展目录类型须先检索」。

## §0 系统本体

### 0.1 使命
守藏 = 个人知识管理系统（PKMS）+ AI 编排底座：人类在 Obsidian 阅读/维护，AI（Agent）按规范蒸馏、归档、注入、召回。

### 0.2 目录体系（四域 + 三层）

| 域 | 类型 | 角色 | 访问 |
| --- | --- | --- | --- |
| `画像/`（我·你） | persona | **热**：用户/agent 画像指针，每轮注入 | 热·注入 |
| `记忆/日记忆/` | memory | **热·临时**：当日蒸馏指针，每轮注入；成熟归档入温层 | 热·注入 |
| `记忆/参考|工具|规则|环境|配置` | memory | **温**：长期仓库文件 | 按需 get_file |
| `笔记/`（单一冷层目录，子域按需扩展） | note | **冷·参考资料**：蒸馏来源、必做双链 | 按需+主动召回 |
| `归档/` | 快照 | **冷**：淘汰/废弃快照，TTL 销毁 | 显式召回/回退 |

- 各目录 `_index.md` = **该目录文件规范（格式权威）**；默认隐藏，可经 `[[双链]]` 显式打开。
- 指针化红线：注入一律指针行，禁止全文注入；温/冷不注入。

## §1 通用规则（横切标准）

### 1.1 命名规则
- 1.1.1 文件名（不含扩展名）**必须等于** frontmatter `name` 字段值；`name` 与文件名一致保证 `[[name]]` 双链正确解析。
- 1.1.2 `name` 结构：**主-宾-谓** 三段式，kebab-case。
  - 主=主体实体/工具/系统（如 dsh-host、v2ray）；宾=作用对象/子主题（如 cordis、proxy）；谓=文档类型后缀（见 1.1.3）。
  - `记忆/` 单事实条目谓词用 `note`；`笔记/` 走主-宾-谓。
- 1.1.3 谓词表（适用 记忆/笔记）：

| 谓词 | 说明 | 适用 |
| --- | --- | --- |
| 配置方法 / 部署教程 | 配置/安装/部署指引 | 笔记 |
| 故障排查 | 排障指南 | 笔记 |
| 调研报告 / 原理分析 | 调研/分析 | 笔记 |
| 测试验证 / 审计检查 | 验证/审计 | 笔记 |
| 开发指南 / 使用教程 | 指南 | 笔记 |
| 优化方案 / 工作流 | 方案/流程 | 笔记 |
| 速查 | 速查参考 | 记忆 |
| 配置片段 | 配置片段 | 记忆 |
| reference / 参考 | 参考文档 | 记忆 |

### 1.2 tags 标签规则
- 层级 ≤3（L1 域 / L2 主题 / L3 任务），全小写（无空格），每文件 1–5 个；域标识：`shoucang`、`env|rule|tool|config|ref|note`、`codex` 等。

### 1.3 frontmatter 字段定义（字段序）
`type / name / title / tags / subtype / stage / confidence / created / updated / description / source`
- type：memory / persona / note / index / wiki/spec
- subtype：记忆类固定枚举 `env|rule|tool|config|ref`（未知→**扩展目录类型须先检索**）；画像 `persona-user|persona-agent`；笔记无固定 subtype（tags 域标识）
- stage：daily（日记忆）/ settled（温层）/ archive（归档）；画像/笔记无
- confidence：新建 60，由 lifecycle settle 统一增减（不手动调）
- description：画像=**一句话注入基线**；其余=条目摘要
- source：日记忆/笔记必填（来源会话 id / 原文链接）

### 1.4 正文质量
- memory ≥100 字；note ≥150 字（自己的话提炼，禁大段复制，单主题一张卡）
- **自包含**：禁止绝对路径信息源与脱库引用；跨条目引用只用 `[[wiki-link]]`（双链）；占位符短语占比 ≥30% 拒绝

### 1.5 置信度与生命周期（SABC）
- confidence 评分 + `_meta/lifecycle_settle.py` 定时结算（boost/decay/豁免）；淘汰线 conf≤10 且 2 周期零命中 → 归档/（TTL×2 销毁）。

## §2 类型定义

### 2.1 memory（记忆）
- 目录：`记忆/日记忆`（stage=daily）+ `记忆/参考|工具|规则|环境|配置`（stage=settled）
- subtype→目录映射：`env→环境 / rule→规则 / tool→工具 / config→配置 / ref→参考`
- 流程：idle-review 蒸馏 → 日记忆（热）→ `archive-daily` 成熟归档入温层；**未知 subtype 扩展目录类型必须先网络检索**（`index_rules.py --ensure-researched`）

### 2.2 persona（画像）
- 目录：`画像/我`（用户）、`画像/你`（agent）；每目录唯一核心画像文件
- `description` = 注入基线；正文四段（画像/我：概述→关键事实→偏好[场景→偏好→边界]→协作风格；画像/你：响应哲学→行为基线→边界与安全→底线守护）

### 2.3 note（笔记）
- 目录：`笔记/` 单一目录（子域按需扩展目录类型，**扩展须先网络检索**补全新子目录 `_index.md` 规范，复用归档检索扩容方式，不预置）；**来源=蒸馏**（会话中网络检索/整理完善文档），不经归档
- frontmatter 必含 `source` 归因；**必做双链**（与记忆/画像互链）

## §3 归档与规则层
- 归档/：淘汰快照（不可变，`_source_stage/_archived_at/_archived_stage`），TTL×2 自动销毁，只出不进、不入读路由
- 规则层：每个目录 `_index.md` = 目录文件规范（职责/文件类型/frontmatter/正文/维护）；命令（`/scnote`）、蒸馏、归档写入均须遵循目标目录 `_index.md`；扩展目录类型须先检索并补全新类型 `_index.md` 规范