---
type: wiki/moc
name: wiki-knowledge-index-moc-v4
title: 守藏知识库索引（MOC v4）
tags:
  - 规则/wiki/index
  - shoucang
confidence: 90
iteration: 4
created: 2026-07-11
updated: 2026-08-27
source: manual / 2026-08-27 架构重构
description: 守藏知识库入口索引：四域导航 + 三层记忆 + 规则层（各目录 _index.md）+ 管线与配置
---

# 守藏知识库索引（MOC v4）

> 2026-08-27 重构：取代 v3 MOC（备份 `wiki-知识库索引-moc.v3.bak-20260827.md`）；仅索引当前四域结构与规则文件（旧 项目/预skill/站点导航均已撤退）。

## 一、板块速览（四域 · 三层记忆）

| 域 | 入口 | 类型/层 | 说明 |
| --- | --- | --- | --- |
| 画像 | [[画像]]（我[[画像/我]] / 你[[画像/你]]） | persona·热 | 用户/agent 画像指针，每轮注入 |
| 记忆 | [[记忆]] | memory·热/温 | 日记忆（热·临时）→ archive-daily 归入温层类型目录 |
| 笔记 | [[笔记]] | note·冷 | 蒸馏来源参考资料，必做双链 |
| 归档 | [[归档]] | 快照·冷 | 淘汰/废弃快照，TTL×2 销毁 |

记忆温层类型目录：[[记忆/参考]] · [[记忆/工具]] · [[记忆/规则]] · [[记忆/环境]] · [[记忆/配置]]
笔记域：`笔记/` 单一冷层目录（子域按需扩展，**扩展须先网络检索**补全子目录规范，复用归档检索扩容方式）

## 二、规则层（目录文件规范 · 格式权威）

每个目录的 `_index.md` = 该目录文件规范（职责 / 文件类型 / frontmatter / 正文质量 / 维护与扩展规则）。总纲见 [[wiki-目录格式规范]]（v4），MOC 不重复。

## 三、管线与配置（基础设施）

| 项 | 位置 | 作用 |
| --- | --- | --- |
| 蒸馏 | idle-review 契约（会话→日记忆）+ `_meta/explicit_facts_extractor.py` | 防重蒸馏 v2（source 标记 + cutoff 增量） |
| 归档 | `_meta/lifecycle_settle.py`（settle / archive-daily / archive-sweep） | 成熟归温层 · 淘汰进归档 TTL |
| 合规 | `_meta/index_rules.py`（ensure_type_dir / validate / ensure-researched） | `_index.md` 权威 · 扩展目录类型须先检索 |
| 指针同步 | `_meta/gen_pointer_tables.py` | 缺失 _index 生成 + 子目录登记 |
| 配置 | `shoucang.config.yaml` | 板块开关 / injection.level / archive-daily 门槛 |
| 默认结构 | `D:\lk\FF\shoucang-default-structure-check`（参照） | 切换根目录的默认目录构建模板 |

## 四、入口说明

- 面板：守藏设置面板五项视图（画像板块 → 记忆板块 → 知识库 wiki → 板块与管线 → 配置原文）
- 命令：`/scnote <任务>`（笔记化执行：网络检索蒸馏 → 笔记/，遵循目录 `_index.md` 规范）
- 注入：R1 热记忆指针（画像 + 日记忆），温/冷按需召回