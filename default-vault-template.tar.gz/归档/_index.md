---
type: index
title: "归档 指针表"
updated: 2026-08-27
---

# 归档

(暂无条目)

## 目录文件规范（归档 · 冷层（参考资料/回退））

> 依据：三层记忆定义（冷=按需+主动召回，参考资料）+ TTL 生命周期惯例 + 归档定义（不可变）
- 职责：**冷层·淘汰/废弃快照区**——源销毁前落快照；agent 可**主动召回**作参考资料/审计回退；只进不出
- 文件类型：原条目类型 + 快照标记：`stage: archive / _source_stage / _archived_at / _archived_stage`；**已归档条目禁止修改**（不可变快照）
- frontmatter 必填：`type / name / title / stage(archive) / _source_stage / _archived_at / _archived_stage / description`
- 保留期：来源层档位 × `archive.ttl_multiplier`（默认 2）→ archive-sweep 到期 TTL 自动销毁（备份恢复/迁移需重配 TTL，Spanner 惯例）
- 路由：不入常驻注入与常规读路由，仅供显式召回/回退；面板默认隐藏 `_index.md`（双链可显式打开）
- 维护：lifecycle archive-sweep + archive-daily/淘汰写入；不符规则 → 扩展目录类型并登记
