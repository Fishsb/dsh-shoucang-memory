---
type: index
title: "我 指针表"
updated: 2026-08-27
---

# 我

(暂无条目)

## 目录文件规范（我 · 用户画像）

> 依据：网络惯例（agent.md persona 三要素 / 偏好结构化场景→偏好→边界）+ 本地 wiki-目录格式规范（命名 frontmatter）

- 职责：本目录唯一核心画像文件 = **用户协作画像**（用户事实 / 偏好 / 协作风格 / 边界），供 R1 热记忆每轮注入
- 文件类型：`type: persona`；`_index.md` 默认隐藏，双链可显式打开
- frontmatter 必填：`type / name / title / updated / source / description`
  - `description` = **一句话画像基线**（注入指针摘要，如“中文短指令、重实测数据、开源优先”）
- 命名：`name` 主-宾-谓 kebab-case；文件名 = name（与 [[wiki-link]] 解析一致）
- 正文结构（agent.md persona 惯例）：`概述`（角色一句话）→ `关键事实`（项目/环境/喜好，可溯源）→ `偏好`（**场景 → 偏好 → 边界/反例** 三元组）→ `协作风格`（指令/验收习惯）
- 维护：写前备份；画像变更须同步 `description`（指针摘要源）；`source` 记录最近依据（会话/审计）
