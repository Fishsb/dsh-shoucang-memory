---
type: index
title: "你 指针表"
updated: 2026-08-27
---

# 你

(暂无条目)

## 目录文件规范（你 · agent画像）

> 依据：arXiv persona 建模（行为多样性可表示/可验证）+ AWS Agent 安全边界惯例 + 本地 wiki-目录格式规范

- 职责：本目录唯一核心画像文件 = **agent 行为画像**（AI 响应哲学 / 行为基线 / 边界与安全 / 底线守护），供 R1 热记忆每轮注入
- 文件类型：`type: persona`；`_index.md` 默认隐藏
- frontmatter 必填：`type / name / title / updated / source / description`
  - `description` = 一句话 agent 基线（注入指针摘要，如“轻代码多路由、契约优先、底线守护”）
- 命名：`name` 主-宾-谓 kebab-case；文件名 = name
- 正文结构（persona 可验证 + 安全边界惯例）：`响应哲学`（总体原则）→ `行为基线`（默认决策偏好/路由偏好）→ `边界与安全`（工具使用纪律、权限红线、禁止项）→ `底线守护`（不可越过的硬约束）
- 维护：写前备份；行为基线变更须同步 `description`；`source` 记录最近依据
