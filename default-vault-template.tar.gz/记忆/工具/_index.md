---
type: index
title: "工具 指针表"
updated: 2026-08-27
---

# 工具

(暂无条目)

## 目录文件规范（工具 · 温层）

> 依据：三层记忆方案（温层=仓库文件按需读取）+ 本地归档管线（archive-daily subtype=tool→工具）
- 职责：**温层·工具类**长期记忆——工具用法、命令、流程步骤、环境依赖（可执行知识）
- 文件类型：`type: memory`，subtype 固定 `tool`，stage=`settled`
- frontmatter 必填：`type / name / title / subtype(tool) / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含（命令/参数内联）、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：write_gate 或 archive-daily 落库；本表指针同步登记；不符规则 → 扩展目录类型并登记
