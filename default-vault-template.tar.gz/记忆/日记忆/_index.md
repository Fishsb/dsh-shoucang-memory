---
type: index
title: "日记忆 指针表"
updated: 2026-08-27
---

# 日记忆

(暂无条目)

## 目录文件规范（日记忆 · 热层（临时））

> 依据：三层记忆定义（热=每轮注入）+ 用户定稿（日记忆为临时记忆，归类热记忆）

- 职责：**热层·当日蒸馏临时指针源**——idle-review 蒸馏产物（stage=`daily`，窗口 ~7 天），**每次会话注入其指针行**（缩略，全文按需 get_file）；成熟条目（conf≥50 且 ≥1 天）经 archive-daily 归档入温层类型目录
- 文件类型：`type: memory`，subtype 暂不限（归档时定级），stage=`daily`
- frontmatter 必填：`type / name / title / subtype / stage(daily) / confidence / created / updated / description / source`（source=来源会话 id，防重蒸馏依据）
- 正文：事实/结论直陈（可溯源）+ 来源行；≥100 字、自包含、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：蒸馏 write_gate 落库后由 `_meta/gen_pointer_tables.py` 投影重建本表指针行（真源=条目文件，规则块人工维护；2026-08-27 起）；防重蒸馏注册表 `_meta/.distilled-sessions.json`（cutoff 边界，增量蒸馏）
