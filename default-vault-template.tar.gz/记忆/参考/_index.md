---
type: index
title: "参考 指针表"
updated: 2026-08-27
---

# 参考

(暂无条目)

## 目录文件规范（参考 · 温层）

> 依据：三层记忆方案（温层=仓库文件按需读取）+ 本地归档管线（archive-daily subtype=ref→参考）
- 职责：**温层·参考/引用类**长期记忆——需复用的参考事实、来源摘要、指针（不含可执行步骤，有步骤归工具/预skill）
- 文件类型：`type: memory`，subtype 固定 `ref/参考`，stage=`settled`
- frontmatter 必填：`type / name / title / subtype(ref) / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：write_gate 或 archive-daily 落库；本表指针同步登记；不符规则 → 扩展目录类型并登记
