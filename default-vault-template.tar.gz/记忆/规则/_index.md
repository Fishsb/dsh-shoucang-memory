---
type: index
title: "规则 指针表"
updated: 2026-08-27
---

# 规则

(暂无条目)

## 目录文件规范（规则 · 温层）

> 依据：三层记忆方案（温层=仓库文件按需读取）+ 本地归档管线（archive-daily subtype=rule→规则）
- 职责：**温层·规则/约定/原则类**长期记忆——必须遵守的约束、边界、纪律（非单次决策）
- 文件类型：`type: memory`，subtype 固定 `rule`，stage=`settled`
- frontmatter 必填：`type / name / title / subtype(rule) / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含（规则=适用场景+条文+边界/例外）、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：write_gate 或 archive-daily 落库；本表指针同步登记；不符规则 → 扩展目录类型并登记
