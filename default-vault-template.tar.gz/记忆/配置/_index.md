---
type: index
title: "配置 指针表"
updated: 2026-08-27
---

# 配置

(暂无条目)

## 目录文件规范（配置 · 温层）

> 依据：三层记忆方案（温层=仓库文件按需读取）+ 本地归档管线（archive-daily subtype=config→配置）
- 职责：**温层·配置类**长期记忆——配置片段/参数/生效域/环境变量
- 文件类型：`type: memory`，subtype 固定 `config`，stage=`settled`
- frontmatter 必填：`type / name / title / subtype(config) / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含（片段+生效域内联）、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：write_gate 或 archive-daily 落库；本表指针同步登记；不符规则 → 扩展目录类型并登记
