---
type: index
title: "环境 指针表"
updated: 2026-08-27
---

# 环境

(暂无条目)

## 目录文件规范（环境 · 温层）

> 依据：三层记忆方案（温层=仓库文件按需读取；环境配置/故障模式提升为常驻档案）+ 本地归档管线（archive-daily subtype=env→环境）
- 职责：**温层·环境事实类**长期记忆——机器/宿主/链路“有什么、怎么配、偏好什么”（如 DSH宿主与Cordis插件体系环境事实）
- 文件类型：`type: memory`，subtype 固定 `env`，stage=`settled`
- frontmatter 必填：`type / name / title / subtype(env) / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含（版本/路径/配置内联）、不脱库引用；跨条目只用 `[[wiki-link]]`
- 维护：write_gate 或 archive-daily 落库；本表指针同步登记；不符规则 → 扩展目录类型并登记
