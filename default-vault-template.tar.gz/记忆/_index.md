---
type: index
title: "记忆 指针表"
updated: 2026-08-27
---

# 记忆

(暂无条目)

## 子目录

- [[参考]]
- [[工具]]
- [[日记忆]] — 当日知识暂存
- [[环境]]
- [[规则]]
- [[配置]]

## 目录文件规范（记忆 · 板块根（三层修正 2026-08-27））

> 依据：三层记忆方案（热/温/冷）惯例 + 用户定稿修正（2026-08-27）
- 三层定义：**热**=画像（用户/agent 画像）+ **日记忆**（临时·当日蒸馏指针，每轮会话注入）；**温**=类型目录 `参考|工具|规则|环境|配置`（长期仓库文件，按需 get_file 读取，不注入）；**冷**=**笔记 + 归档**（按需加载 + agent **主动召回**，当参考资料；不注入）
- 类型映射（archive-daily，subtype→目录）：`env→环境 / rule→规则 / tool→工具 / config→配置 / ref→参考`；**未知 subtype → 扩展目录类型**：须先按本表规则框架 + **网络检索**补全新类型 `_index.md` 的「目录文件规范」块（`index_rules.py --ensure-researched <parent> <type> --summary <检索结论>`），**禁止不检索信息直接扩展**
- 记忆类文件：`type: memory`；`name` 主-宾-谓 kebab-case；frontmatter 必填 `type / name / title / subtype / stage / confidence / created / updated / description`
- 正文：≥100 字、自包含、不脱库引用；跨条目只用 `[[wiki-link]]`
- 流程：蒸馏 → 日记忆（热·临时）→ 成熟(conf≥50,≥1天) archive-daily 归入温层类型目录；淘汰/废弃 → 归档（冷·TTL×2 销毁）
- 维护：目录规范见各子目录 `_index.md`；不符规则 → 扩展目录类型并登记
