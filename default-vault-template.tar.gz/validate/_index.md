---
type: index
title: "validate 指针表"
updated: 2026-08-27
---

# validate

(暂无条目)

## 子目录

- [[记忆]]
